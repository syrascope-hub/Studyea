# Security notes

- Never commit provider API keys.
- StudyEA stores supported keys in the platform secure-storage API and does not include them in `Store.toMap()` backups.
- A prior StudyEA JSON file may contain legacy plaintext keys; the app migrates those values at launch and writes a sanitized JSON file afterward.
- Direct mobile API calls cannot fully protect a provider key from a device owner. Use a backend proxy for a public production release, with user authentication, quotas, request validation, and provider keys stored server-side.
- Rotate any key that was accidentally committed or shared.
