# StudyEA

StudyEA is a Flutter study app with flashcards, spaced repetition (SM-2), quizzes, mind maps, progress tracking, TTS, AI-assisted card creation and PDF export. The interface uses a Neo-Brutalism style (cream, electric violet, lime, orange, hard shadows).

## Added in this revision

- OpenRouter chat-completions integration plus existing Gemini and Hugging Face options.
- AI study coach.
- Study file import from text, Markdown, CSV/TSV, DOCX and text-based PDFs; extracted content can be turned into cards by the configured AI provider. Scanned image-only PDFs require OCR and are not currently extracted.
- Listen mode to read cards one by one or sequentially.
- Voice engine selection: local Android TTS, Google Cloud Text-to-Speech, ElevenLabs, or automatic fallback.
- API secrets moved to `flutter_secure_storage` rather than exported in app JSON backups. Existing plaintext keys in an old StudyEA data file are migrated on startup when secure storage is available.
- GitHub Actions workflow to generate Android project files if needed, run analysis, build the release APK, and publish it as an artifact.

## AI setup

1. Open **Settings** and select **OpenRouter** as the AI provider.
2. Enter your OpenRouter API key in the password field.
3. Optionally set a model available to your OpenRouter account. The default is `openai/gpt-4o-mini`.
4. Keep the key private and set account limits on the OpenRouter side.

## Voice setup

PDF extraction uses Syncfusion Flutter PDF, which requires a Syncfusion commercial or eligible free Community license. Review the package license terms before distributing the app.

- **Automatic** prefers Google Cloud TTS when a Google key is configured, then ElevenLabs when its key is configured, and otherwise uses local device TTS.
- Google Cloud and ElevenLabs are optional services and may incur charges or have usage limits. Their keys are entered in Settings.
- If the online engine fails, playback falls back to local device TTS.

## Key security note

Secrets are stored using the platform secure-storage plugin and excluded from StudyEA JSON backups and Git. However, a key used directly by a mobile app cannot be guaranteed secret from a sufficiently capable device owner or app reverse engineer. For production distribution, the strongest design is a small authenticated backend proxy that keeps provider keys on the server and applies per-user quotas. Do not embed real keys in source code, APK assets, or GitHub Actions logs.

## Build Android APK

The source archive may not include generated Android platform files. With Flutter installed locally:

```bash
flutter create --platforms=android --org app.studyea .
python3 tools/patch_android.py
flutter pub get
flutter analyze
flutter build apk --release
```

The APK is written to `build/app/outputs/flutter-apk/app-release.apk`.

Alternatively, push this folder to a GitHub repository on `main` or `master`, or manually run **Build StudyEA APK** from the Actions tab. Download the `studyea-release-apk` artifact after the workflow completes.


## Neo-Brutalism visual refresh

The shared UI primitives now use a restrained Neo-Brutalist system: warm cream surfaces,
near-black outlines, hard offset shadows, electric-purple primary actions, and lime accents.
The previous frosted-glass blur/gradient treatment was removed from shared cards so text
stays crisp and the UI is lighter to render. Dark mode uses charcoal surfaces and high-contrast
light outlines. Existing screen widgets continue to use the shared `NeuBox`, `NeuButton`,
`NeuField`, and `NeuPage` components.


## StudyEA visual palette

The app uses a shared Neo-Brutalism palette across screens: warm cream backgrounds, paper cards, electric violet primary actions, lime highlights, orange accents, coral status/error accents, and near-black outlines. Dark mode uses a coordinated plum-charcoal surface palette.

## Release signing (so updates install over old versions)

Create a keystore once: `keytool -genkey -v -keystore upload.jks -keyalg RSA -keysize 2048 -validity 10000 -alias upload`
Then add these GitHub repository secrets: `KEYSTORE_BASE64` (output of `base64 -w0 upload.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`. Keep the keystore file safe; losing it means you can no longer update the app.


## Revision 3 — design match, voices, LaTeX

- **New navigation:** Home · Library · Maps · Focus · More. The home screen shows a greeting (name asked in onboarding / Settings), the "today's session" card, progress and streak, coloured subject cards and shortcuts.
- **Review screen:** progress bar, stacked cards, "Show answer" button, coloured answer buttons, speed chip, auto-read toggle.
- **Focus tab:** dark timer (15/25/45/60), break handling, XP, and four looping ambient sounds (calm, rain, forest, ocean). The sounds are synthesised WAV loops in `assets/sounds/` and work offline.
- **Listen mode:** waveform while speaking, engine chips, speed slider.
- **LaTeX:** `$...$`, `$$...$$`, `\(...\)`, `\[...\]` render in cards, review, quiz, listen mode and the AI coach (`flutter_math_fork`). The card editor has a LaTeX toolbar and live preview. AI prompts ask for LaTeX and `extractJson` repairs single-backslash LaTeX that would otherwise corrupt JSON. Formulas are read aloud as words (`x^2` → "x squared"), in Arabic or English. PDF export prints formulas as raw LaTeX source.
- **Voice engines fixed:** playback now completes on stop (previously stopping an online voice hung for 3 minutes and then silently spoke with the local voice); failures are shown to the user instead of being swallowed; long text is chunked; speed control; Arabic voice availability check; `<queries>` for `TTS_SERVICE` added to the Android manifest patch (needed on Android 11+ for device TTS). Settings has a test button for each engine that reports the real error. Google Cloud TTS and ElevenLabs need their own keys and may be unreachable in some countries; the app then falls back to the device voice and tells you why.
