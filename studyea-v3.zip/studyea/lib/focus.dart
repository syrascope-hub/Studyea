import 'dart:async';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'neu.dart';
import 'store.dart';

/// Dark focus-timer tab with looping ambient sounds (generated, bundled in assets/sounds).
class FocusPage extends StatefulWidget {
  const FocusPage({super.key});
  @override
  State<FocusPage> createState() => _FocusPageState();
}

class _FocusPageState extends State<FocusPage> {
  Timer? _timer;
  DateTime? _endAt;
  bool running = false, focus = true;
  int total = 25 * 60, left = 25 * 60;
  final AudioPlayer _amb = AudioPlayer();
  double vol = .6;
  String playing = '';

  @override
  void initState() {
    super.initState();
    final s = context.read<Store>();
    total = s.focusMin * 60;
    left = total;
  }

  @override
  void dispose() {
    _timer?.cancel();
    _amb.dispose();
    super.dispose();
  }

  int get _breakMinutes => context.read<Store>().focusMin >= 45 ? 10 : 5;

  void _toggle() {
    if (running) {
      _timer?.cancel();
      setState(() => running = false);
      return;
    }
    _endAt = DateTime.now().add(Duration(seconds: left));
    setState(() => running = true);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) => _tick());
  }

  void _tick() {
    final end = _endAt;
    if (end == null) return;
    final ms = end.difference(DateTime.now()).inMilliseconds;
    if (ms <= 0) {
      _finish();
    } else if (mounted) {
      setState(() => left = (ms / 1000).ceil());
    }
  }

  void _finish({bool reward = true}) {
    _timer?.cancel();
    if (!mounted) return;
    final s = context.read<Store>();
    if (reward) HapticFeedback.heavyImpact();
    if (focus && reward) {
      s.focusTotal += total ~/ 60;
      s.addXp(total ~/ 60);
    }
    setState(() {
      focus = !focus;
      total = (focus ? s.focusMin : _breakMinutes) * 60;
      left = total;
      running = false;
    });
    if (reward) toast(context, focus ? s.tr('انتهت الاستراحة. جاهز لجلسة جديدة؟', 'Break over. Ready for another session?') : s.tr('أحسنت! حان وقت الاستراحة ☕', 'Great job! Time for a break ☕'));
  }

  void _reset() {
    _timer?.cancel();
    final s = context.read<Store>();
    setState(() {
      running = false;
      focus = true;
      total = s.focusMin * 60;
      left = total;
    });
  }

  void _setMinutes(int m) {
    if (running) return;
    final s = context.read<Store>();
    s.focusMin = m;
    s.changed();
    setState(() {
      focus = true;
      total = m * 60;
      left = total;
    });
  }

  Future<void> _setAmbient(String id) async {
    try {
      if (playing == id) {
        await _amb.stop();
        if (mounted) setState(() => playing = '');
        return;
      }
      await _amb.setReleaseMode(ReleaseMode.loop);
      await _amb.setVolume(vol);
      await _amb.play(AssetSource('sounds/$id.wav'));
      if (mounted) setState(() => playing = id);
    } catch (e) {
      if (mounted) toast(context, '$e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    return Theme(
      data: Theme.of(context).copyWith(brightness: Brightness.dark),
      child: Builder(builder: (context) {
        final d = isDark(context);
        final mm = (left ~/ 60).toString().padLeft(2, '0');
        final ss = (left % 60).toString().padLeft(2, '0');
        final sounds = [
          ('calm', Icons.music_note_rounded, s.tr('موسيقى هادئة', 'Calm music')),
          ('rain', Icons.grain_rounded, s.tr('مطر', 'Rain')),
          ('forest', Icons.park_rounded, s.tr('غابة', 'Forest')),
          ('ocean', Icons.water_rounded, s.tr('محيط', 'Ocean')),
        ];
        return NeuPage(
          title: s.tr('وضع التركيز', 'Focus mode'),
          back: false,
          body: ListView(padding: const EdgeInsets.all(18), children: [
            Center(
              child: SizedBox(
                width: 250,
                height: 250,
                child: Stack(alignment: Alignment.center, children: [
                  SizedBox.expand(
                    child: CircularProgressIndicator(
                      value: total == 0 ? 0 : 1 - left / total,
                      strokeWidth: 14,
                      strokeCap: StrokeCap.round,
                      color: focus ? kAccent : kLime,
                      backgroundColor: Colors.white12,
                    ),
                  ),
                  Column(mainAxisSize: MainAxisSize.min, children: [
                    Text('$mm:$ss', style: TextStyle(fontSize: 54, fontWeight: FontWeight.w900, color: neuText(d))),
                    Text(focus ? s.tr('جلسة تركيز', 'Focus session') : s.tr('استراحة', 'Break'),
                        style: TextStyle(fontSize: 15, color: neuText(d).withValues(alpha: .7))),
                  ]),
                ]),
              ),
            ),
            const SizedBox(height: 22),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              NeuIcon(Icons.restart_alt_rounded, onTap: _reset),
              const SizedBox(width: 18),
              NeuButton(
                filled: true,
                radius: 60,
                padding: const EdgeInsets.all(22),
                onTap: _toggle,
                child: Icon(running ? Icons.pause_rounded : Icons.play_arrow_rounded, size: 38),
              ),
              const SizedBox(width: 18),
              NeuIcon(Icons.skip_next_rounded, onTap: running || left != total ? () => _finish(reward: false) : null),
            ]),
            const SizedBox(height: 22),
            Wrap(alignment: WrapAlignment.center, spacing: 10, runSpacing: 10, children: [
              for (final m in const [15, 25, 45, 60])
                GestureDetector(
                  onTap: () => _setMinutes(m),
                  child: NeuBox(
                    inset: s.focusMin == m,
                    radius: 14,
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    child: Text('$m ${s.tr('د', 'min')}',
                        style: TextStyle(fontWeight: FontWeight.w800, color: s.focusMin == m ? kLime : neuText(d))),
                  ),
                ),
            ]),
            const SizedBox(height: 8),
            Center(
              child: Text(s.tr('إجمالي التركيز: ${s.focusTotal} دقيقة', 'Total focus: ${s.focusTotal} min'),
                  style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
            ),
            const SizedBox(height: 22),
            Text(s.tr('الأصوات الخلفية', 'Background sounds'), style: TextStyle(fontSize: 16, fontWeight: FontWeight.w900, color: neuText(d))),
            const SizedBox(height: 10),
            Row(children: [
              for (final x in sounds)
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 4),
                    child: GestureDetector(
                      onTap: () => _setAmbient(x.$1),
                      child: NeuBox(
                        radius: 16,
                        depth: playing == x.$1 ? 0 : 4,
                        color: playing == x.$1 ? kAccent : null,
                        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 4),
                        child: Column(children: [
                          Icon(x.$2, color: playing == x.$1 ? Colors.white : neuText(d)),
                          const SizedBox(height: 4),
                          Text(x.$3,
                              textAlign: TextAlign.center,
                              maxLines: 2,
                              style: TextStyle(fontSize: 10, fontWeight: FontWeight.w800, color: playing == x.$1 ? Colors.white : neuText(d))),
                        ]),
                      ),
                    ),
                  ),
                ),
            ]),
            Row(children: [
              Icon(Icons.volume_down_rounded, color: neuText(d).withValues(alpha: .6)),
              Expanded(
                child: Slider(
                  value: vol,
                  activeColor: kAccent,
                  onChanged: (v) {
                    setState(() => vol = v);
                    _amb.setVolume(v);
                  },
                ),
              ),
              Icon(Icons.volume_up_rounded, color: neuText(d).withValues(alpha: .6)),
            ]),
            Text(
                s.tr('الأصوات مولّدة داخل التطبيق وتعمل بدون إنترنت.', 'Sounds are generated inside the app and work offline.'),
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .5))),
          ]),
        );
      }),
    );
  }
}
