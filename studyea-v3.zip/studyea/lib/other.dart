import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neu.dart';
import 'store.dart';
import 'study.dart';
import 'extras.dart';
import 'notify.dart';
import 'tts.dart';
import 'dart:convert';
import 'package:flutter/services.dart';

class StatsPage extends StatelessWidget {
  const StatsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final now = DateTime.now();
    final days = [for (var i = 6; i >= 0; i--) now.subtract(Duration(days: i))];
    final vals = [for (final x in days) s.byDay[dayKey(x)] ?? 0];
    final mx = vals.fold<int>(1, (a, b) => b > a ? b : a);
    final nNew = s.cards.where((c) => c.isNew).length;
    final nMature = s.cards.where((c) => c.interval >= 21).length;
    final nLearn = s.cards.length - nNew - nMature;
    final hardest = [...s.cards]..sort((a, b) => b.lapses.compareTo(a.lapses));

    Widget tile(String label, String v, IconData i) => Expanded(
          child: NeuBox(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
            child: Column(children: [
              Icon(i, color: kAccent),
              const SizedBox(height: 6),
              Text(v, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: neuText(d))),
              Text(label,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .6))),
            ]),
          ),
        );
    Widget h(String t) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 10),
        child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: neuText(d))));

    return NeuPage(
      title: s.t('stats'),
      actions: [
        NeuIcon(Icons.timer_rounded, size: 20,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PomodoroPage())))
      ],
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          tile(s.t('streak'), '${s.streak}', Icons.local_fire_department_rounded),
          const SizedBox(width: 12),
          tile('${s.t('level')}', '${s.level}', Icons.military_tech_rounded),
          const SizedBox(width: 12),
          tile(s.t('xp'), '${s.xp}', Icons.bolt_rounded),
        ]),
        h('${s.t('dailyGoal')}: ${s.today}/${s.dailyGoal}'),
        NeuBox(
          inset: true,
          radius: 12,
          padding: const EdgeInsets.all(4),
          child: LayoutBuilder(
            builder: (c, k) => Align(
              alignment: AlignmentDirectional.centerStart,
              child: Container(
                height: 14,
                width: k.maxWidth * (s.dailyGoal == 0 ? 0 : (s.today / s.dailyGoal).clamp(0, 1).toDouble()),
                decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(8)),
              ),
            ),
          ),
        ),
        h(s.t('last7')),
        NeuBox(
          child: SizedBox(
            height: 120,
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              for (var i = 0; i < 7; i++)
                Expanded(
                  child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Text('${vals[i]}', style: TextStyle(fontSize: 10, color: neuText(d))),
                    const SizedBox(height: 4),
                    Container(
                      height: 8 + 70.0 * vals[i] / mx,
                      margin: const EdgeInsets.symmetric(horizontal: 6),
                      decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(8)),
                    ),
                    const SizedBox(height: 4),
                    Text('${days[i].day}', style: TextStyle(fontSize: 10, color: neuText(d).withValues(alpha: .6))),
                  ]),
                ),
            ]),
          ),
        ),
        h(s.t('mastery')),
        Row(children: [
          tile(s.t('mNew'), '$nNew', Icons.fiber_new_rounded),
          const SizedBox(width: 12),
          tile(s.t('mLearning'), '$nLearn', Icons.school_rounded),
          const SizedBox(width: 12),
          tile(s.t('mMature'), '$nMature', Icons.verified_rounded),
        ]),
        h(s.t('badges')),
        Wrap(spacing: 10, runSpacing: 10, children: [
          for (final b in [
            ('badge_first', s.totalReviews >= 1),
            ('badge_r100', s.totalReviews >= 100),
            ('badge_streak7', s.streak >= 7),
            ('badge_cards100', s.cards.length >= 100),
            ('badge_lvl5', s.level >= 5),
          ])
            Opacity(
              opacity: b.$2 ? 1 : .35,
              child: NeuBox(
                inset: !b.$2,
                radius: 14,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(Icons.workspace_premium_rounded, size: 18, color: b.$2 ? Colors.amber.shade700 : null),
                  const SizedBox(width: 6),
                  Text(s.t(b.$1), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                ]),
              ),
            ),
        ]),
        h(s.t('hardest')),
        for (final c in hardest.where((c) => c.lapses > 0).take(5))
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: NeuBox(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(
                    child: Text(cardQA(c).$1,
                        maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: neuText(d)))),
                Text('${c.lapses} ✗', style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w700)),
              ]),
            ),
          ),
      ]),
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final gk = TextEditingController(text: context.read<Store>().geminiKey);
  late final hk = TextEditingController(text: context.read<Store>().hfKey);
  late final ork = TextEditingController(text: context.read<Store>().openRouterKey);
  late final gtts = TextEditingController(text: context.read<Store>().googleTtsKey);
  late final elk = TextEditingController(text: context.read<Store>().elevenLabsKey);
  late final mdl = TextEditingController(text: context.read<Store>().model);
  late final nameC = TextEditingController(text: context.read<Store>().userName);
  bool savingKeys = false;
  String testing = '';

  Future<void> _test(String engine) async {
    final st = context.read<Store>();
    setState(() => testing = engine);
    final err = await testVoice(engine, googleKey: gtts.text, elevenLabsKey: elk.text, arabic: st.lang == 'ar');
    if (!mounted) return;
    setState(() => testing = '');
    if (err == null) {
      toast(context, st.tr('✓ المحرك يعمل', '✓ Engine works'));
    } else {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: neuBg(isDark(context)),
          title: Text(st.tr('تعذّر تشغيل المحرك', 'Engine failed')),
          content: SingleChildScrollView(child: SelectableText(err)),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(st.t('ok')))],
        ),
      );
    }
  }

  Future<void> _saveKeys() async {
    setState(() => savingKeys = true);
    try {
      final store = context.read<Store>();
      await store.updateSecret('openRouterKey', ork.text);
      await store.updateSecret('geminiKey', gk.text);
      await store.updateSecret('hfKey', hk.text);
      await store.updateSecret('googleTtsKey', gtts.text);
      await store.updateSecret('elevenLabsKey', elk.text);
      if (mounted) toast(context, 'تم حفظ المفاتيح في التخزين الآمن.');
    } catch (e) {
      if (mounted) toast(context, 'تعذر حفظ المفاتيح: $e');
    } finally {
      if (mounted) setState(() => savingKeys = false);
    }
  }

  @override
  void dispose() {
    gk.dispose();
    hk.dispose();
    ork.dispose();
    gtts.dispose();
    elk.dispose();
    mdl.dispose();
    nameC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    Widget h(String t) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d))));
    Widget seg(List<(String, String)> items, String cur, void Function(String) on) => Wrap(spacing: 10, children: [
          for (final i in items)
            GestureDetector(
              onTap: () => on(i.$1),
              child: NeuBox(
                inset: cur == i.$1,
                radius: 14,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Text(i.$2,
                    style: TextStyle(fontWeight: FontWeight.w700, color: cur == i.$1 ? kAccent : neuText(d))),
              ),
            ),
        ]);
    return NeuPage(
      title: s.t('settings'),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        h(s.t('language')),
        seg([('ar', 'العربية'), ('en', 'English')], s.lang, (v) {
          s.lang = v;
          s.changed();
        }),
        h(s.t('theme')),
        Wrap(spacing: 12, children: [
          for (var i = 0; i < kThemeCount; i++)
            GestureDetector(
              onTap: () {
                s.themeIdx = i;
                gTheme = i;
                s.changed();
              },
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: themeSwatch(i),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: neuLo(d), width: s.themeIdx == i ? 5 : 2.5),
                ),
              ),
            ),
        ]),
        h(s.t('fontSize')),
        seg([('0.9', 'S'), ('1.0', 'M'), ('1.15', 'L'), ('1.3', 'XL')], s.fontScale.toString(), (v) {
          s.fontScale = double.parse(v);
          s.changed();
        }),
        h(s.t('reminder')),
        Row(children: [
          NeuButton(
            filled: s.remindOn,
            onTap: () async {
              if (s.remindOn) {
                s.remindOn = false;
                await disableReminder();
              } else {
                final ok = await enableReminder(s.remindH, s.remindM, s.t('remTitle'), s.t('remBody'));
                s.remindOn = ok;
                if (!ok && context.mounted) toast(context, s.t('permDenied'));
              }
              s.changed();
            },
            child: Text(s.remindOn ? s.t('on') : s.t('off')),
          ),
          const SizedBox(width: 12),
          NeuButton(
            onTap: () async {
              final t = await showTimePicker(
                  context: context, initialTime: TimeOfDay(hour: s.remindH, minute: s.remindM));
              if (t == null) return;
              s.remindH = t.hour;
              s.remindM = t.minute;
              if (s.remindOn) await enableReminder(t.hour, t.minute, s.t('remTitle'), s.t('remBody'));
              s.changed();
            },
            child: Text('${s.remindH.toString().padLeft(2, '0')}:${s.remindM.toString().padLeft(2, '0')}'),
          ),
        ]),
        h(s.t('darkMode')),
        seg([('0', '☀'), ('1', '🌙')], s.dark ? '1' : '0', (v) {
          s.dark = v == '1';
          s.changed();
        }),
        h(s.t('dailyGoal')),
        Row(children: [
          NeuIcon(Icons.remove_rounded, onTap: () {
            if (s.dailyGoal > 5) {
              s.dailyGoal -= 5;
              s.changed();
            }
          }),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text('${s.dailyGoal}',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: neuText(d)))),
          NeuIcon(Icons.add_rounded, onTap: () {
            s.dailyGoal += 5;
            s.changed();
          }),
        ]),
        h(s.t('aiProvider')),
        seg([('openrouter', 'OpenRouter'), ('gemini', 'Gemini'), ('hf', 'Hugging Face')], s.provider, (v) {
          if (s.provider != v) {
            s.provider = v;
            s.model = '';
            mdl.clear();
            s.changed();
          }
        }),
        h('OpenRouter API Key'),
        NeuField(controller: ork, obscure: true),
        Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text('النموذج الافتراضي: openai/gpt-4o-mini. يمكنك إدخال اسم نموذج متاح من OpenRouter أدناه.', style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
        ),
        h(s.t('geminiKey')),
        NeuField(controller: gk, obscure: true),
        h(s.t('hfKey')),
        NeuField(controller: hk, obscure: true),
        h('مفتاح Google Cloud Text-to-Speech (اختياري)'),
        NeuField(controller: gtts, obscure: true),
        h('مفتاح ElevenLabs (اختياري)'),
        NeuField(controller: elk, obscure: true),
        const SizedBox(height: 12),
        NeuButton(
          filled: true,
          onTap: savingKeys ? null : _saveKeys,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (savingKeys) const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            else const Icon(Icons.lock_rounded, size: 18),
            const SizedBox(width: 8),
            Text(savingKeys ? 'جارٍ الحفظ…' : 'حفظ مفاتيح API بشكل آمن'),
          ]),
        ),
        h(s.tr('اسمك', 'Your name')),
        NeuField(controller: nameC, hint: s.tr('يظهر في الشاشة الرئيسية', 'Shown on the home screen'), onChanged: (v) {
          s.userName = v.trim();
          s.changed();
        }),
        h('محرك القراءة الصوتية'),
        seg([('auto', 'تلقائي'), ('local', 'محلي'), ('google', 'Google'), ('elevenlabs', 'ElevenLabs')], s.voiceEngine, (v) => s.setVoiceEngine(v)),
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text('الوضع التلقائي يختار Google عند توفر مفتاحه، ثم ElevenLabs، وإلا يستخدم صوت الجهاز. تتوفر مفاتيح الصوت عبر الإنترنت اختياريًا.', style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
        ),
        const SizedBox(height: 12),
        Text(s.tr('اختبار المحركات', 'Test engines'), style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d))),
        const SizedBox(height: 8),
        Wrap(spacing: 10, runSpacing: 10, children: [
          for (final e in const [('local', 'الجهاز / Device'), ('google', 'Google'), ('elevenlabs', 'ElevenLabs')])
            NeuButton(
              onTap: testing.isEmpty ? () => _test(e.$1) : null,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                if (testing == e.$1)
                  const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                else
                  const Icon(Icons.play_arrow_rounded, size: 18),
                const SizedBox(width: 6),
                Text(e.$2, style: const TextStyle(fontSize: 12)),
              ]),
            ),
        ]),
        const SizedBox(height: 12),
        Row(children: [
          Text(s.tr('السرعة', 'Speed'), style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d))),
          Expanded(
            child: Slider(
              value: s.voiceSpeed,
              min: 0.5,
              max: 2.0,
              divisions: 12,
              activeColor: kAccent,
              label: '${s.voiceSpeed.toStringAsFixed(2)}x',
              onChanged: (v) => s.setVoiceSpeed(v),
            ),
          ),
          Text('${s.voiceSpeed.toStringAsFixed(2)}x', style: TextStyle(color: neuText(d))),
        ]),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          activeColor: kAccent,
          title: Text(s.tr('قراءة البطاقات تلقائيًا أثناء المراجعة', 'Auto-read cards during review'), style: TextStyle(color: neuText(d), fontWeight: FontWeight.w700)),
          value: s.autoSpeak,
          onChanged: (v) {
            s.autoSpeak = v;
            s.changed();
          },
        ),
        Text(s.tr('تُقرأ الصيغ المكتوبة بـ LaTeX كلمات (مثل: x تربيع زائد 2). Google وElevenLabs قد لا تعمل في بعض الدول؛ عندها يعود التطبيق لصوت الجهاز ويعرض سبب الفشل.', 'LaTeX formulas are read as words. Google and ElevenLabs may be unreachable in some countries; the app then falls back to the device voice and shows why.'),
            style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
        h(s.t('aiModel')),
        NeuField(controller: mdl, onChanged: (v) {
          s.model = v.trim();
          s.changed();
        }),
        h('Backup'),
        Wrap(spacing: 10, runSpacing: 10, children: [
          NeuButton(
              onTap: () async {
                await Clipboard.setData(ClipboardData(text: jsonEncode(s.toMap())));
                if (context.mounted) toast(context, s.t('copied'));
              },
              child: Text(s.t('backupCopy'))),
          NeuButton(
              onTap: () async {
                final d = await Clipboard.getData('text/plain');
                try {
                  s.fromMap(jsonDecode(d?.text ?? ''));
                  s.changed();
                  if (context.mounted) toast(context, s.t('restored'));
                } catch (e) {
                  if (context.mounted) toast(context, e.toString());
                }
              },
              child: Text(s.t('backupRestore'))),
        ]),
        const SizedBox(height: 20),
      ]),
    );
  }
}
