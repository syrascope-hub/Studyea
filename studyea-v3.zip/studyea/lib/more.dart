import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neu.dart';
import 'other.dart';
import 'store.dart';
import 'study_tools.dart';

class MorePage extends StatelessWidget {
  const MorePage({super.key});

  void _push(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    Widget item(IconData icon, Color color, String title, String sub, VoidCallback onTap) => Padding(
          padding: const EdgeInsets.only(bottom: 14),
          child: GestureDetector(
            onTap: onTap,
            child: NeuBox(
              child: Row(children: [
                NeuBox(
                  radius: 14,
                  depth: 0,
                  color: color,
                  padding: const EdgeInsets.all(11),
                  child: Icon(icon, color: onColor(color)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(title, style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800, color: neuText(d))),
                    Text(sub, style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
                  ]),
                ),
                Icon(Icons.chevron_right_rounded, color: neuText(d).withValues(alpha: .5)),
              ]),
            ),
          ),
        );
    return NeuPage(
      title: s.tr('المزيد', 'More'),
      back: false,
      body: ListView(padding: const EdgeInsets.all(16), children: [
        item(Icons.psychology_alt_rounded, kAccent, s.tr('المدرب الذكي', 'AI coach'),
            s.tr('اسأل واشرح مع دعم المعادلات LaTeX', 'Ask and learn, with LaTeX math'), () => _push(context, const StudyCoachPage())),
        item(Icons.upload_file_rounded, kLime, s.tr('استيراد ملف', 'Import a file'),
            s.tr('PDF · DOCX · TXT · MD · CSV', 'PDF · DOCX · TXT · MD · CSV'), () {
          final target = s.decks.isEmpty ? s.addDeck(s.t('general')) : s.decks.first;
          _push(context, StudyFileImportPage(deckId: target.id));
        }),
        item(Icons.headphones_rounded, kOrange, s.tr('وضع الاستماع', 'Listen mode'),
            s.tr('استمع للبطاقات بمحركات صوت متعددة', 'Hear your cards with multiple voice engines'), () {
          if (s.cards.isEmpty) {
            toast(context, s.tr('أضف بطاقات قبل بدء وضع الاستماع.', 'Add cards before using Listen mode.'));
            return;
          }
          _push(context, ListenModePage(cards: List.of(s.cards)));
        }),
        item(Icons.insights_rounded, kSky, s.t('stats'), s.tr('التقدم والأوسمة والمستوى', 'Progress, badges and level'),
            () => _push(context, const StatsPage())),
        item(Icons.tune_rounded, kCoral, s.t('settings'), s.tr('الذكاء الاصطناعي، الصوت، المظهر', 'AI, voice, appearance'),
            () => _push(context, const SettingsPage())),
      ]),
    );
  }
}
