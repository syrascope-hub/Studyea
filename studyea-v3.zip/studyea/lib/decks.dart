import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';
import 'ai.dart';
import 'models.dart';
import 'neu.dart';
import 'store.dart';
import 'study.dart';
import 'extras.dart';
import 'tts.dart';
import 'tex.dart';
import 'study_tools.dart';

class DecksPage extends StatefulWidget {
  const DecksPage({super.key});
  @override
  State<DecksPage> createState() => _DecksPageState();
}

class _DecksPageState extends State<DecksPage> {
  final q = TextEditingController();

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final query = q.text.trim().toLowerCase();
    final roots = s.children(null);
    final found = query.isEmpty
        ? <CardM>[]
        : s.cards
            .where((c) => '${c.front} ${c.back} ${c.tags.join(' ')}'.toLowerCase().contains(query))
            .toList();
    return NeuPage(
      title: 'Studyea',
      back: false,
      actions: [
        NeuIcon(Icons.add_rounded, filled: true, onTap: () async {
          final n = await askText(context, s.t('newDeck'), hint: s.t('deckName'));
          if (n != null && n.isNotEmpty) s.addDeck(n);
        })
      ],
      body: ListView(padding: const EdgeInsets.all(16), children: [
        NeuField(controller: q, hint: s.t('search'), onChanged: (_) => setState(() {})),
        const SizedBox(height: 14),
        Wrap(spacing: 8, runSpacing: 8, children: [
          NeuButton(
            filled: true,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            onTap: () {
              final target = s.decks.isEmpty ? s.addDeck(s.t('general')) : s.decks.first;
              Navigator.push(context, MaterialPageRoute(builder: (_) => StudyFileImportPage(deckId: target.id)));
            },
            child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.upload_file_rounded, size: 18), SizedBox(width: 6), Text('استيراد ملف')]),
          ),
          NeuButton(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const StudyCoachPage())),
            child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.psychology_alt_rounded, size: 18), SizedBox(width: 6), Text('مدرب AI')]),
          ),
          NeuButton(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            onTap: () {
              if (s.cards.isEmpty) {
                toast(context, 'أضف بطاقات قبل بدء وضع الاستماع.');
                return;
              }
              Navigator.push(context, MaterialPageRoute(builder: (_) => ListenModePage(cards: List.of(s.cards))));
            },
            child: const Row(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.headphones_rounded, size: 18), SizedBox(width: 6), Text('وضع الاستماع')]),
          ),
        ]),
        const SizedBox(height: 16),
        if (query.isNotEmpty)
          for (final c in found) CardTile(card: c)
        else if (roots.isEmpty)
          Padding(
            padding: const EdgeInsets.all(40),
            child: Center(child: Text(s.t('noDecks'), style: TextStyle(color: neuText(d).withValues(alpha: .6)))),
          )
        else
          for (final dk in roots) DeckTile(deck: dk),
      ]),
    );
  }
}

class DeckTile extends StatelessWidget {
  final Deck deck;
  const DeckTile({super.key, required this.deck});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final total = s.cardsOf(deck.id).length;
    final due = s.dueCount(deck.id);
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: GestureDetector(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => DeckPage(deckId: deck.id))),
        child: NeuBox(
          child: Row(children: [
            NeuBox(
              radius: 14,
              depth: 0,
              color: deckColor(deck),
              padding: const EdgeInsets.all(12),
              child: Icon(Icons.style_rounded, color: onColor(deckColor(deck))),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(deck.name,
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: neuText(d))),
                const SizedBox(height: 4),
                Text('$total ${s.t('cards')} · $due ${s.t('due')}',
                    style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
              ]),
            ),
            Icon(Icons.chevron_right_rounded, color: neuText(d).withValues(alpha: .5)),
          ]),
        ),
      ),
    );
  }
}

class CardTile extends StatelessWidget {
  final CardM card;
  const CardTile({super.key, required this.card});
  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    final qa = cardQA(card);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: GestureDetector(
        onTap: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => CardEditor(deckId: card.deckId, card: card))),
        child: NeuBox(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            if (card.image != null && File(card.image!).existsSync())
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 12),
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.file(File(card.image!), width: 48, height: 48, fit: BoxFit.cover)),
              ),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                RichMath(qa.$1, maxLines: 2, style: TextStyle(fontWeight: FontWeight.w700, color: neuText(d))),
                const SizedBox(height: 2),
                RichMath(qa.$2, maxLines: 1, style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
              ]),
            ),
            NeuIcon(Icons.volume_up_rounded, size: 18, onTap: () => speak(card.front)),
          ]),
        ),
      ),
    );
  }
}

class DeckPage extends StatelessWidget {
  final String deckId;
  const DeckPage({super.key, required this.deckId});

  Future<void> _dups(BuildContext context, Store s, List<CardM> all) async {
    final g = <String, List<CardM>>{};
    for (final c in all) {
      g.putIfAbsent(cardQA(c).$1.trim().toLowerCase(), () => []).add(c);
    }
    final extras = <CardM>[];
    for (final l in g.values) {
      if (l.length > 1) extras.addAll(l.skip(1));
    }
    if (extras.isEmpty) {
      toast(context, s.t('noDups'));
      return;
    }
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: neuBg(isDark(context)),
        content: Text('${extras.length} ${s.t('dupsFound')}', style: TextStyle(color: neuText(isDark(context)))),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('cancel'))),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('delDups'))),
        ],
      ),
    );
    if (ok == true) {
      final ids = extras.map((e) => e.id).toSet();
      s.cards.removeWhere((c) => ids.contains(c.id));
      s.changed();
    }
  }

  Future<void> _pdf(BuildContext context, Store s, Deck dk) async {
    final list = s.cardsOf(dk.id);
    pw.Font? font;
    try {
      font = await PdfGoogleFonts.notoSansArabicRegular();
    } catch (_) {}
    final doc = pw.Document(theme: font != null ? pw.ThemeData.withFont(base: font, bold: font) : null);
    final rtl = s.lang == 'ar';
    doc.addPage(pw.MultiPage(
      pageFormat: PdfPageFormat.a4,
      textDirection: rtl ? pw.TextDirection.rtl : pw.TextDirection.ltr,
      build: (c) => [
        pw.Text(dk.name, style: const pw.TextStyle(fontSize: 22)),
        pw.SizedBox(height: 12),
        pw.Table(
          border: pw.TableBorder.all(color: PdfColors.grey500),
          children: [
            for (final c in list)
              pw.TableRow(children: [
                pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text(cardQA(c).$1)),
                pw.Padding(padding: const pw.EdgeInsets.all(6), child: pw.Text(cardQA(c).$2)),
              ]),
          ],
        ),
      ],
    ));
    await Printing.layoutPdf(onLayout: (_) => doc.save());
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final dk = s.deck(deckId);
    if (dk == null) return const Scaffold();
    final d = isDark(context);
    final all = s.cardsOf(dk.id);
    final own = s.cardsOf(dk.id, recursive: false);
    final now = DateTime.now().millisecondsSinceEpoch;
    final due = all.where((c) => c.due <= now).toList();
    void open(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));

    Widget action(IconData i, String label, VoidCallback? f, {bool filled = false}) => NeuButton(
          onTap: f,
          filled: filled,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          child: Row(mainAxisSize: MainAxisSize.min, children: [Icon(i, size: 18), const SizedBox(width: 6), Text(label)]),
        );

    return NeuPage(
      title: dk.name,
      actions: [
        NeuIcon(Icons.edit_rounded, size: 18, onTap: () async {
          final n = await askText(context, s.t('rename'), initial: dk.name);
          if (n != null && n.isNotEmpty) s.renameDeck(dk, n);
        }),
        NeuIcon(Icons.delete_outline_rounded, size: 18, onTap: () async {
          if (await confirm(context)) {
            s.deleteDeck(dk.id);
            if (context.mounted) Navigator.pop(context);
          }
        }),
      ],
      bottom: Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
        child: Row(children: [
          Expanded(
            child: NeuButton(
              filled: true,
              onTap: () => open(CardEditor(deckId: dk.id)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.add_rounded),
                const SizedBox(width: 6),
                Text(s.t('addCard')),
              ]),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: NeuButton(
              onTap: () => open(ImportPage(deckId: dk.id)),
              child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.text_snippet_rounded),
                const SizedBox(width: 6),
                Text(s.t('importText')),
              ]),
            ),
          ),
        ]),
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Wrap(spacing: 10, runSpacing: 10, children: [
          action(Icons.play_arrow_rounded, '${s.t('studyNow')} (${due.length})',
              due.isEmpty ? null : () => open(ReviewPage(cards: due)),
              filled: true),
          action(Icons.bolt_rounded, s.t('cram'), all.isEmpty ? null : () => open(ReviewPage(cards: all, cram: true))),
          action(Icons.quiz_rounded, s.t('quiz'), all.length < 2 ? null : () => open(QuizPage(cards: all))),
          action(Icons.rule_rounded, s.t('quizTf'), all.length < 2 ? null : () => open(QuizPage(cards: all, tf: true))),
          action(Icons.content_copy_rounded, s.t('dups'), all.length < 2 ? null : () => _dups(context, s, all)),
          action(Icons.extension_rounded, s.t('match'), all.length < 2 ? null : () => open(MatchPage(cards: all))),
          action(Icons.picture_as_pdf_rounded, s.t('exportDeck'), all.isEmpty ? null : () => _pdf(context, s, dk)),
        ]),
        const SizedBox(height: 22),
        Row(children: [
          Expanded(
              child: Text(s.t('subdecks'),
                  style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: neuText(d)))),
          NeuIcon(Icons.create_new_folder_rounded, size: 18, onTap: () async {
            final n = await askText(context, s.t('addSubdeck'), hint: s.t('deckName'));
            if (n != null && n.isNotEmpty) s.addDeck(n, dk.id);
          }),
        ]),
        const SizedBox(height: 12),
        for (final c in s.children(dk.id)) DeckTile(deck: c),
        const SizedBox(height: 10),
        Text('${s.t('cards')} (${own.length})',
            style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: neuText(d))),
        const SizedBox(height: 12),
        if (own.isEmpty)
          Padding(
              padding: const EdgeInsets.all(24),
              child: Center(child: Text(s.t('noCards'), style: TextStyle(color: neuText(d).withValues(alpha: .6)))))
        else
          for (final c in own) CardTile(card: c),
      ]),
    );
  }
}

class CardEditor extends StatefulWidget {
  final String deckId;
  final CardM? card;
  const CardEditor({super.key, required this.deckId, this.card});
  @override
  State<CardEditor> createState() => _CardEditorState();
}

class _CardEditorState extends State<CardEditor> {
  late final front = TextEditingController(text: widget.card?.front);
  late final back = TextEditingController(text: widget.card?.back);
  late final opts = TextEditingController(text: widget.card?.options.join('\n'));
  late final tags = TextEditingController(text: widget.card?.tags.join(', '));
  late String type = widget.card?.type ?? 'basic';
  final fnFront = FocusNode();
  final fnBack = FocusNode();
  late TextEditingController active = front;
  String? image;
  bool busy = false;

  @override
  void initState() {
    super.initState();
    image = widget.card?.image;
    fnFront.addListener(() {
      if (fnFront.hasFocus) active = front;
    });
    fnBack.addListener(() {
      if (fnBack.hasFocus) active = back;
    });
    front.addListener(_refresh);
    back.addListener(_refresh);
  }

  void _refresh() {
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    front.removeListener(_refresh);
    back.removeListener(_refresh);
    fnFront.dispose();
    fnBack.dispose();
    front.dispose();
    back.dispose();
    opts.dispose();
    tags.dispose();
    super.dispose();
  }

  /// Inserts [snippet] at the cursor of the field being edited. '▮' marks where the cursor should land.
  void insertTex(String snippet) {
    final c = active;
    final caret = snippet.indexOf('▮');
    final clean = snippet.replaceAll('▮', '');
    final sel = c.selection;
    final at = sel.isValid && sel.start >= 0 ? sel.start : c.text.length;
    final end = sel.isValid && sel.end >= 0 ? sel.end : at;
    final txt = c.text.replaceRange(at, end, clean);
    c.value = TextEditingValue(text: txt, selection: TextSelection.collapsed(offset: at + (caret >= 0 ? caret : clean.length)));
  }

  Future<void> pick(ImageSource src) async {
    final s = context.read<Store>();
    final x = await ImagePicker().pickImage(source: src, maxWidth: 1024, imageQuality: 85);
    if (x == null) return;
    final p = await s.saveImage(await x.readAsBytes());
    setState(() => image = p);
  }

  Future<void> gen() async {
    final s = context.read<Store>();
    final prompt = front.text.trim().isNotEmpty ? front.text.trim() : back.text.trim();
    if (prompt.isEmpty) return;
    setState(() => busy = true);
    try {
      final b = await Ai(s).image(prompt.replaceAll(RegExp(r'\{\{|\}\}'), ''));
      final p = await s.saveImage(b);
      setState(() => image = p);
    } catch (e) {
      if (mounted) toast(context, e.toString());
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> examples() async {
    final s = context.read<Store>();
    final w = front.text.trim().replaceAll(RegExp(r'\{\{|\}\}'), '');
    if (w.isEmpty) return;
    setState(() => busy = true);
    try {
      final r = await Ai(s).examples(w);
      if (mounted) {
        await showDialog(
          context: context,
          builder: (ctx) => AlertDialog(
            backgroundColor: neuBg(isDark(context)),
            content: SingleChildScrollView(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                for (final e in r)
                  Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: Row(children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () {
                            back.text = back.text.isEmpty ? e : '${back.text}\n$e';
                            Navigator.pop(ctx);
                          },
                          child: NeuBox(padding: const EdgeInsets.all(10), child: Text(e)),
                        ),
                      ),
                      const SizedBox(width: 8),
                      NeuIcon(Icons.volume_up_rounded, size: 16, onTap: () => speak(e)),
                    ]),
                  ),
              ]),
            ),
          ),
        );
      }
    } catch (e) {
      if (mounted) toast(context, e.toString());
    }
    if (mounted) setState(() => busy = false);
  }

  Future<void> explain() async {
    final s = context.read<Store>();
    setState(() => busy = true);
    try {
      final r = await Ai(s).explain(front.text, back.text);
      if (mounted) {
        await showDialog(
            context: context,
            builder: (c) => AlertDialog(
                  backgroundColor: neuBg(isDark(context)),
                  content: SingleChildScrollView(child: RichMath(r, markdown: true, style: TextStyle(color: neuText(isDark(context))))),
                ));
      }
    } catch (e) {
      if (mounted) toast(context, e.toString());
    }
    if (mounted) setState(() => busy = false);
  }

  void save() {
    final s = context.read<Store>();
    if (front.text.trim().isEmpty) return;
    final o = opts.text.split('\n').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final tg = tags.text.split(RegExp('[,،]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    final c = widget.card;
    if (c == null) {
      s.addCard(CardM(
          id: newId(), deckId: widget.deckId, type: type, front: front.text.trim(), back: back.text.trim(),
          options: o, tags: tg, image: image));
    } else {
      c
        ..type = type
        ..front = front.text.trim()
        ..back = back.text.trim()
        ..options = o
        ..tags = tg
        ..image = image;
      s.changed();
    }
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    Widget label(String k) => Padding(
        padding: const EdgeInsets.only(top: 14, bottom: 6),
        child: Text(s.t(k), style: TextStyle(fontWeight: FontWeight.w700, color: neuText(d))));
    return NeuPage(
      title: widget.card == null ? s.t('addCard') : s.t('editCard'),
      actions: [
        if (widget.card != null)
          NeuIcon(Icons.delete_outline_rounded, size: 18, onTap: () async {
            if (await confirm(context)) {
              s.deleteCard(widget.card!);
              if (context.mounted) Navigator.pop(context);
            }
          }),
      ],
      bottom: Padding(
        padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
        child: SizedBox(
          width: double.infinity,
          child: NeuButton(
              filled: true, onTap: busy ? null : save, child: Center(child: Text(s.t('save')))),
        ),
      ),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Wrap(spacing: 10, children: [
          for (final t in [('basic', 'tBasic'), ('cloze', 'tCloze'), ('mcq', 'tMcq')])
            GestureDetector(
              onTap: () => setState(() => type = t.$1),
              child: NeuBox(
                inset: type == t.$1,
                radius: 14,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Text(s.t(t.$2),
                    style: TextStyle(
                        fontWeight: FontWeight.w700, color: type == t.$1 ? kAccent : neuText(d))),
              ),
            ),
        ]),
        if (type == 'cloze')
          Padding(
              padding: const EdgeInsets.only(top: 8),
              child: Text(s.t('clozeHint'), style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6)))),
        label('front'),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: NeuField(controller: front, maxLines: 4, focusNode: fnFront)),
          const SizedBox(width: 8),
          NeuIcon(Icons.volume_up_rounded, size: 18, onTap: () => speak(front.text)),
        ]),
        if (type != 'cloze') ...[
          label('back'),
          Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(child: NeuField(controller: back, maxLines: 4, focusNode: fnBack)),
            const SizedBox(width: 8),
            NeuIcon(Icons.volume_up_rounded, size: 18, onTap: () => speak(back.text)),
          ]),
        ],
        const SizedBox(height: 10),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(children: [
            Padding(
              padding: const EdgeInsetsDirectional.only(end: 8),
              child: Text('LaTeX', style: TextStyle(fontWeight: FontWeight.w900, color: neuText(d))),
            ),
            for (final t in const [
              (r'$▮$', r'$ $'),
              (r'$x^{▮}$', 'x²'),
              (r'$x_{▮}$', 'x₁'),
              (r'$\frac{▮}{b}$', 'a/b'),
              (r'$\sqrt{▮}$', '√'),
              (r'$\int_{a}^{b} ▮\,dx$', '∫'),
              (r'$\sum_{i=1}^{n} ▮$', 'Σ'),
              (r'$\lim_{x \to ▮} f(x)$', 'lim'),
              (r'$\pi$', 'π'),
              (r'$\alpha$', 'α'),
              (r'$\theta$', 'θ'),
              (r'$\infty$', '∞'),
              (r'$\leq$', '≤'),
              (r'$\neq$', '≠'),
              (r'$$▮$$', r'$$ $$'),
            ])
              Padding(
                padding: const EdgeInsetsDirectional.only(end: 6),
                child: GestureDetector(
                  onTap: () => insertTex(t.$1),
                  child: NeuBox(
                    radius: 10,
                    depth: 2,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Text(t.$2, style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d))),
                  ),
                ),
              ),
          ]),
        ),
        if (hasMath(front.text) || hasMath(back.text))
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: NeuBox(
              inset: true,
              padding: const EdgeInsets.all(14),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Text(s.tr('معاينة', 'Preview'), style: const TextStyle(color: kAccent, fontWeight: FontWeight.w900, fontSize: 12)),
                const SizedBox(height: 6),
                RichMath(type == 'cloze' ? clozeFullText(front.text) : front.text, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: neuText(d))),
                if (type != 'cloze' && back.text.trim().isNotEmpty) ...[
                  const Divider(),
                  RichMath(back.text, style: TextStyle(fontSize: 18, color: kAccent, fontWeight: FontWeight.w700)),
                ],
              ]),
            ),
          ),
        if (type == 'mcq') ...[label('options'), NeuField(controller: opts, maxLines: 5)],
        label('tags'),
        NeuField(controller: tags),
        const SizedBox(height: 18),
        if (image != null && File(image!).existsSync())
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: NeuBox(
                padding: const EdgeInsets.all(8),
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(14),
                    child: Image.file(File(image!), height: 180, width: double.infinity, fit: BoxFit.cover))),
          ),
        Wrap(spacing: 10, runSpacing: 10, children: [
          NeuButton(onTap: () => pick(ImageSource.gallery), child: Text(s.t('gallery'))),
          NeuButton(onTap: () => pick(ImageSource.camera), child: Text(s.t('camera'))),
          NeuButton(onTap: busy ? null : gen, child: Text(s.t('aiImage'))),
          if (image != null) NeuButton(onTap: () => setState(() => image = null), child: Text(s.t('removeImage'))),
          NeuButton(onTap: busy ? null : explain, child: Text(s.t('explain'))),
          NeuButton(onTap: busy ? null : examples, child: Text(s.t('examples'))),
        ]),
        if (busy) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
      ]),
    );
  }
}

List<List<String>> parseLines(String text, String sep) {
  final out = <List<String>>[];
  for (final line in text.split('\n')) {
    final l = line.trim();
    if (l.isEmpty) continue;
    var used = sep;
    var i = sep.isNotEmpty ? l.indexOf(sep) : -1;
    if (i <= 0) {
      for (final c in ['\t', ' - ', ' – ', ' : ', ':', ';', '|', '=']) {
        i = l.indexOf(c);
        if (i > 0) {
          used = c;
          break;
        }
      }
    }
    if (i <= 0) continue;
    final a = l.substring(0, i).trim(), b = l.substring(i + used.length).trim();
    if (a.isNotEmpty && b.isNotEmpty) out.add([a, b]);
  }
  return out;
}

class ImportPage extends StatefulWidget {
  final String deckId;
  const ImportPage({super.key, required this.deckId});
  @override
  State<ImportPage> createState() => _ImportPageState();
}

class _ImportPageState extends State<ImportPage> {
  final text = TextEditingController();
  final sep = TextEditingController(text: ' - ');
  bool busy = false;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final list = parseLines(text.text, sep.text);
    return NeuPage(
      title: s.t('importText'),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        NeuField(controller: text, hint: s.t('pasteText'), maxLines: 10, onChanged: (_) => setState(() {})),
        const SizedBox(height: 12),
        Text(s.t('separator')),
        const SizedBox(height: 6),
        NeuField(controller: sep, onChanged: (_) => setState(() {})),
        const SizedBox(height: 12),
        Text('${s.t('preview')}: ${list.length}', style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(
            child: NeuButton(
              filled: true,
              onTap: list.isEmpty
                  ? null
                  : () {
                      s.addCards(widget.deckId, list);
                      Navigator.pop(context);
                    },
              child: Center(child: Text(s.t('importBtn'))),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: NeuButton(
              onTap: busy || text.text.trim().isEmpty
                  ? null
                  : () async {
                      setState(() => busy = true);
                      try {
                        final r = await Ai(s).cardsFromText(text.text);
                        s.addCards(widget.deckId, r);
                        if (mounted) Navigator.pop(context);
                      } catch (e) {
                        if (mounted) toast(context, e.toString());
                      }
                      if (mounted) setState(() => busy = false);
                    },
              child: Center(child: Text(s.t('aiCards'))),
            ),
          ),
        ]),
        if (busy) const Padding(padding: EdgeInsets.all(16), child: Center(child: CircularProgressIndicator())),
      ]),
    );
  }
}

String clozeFullText(String front) => front.replaceAllMapped(RegExp(r'\{\{(.*?)\}\}'), (m) => m.group(1) ?? '');
