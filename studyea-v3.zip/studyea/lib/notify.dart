import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/timezone.dart' as tz;

final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
bool _inited = false;

Future<void> _init() async {
  if (_inited) return;
  await _p.initialize(const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')));
  _inited = true;
}

/// Schedules a repeating daily notification. Returns false if permission denied.
Future<bool> enableReminder(int h, int m, String title, String body) async {
  try {
    await _init();
    final android = _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    final ok = await android?.requestNotificationsPermission() ?? true;
    if (ok == false) return false;
    final now = DateTime.now();
    var at = DateTime(now.year, now.month, now.day, h, m);
    if (!at.isAfter(now)) at = at.add(const Duration(days: 1));
    final t = tz.TZDateTime.from(at, tz.UTC);
    await _p.zonedSchedule(
      1,
      title,
      body,
      t,
      const NotificationDetails(
          android: AndroidNotificationDetails('daily', 'Daily reminder',
              importance: Importance.high, priority: Priority.high)),
      androidScheduleMode: AndroidScheduleMode.inexactAllowWhileIdle,
      uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
      matchDateTimeComponents: DateTimeComponents.time,
    );
    return true;
  } catch (_) {
    return false;
  }
}

Future<void> disableReminder() async {
  try {
    await _init();
    await _p.cancel(1);
  } catch (_) {}
}
