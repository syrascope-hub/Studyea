import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'tts.dart';
import 'package:uuid/uuid.dart';
import 'models.dart';
import 'strings.dart';

const _uuid = Uuid();
const _secretStorage = FlutterSecureStorage();
String newId() => _uuid.v4();

String dayKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class Store extends ChangeNotifier {
  List<Deck> decks = [];
  List<CardM> cards = [];
  List<MindMap> maps = [];
  String lang = 'ar', provider = 'openrouter', geminiKey = '', hfKey = '', openRouterKey = '', googleTtsKey = '', elevenLabsKey = '', model = '';
  String voiceEngine = 'auto';
  String userName = '', ambient = '', lastDeckId = '';
  double voiceSpeed = 1.0;
  bool autoSpeak = false;
  int focusMin = 25, focusTotal = 0;
  bool dark = false, loaded = false;
  int dailyGoal = 20, xp = 0, streak = 0, totalReviews = 0, themeIdx = 0, remindH = 20, remindM = 0;
  double fontScale = 1.0;
  bool remindOn = false, onboarded = false;
  String lastDay = '';
  Map<String, int> byDay = {};
  late Directory dir;
  bool _loadFailed = false;
  Future<void> _saveChain = Future.value();

  String t(String k) {
    final v = kStr[k];
    if (v == null) return k;
    return v[lang == 'ar' ? 0 : 1];
  }

  bool get ar => lang == 'ar';
  String tr(String a, String e) => lang == 'ar' ? a : e;

  int get level => xp ~/ 100 + 1;
  int get today => byDay[dayKey(DateTime.now())] ?? 0;

  Future<void> load() async {
    dir = await getApplicationDocumentsDirectory();
    await Directory('${dir.path}/images').create(recursive: true);
    final f = File('${dir.path}/studyea.json');
    Map<String, dynamic>? loadedMap;
    if (await f.exists()) {
      try {
        loadedMap = Map<String, dynamic>.from(jsonDecode(await f.readAsString()));
        fromMap(loadedMap);
      } catch (_) {
        // Never overwrite an unreadable data file: keep a copy and block saving this session.
        try {
          await f.copy('${dir.path}/studyea.corrupt-${DateTime.now().millisecondsSinceEpoch}.json');
        } catch (_) {}
        decks = [];
        cards = [];
        maps = [];
        _loadFailed = true;
      }
    }
    // Migrate older plaintext API keys to platform secure storage, then remove them from JSON.
    await _loadSecret('geminiKey', loadedMap?['geminiKey']?.toString() ?? '', (v) => geminiKey = v);
    await _loadSecret('hfKey', loadedMap?['hfKey']?.toString() ?? '', (v) => hfKey = v);
    await _loadSecret('openRouterKey', loadedMap?['openRouterKey']?.toString() ?? '', (v) => openRouterKey = v);
    await _loadSecret('googleTtsKey', loadedMap?['googleTtsKey']?.toString() ?? '', (v) => googleTtsKey = v);
    await _loadSecret('elevenLabsKey', loadedMap?['elevenLabsKey']?.toString() ?? '', (v) => elevenLabsKey = v);
    configureVoice(engine: voiceEngine, googleKey: googleTtsKey, elevenLabsKey: elevenLabsKey, speed: voiceSpeed);
    // Save a sanitized file without any secret material.
    await _save();
    loaded = true;
    notifyListeners();
  }

  void fromMap(Map<String, dynamic> j) {
    decks = (j['decks'] as List).map((e) => Deck.fromJson(e)).toList();
    cards = (j['cards'] as List).map((e) => CardM.fromJson(e)).toList();
    maps = (j['maps'] as List? ?? []).map((e) => MindMap.fromJson(e)).toList();
    lang = j['lang'] ?? 'ar';
    dark = j['dark'] ?? false;
    provider = j['provider'] ?? 'gemini';
    model = j['model'] ?? '';
    voiceEngine = j['voiceEngine'] ?? 'auto';
    userName = j['userName'] ?? '';
    ambient = j['ambient'] ?? '';
    lastDeckId = j['lastDeckId'] ?? '';
    voiceSpeed = (j['voiceSpeed'] ?? 1.0).toDouble();
    autoSpeak = j['autoSpeak'] ?? false;
    focusMin = j['focusMin'] ?? 25;
    focusTotal = j['focusTotal'] ?? 0;
    dailyGoal = j['dailyGoal'] ?? 20;
    xp = j['xp'] ?? 0;
    streak = j['streak'] ?? 0;
    totalReviews = j['totalReviews'] ?? 0;
    lastDay = j['lastDay'] ?? '';
    byDay = Map<String, int>.from(j['byDay'] ?? {});
    themeIdx = j['themeIdx'] ?? 0;
    fontScale = (j['fontScale'] ?? 1.0).toDouble();
    remindOn = j['remindOn'] ?? false;
    remindH = j['remindH'] ?? 20;
    remindM = j['remindM'] ?? 0;
    onboarded = j['onboarded'] ?? false;
  }

  Map<String, dynamic> toMap() => {
        'decks': decks.map((e) => e.toJson()).toList(),
        'cards': cards.map((e) => e.toJson()).toList(),
        'maps': maps.map((e) => e.toJson()).toList(),
        'lang': lang,
        'dark': dark,
        'provider': provider,
        // API keys are deliberately excluded; they live in platform secure storage.
        'model': model,
        'voiceEngine': voiceEngine,
        'userName': userName,
        'ambient': ambient,
        'lastDeckId': lastDeckId,
        'voiceSpeed': voiceSpeed,
        'autoSpeak': autoSpeak,
        'focusMin': focusMin,
        'focusTotal': focusTotal,
        'dailyGoal': dailyGoal,
        'xp': xp,
        'streak': streak,
        'totalReviews': totalReviews,
        'lastDay': lastDay,
        'byDay': byDay,
        'themeIdx': themeIdx,
        'fontScale': fontScale,
        'remindOn': remindOn,
        'remindH': remindH,
        'remindM': remindM,
        'onboarded': onboarded,
      };

  Future<void> _loadSecret(String key, String legacyValue, void Function(String) assign) async {
    var value = '';
    try {
      value = await _secretStorage.read(key: key) ?? '';
      if (value.isEmpty && legacyValue.trim().isNotEmpty) {
        value = legacyValue.trim();
        await _secretStorage.write(key: key, value: value);
      }
    } catch (_) {
      // Keep the app usable even when secure storage is unavailable on a test device.
      value = legacyValue.trim();
    }
    assign(value);
  }

  Future<void> updateSecret(String key, String value) async {
    final clean = value.trim();
    try {
      if (clean.isEmpty) {
        await _secretStorage.delete(key: key);
      } else {
        await _secretStorage.write(key: key, value: clean);
      }
    } catch (_) {
      // Do not silently claim a key was secured if the platform plugin failed.
      rethrow;
    }
    switch (key) {
      case 'geminiKey': geminiKey = clean; break;
      case 'hfKey': hfKey = clean; break;
      case 'openRouterKey': openRouterKey = clean; break;
      case 'googleTtsKey': googleTtsKey = clean; break;
      case 'elevenLabsKey': elevenLabsKey = clean; break;
    }
    configureVoice(engine: voiceEngine, googleKey: googleTtsKey, elevenLabsKey: elevenLabsKey, speed: voiceSpeed);
    notifyListeners();
  }

  void setVoiceEngine(String value) {
    voiceEngine = value;
    configureVoice(engine: voiceEngine, googleKey: googleTtsKey, elevenLabsKey: elevenLabsKey, speed: voiceSpeed);
    changed();
  }

  void setVoiceSpeed(double v) {
    voiceSpeed = v;
    configureVoice(engine: voiceEngine, googleKey: googleTtsKey, elevenLabsKey: elevenLabsKey, speed: voiceSpeed);
    changed();
  }

  Future<void> _save() {
    // Serialized + atomic (temp file then rename) so overlapping saves cannot corrupt the data file.
    _saveChain = _saveChain.then((_) async {
      if (_loadFailed) return;
      try {
        final tmp = File('${dir.path}/studyea.json.tmp');
        await tmp.writeAsString(jsonEncode(toMap()), flush: true);
        await tmp.rename('${dir.path}/studyea.json');
      } catch (_) {}
    });
    return _saveChain;
  }

  void changed() {
    notifyListeners();
    _save();
  }

  // ---------- decks ----------
  List<Deck> children(String? parent) => decks.where((d) => d.parentId == parent).toList();
  Deck? deck(String id) {
    for (final d in decks) {
      if (d.id == id) return d;
    }
    return null;
  }

  Set<String> deckTree(String id) {
    final out = <String>{id};
    for (final c in children(id)) {
      out.addAll(deckTree(c.id));
    }
    return out;
  }

  List<CardM> cardsOf(String deckId, {bool recursive = true}) {
    final ids = recursive ? deckTree(deckId) : {deckId};
    return cards.where((c) => ids.contains(c.deckId)).toList();
  }

  int dueCount(String deckId) {
    final now = DateTime.now().millisecondsSinceEpoch;
    return cardsOf(deckId).where((c) => c.due <= now).length;
  }

  Deck addDeck(String name, [String? parent]) {
    final d = Deck(newId(), name, parent, decks.length % kDeckColorCount);
    decks.add(d);
    changed();
    return d;
  }

  void renameDeck(Deck d, String name) {
    d.name = name;
    changed();
  }

  void deleteDeck(String id) {
    final ids = deckTree(id);
    decks.removeWhere((d) => ids.contains(d.id));
    cards.removeWhere((c) => ids.contains(c.deckId));
    changed();
  }

  // ---------- cards ----------
  void addCard(CardM c) {
    cards.add(c);
    changed();
  }

  void addCards(String deckId, List<List<String>> pairs) {
    for (final p in pairs) {
      cards.add(CardM(id: newId(), deckId: deckId, front: p[0], back: p[1]));
    }
    changed();
  }

  void deleteCard(CardM c) {
    cards.removeWhere((e) => e.id == c.id);
    changed();
  }

  Future<String> saveImage(Uint8List bytes) async {
    final p = '${dir.path}/images/${newId()}.jpg';
    await File(p).writeAsBytes(bytes);
    return p;
  }

  // ---------- SM-2 ----------
  List<num> review(CardM c, int q) {
    // q: 0 again, 3 hard, 4 good, 5 easy
    final snap = <num>[c.ease, c.interval, c.reps, c.lapses, c.due, q, q >= 3 ? 10 : 2];
    final now = DateTime.now();
    if (q < 3) {
      c.reps = 0;
      c.lapses++;
      c.interval = 0;
      c.due = now.add(const Duration(minutes: 10)).millisecondsSinceEpoch;
      c.ease = max(1.3, c.ease - 0.2);
    } else {
      if (c.reps == 0) {
        c.interval = 1;
      } else if (c.reps == 1) {
        c.interval = 6;
      } else {
        c.interval = max(c.interval + 1, (c.interval * c.ease).round());
      }
      c.reps++;
      c.ease = max(1.3, c.ease + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02));
      c.due = now.add(Duration(days: c.interval)).millisecondsSinceEpoch;
    }
    lastDeckId = c.deckId;
    final dk = dayKey(now);
    if (lastDay != dk) {
      final y = dayKey(now.subtract(const Duration(days: 1)));
      streak = lastDay == y ? streak + 1 : 1;
      lastDay = dk;
    }
    byDay[dk] = (byDay[dk] ?? 0) + 1;
    totalReviews++;
    xp += q >= 3 ? 10 : 2;
    changed();
    return snap;
  }

  void undoReview(CardM c, List<num> snap) {
    c.ease = snap[0].toDouble();
    c.interval = snap[1].toInt();
    c.reps = snap[2].toInt();
    c.lapses = snap[3].toInt();
    c.due = snap[4].toInt();
    final dk = dayKey(DateTime.now());
    byDay[dk] = max(0, (byDay[dk] ?? 1) - 1);
    totalReviews = max(0, totalReviews - 1);
    xp = max(0, xp - snap[6].toInt());
    changed();
  }

  void addXp(int n) {
    xp += n;
    changed();
  }

  // ---------- maps ----------
  void addMap(MindMap m) {
    maps.add(m);
    changed();
  }

  void deleteMap(MindMap m) {
    maps.removeWhere((e) => e.id == m.id);
    changed();
  }
}
