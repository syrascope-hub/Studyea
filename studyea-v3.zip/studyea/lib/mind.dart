import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'ai.dart';
import 'models.dart';
import 'neu.dart';
import 'store.dart';

const _palette = [
  kAccent,
  kLime,
  kOrange,
  kCoral,
  Color(0xFF26232D),
  Color(0xFFB9A8FF),
];

class MapsPage extends StatelessWidget {
  const MapsPage({super.key});

  Future<void> _create(BuildContext context) async {
    final s = context.read<Store>();
    final c = TextEditingController();
    bool busy = false;
    await neuSheet(
      context,
      (ctx) => StatefulBuilder(
        builder: (ctx, set) => Column(mainAxisSize: MainAxisSize.min, children: [
          Text(s.t('newMap'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 14),
          NeuField(controller: c, hint: s.t('mapTitle')),
          const SizedBox(height: 14),
          if (busy)
            const Padding(padding: EdgeInsets.all(12), child: CircularProgressIndicator())
          else
            Row(children: [
              Expanded(
                child: NeuButton(
                  onTap: () {
                    final t = c.text.trim();
                    if (t.isEmpty) return;
                    final m = MindMap(newId(), t, MNode(newId(), t));
                    s.addMap(m);
                    Navigator.pop(ctx);
                    Navigator.push(context, MaterialPageRoute(builder: (_) => MindMapPage(mapId: m.id)));
                  },
                  child: Center(child: Text(s.t('createManual'), textAlign: TextAlign.center)),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: NeuButton(
                  filled: true,
                  onTap: () async {
                    final t = c.text.trim();
                    if (t.isEmpty) return;
                    set(() => busy = true);
                    try {
                      final root = await Ai(s).mindMap(t);
                      final m = MindMap(newId(), t, root);
                      s.addMap(m);
                      if (ctx.mounted) Navigator.pop(ctx);
                      if (context.mounted) {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => MindMapPage(mapId: m.id)));
                      }
                    } catch (e) {
                      set(() => busy = false);
                      if (context.mounted) toast(context, e.toString());
                    }
                  },
                  child: Center(child: Text(s.t('createAi'), textAlign: TextAlign.center)),
                ),
              ),
            ]),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    return NeuPage(
      title: s.t('mindmaps'),
      back: false,
      actions: [NeuIcon(Icons.add_rounded, filled: true, onTap: () => _create(context))],
      body: s.maps.isEmpty
          ? Center(child: Text(s.t('noMaps'), style: TextStyle(color: neuText(d).withValues(alpha: .6))))
          : ListView(padding: const EdgeInsets.all(16), children: [
              for (final m in s.maps)
                Padding(
                  padding: const EdgeInsets.only(bottom: 16),
                  child: GestureDetector(
                    onTap: () =>
                        Navigator.push(context, MaterialPageRoute(builder: (_) => MindMapPage(mapId: m.id))),
                    child: NeuBox(
                      child: Row(children: [
                        NeuBox(
                            inset: true,
                            radius: 14,
                            padding: const EdgeInsets.all(12),
                            child: const Icon(Icons.account_tree_rounded, color: kAccent)),
                        const SizedBox(width: 14),
                        Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(m.title,
                              style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: neuText(d))),
                          Text('${m.root.count()} ${s.t('nodeText')}',
                              style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
                        ])),
                      ]),
                    ),
                  ),
                ),
            ]),
    );
  }
}

class _Layout {
  final pos = <String, Offset>{};
  final branch = <String, int>{};
  final depth = <String, int>{};
  final parent = <String, String>{};
  final nodes = <String, MNode>{};
  Size size = Size.zero;
}

int _leaves(MNode n) => n.children.isEmpty ? 1 : n.children.fold(0, (a, b) => a + _leaves(b));

_Layout computeLayout(MNode root, bool radial) {
  final L = _Layout();
  if (radial) {
    void rad(MNode n, int dp, double a0, double a1, int br, String? par) {
      final mid = (a0 + a1) / 2;
      L.pos[n.id] = dp == 0 ? Offset.zero : Offset(cos(mid), sin(mid)) * (dp * 215.0);
      L.branch[n.id] = br;
      L.depth[n.id] = dp;
      L.nodes[n.id] = n;
      if (par != null) L.parent[n.id] = par;
      final total = _leaves(n);
      var a = a0;
      for (var i = 0; i < n.children.length; i++) {
        final c = n.children[i];
        final span = (a1 - a0) * _leaves(c) / total;
        rad(c, dp + 1, a, a + span, dp == 0 ? i : br, n.id);
        a += span;
      }
    }

    rad(root, 0, -pi / 2, 3 * pi / 2, -1, null);
  } else {
    var leaf = 0;
    double tree(MNode n, int dp, int br, String? par) {
      L.depth[n.id] = dp;
      L.branch[n.id] = br;
      L.nodes[n.id] = n;
      if (par != null) L.parent[n.id] = par;
      double y;
      if (n.children.isEmpty) {
        y = leaf++ * 84.0;
      } else {
        final ys = <double>[];
        for (var i = 0; i < n.children.length; i++) {
          ys.add(tree(n.children[i], dp + 1, dp == 0 ? i : br, n.id));
        }
        y = (ys.first + ys.last) / 2;
      }
      L.pos[n.id] = Offset(dp * 240.0, y);
      return y;
    }

    tree(root, 0, -1, null);
  }
  var minX = double.infinity, minY = double.infinity, maxX = -double.infinity, maxY = -double.infinity;
  for (final p in L.pos.values) {
    minX = min(minX, p.dx);
    minY = min(minY, p.dy);
    maxX = max(maxX, p.dx);
    maxY = max(maxY, p.dy);
  }
  const mx = 140.0, my = 90.0;
  for (final k in L.pos.keys.toList()) {
    L.pos[k] = L.pos[k]! - Offset(minX, minY) + const Offset(mx, my);
  }
  L.size = Size(maxX - minX + mx * 2, maxY - minY + my * 2);
  return L;
}

Color branchColor(int b) => b < 0 ? kAccent : _palette[b % _palette.length];

class _LinesPainter extends CustomPainter {
  final _Layout L;
  final bool radial;
  final Color ink;
  _LinesPainter(this.L, this.radial, this.ink);
  @override
  void paint(Canvas canvas, Size size) {
    for (final e in L.parent.entries) {
      final a = L.pos[e.value]!, b = L.pos[e.key]!;
      final col = branchColor(L.branch[e.key]!);
      final w = max(2.0, 7.0 - L.depth[e.key]! * 1.8);
      final path = Path()..moveTo(a.dx, a.dy);
      if (radial) {
        final m = Offset.lerp(a, b, .5)!;
        final perp = Offset(-(b.dy - a.dy), b.dx - a.dx) * 0.12;
        path.quadraticBezierTo(m.dx + perp.dx, m.dy + perp.dy, b.dx, b.dy);
      } else {
        final mx = (a.dx + b.dx) / 2;
        path.cubicTo(mx, a.dy, mx, b.dy, b.dx, b.dy);
      }
      canvas.drawPath(
          path,
          Paint()
            ..color = ink
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeWidth = w + 5);
      canvas.drawPath(
          path,
          Paint()
            ..color = col
            ..style = PaintingStyle.stroke
            ..strokeCap = StrokeCap.round
            ..strokeWidth = w);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => true;
}

class MindMapPage extends StatefulWidget {
  final String mapId;
  const MindMapPage({super.key, required this.mapId});
  @override
  State<MindMapPage> createState() => _MindMapPageState();
}

class _MindMapPageState extends State<MindMapPage> {
  bool radial = true, busy = false, centered = false;
  final ctrl = TransformationController();

  bool _remove(MNode p, String id) {
    final i = p.children.indexWhere((c) => c.id == id);
    if (i >= 0) {
      p.children.removeAt(i);
      return true;
    }
    return p.children.any((c) => _remove(c, id));
  }

  Future<void> _nodeMenu(MindMap m, MNode n) async {
    final s = context.read<Store>();
    final isRoot = n.id == m.root.id;
    Widget item(IconData i, String t, Future<void> Function() f) => Padding(
          padding: const EdgeInsets.only(bottom: 12),
          child: NeuButton(
            onTap: () async {
              Navigator.pop(context);
              await f();
            },
            child: SizedBox(
                width: double.infinity,
                child: Row(children: [Icon(i, size: 20), const SizedBox(width: 12), Text(t)])),
          ),
        );
    await neuSheet(
      context,
      (ctx) => Column(mainAxisSize: MainAxisSize.min, children: [
        Padding(
            padding: const EdgeInsets.only(bottom: 14),
            child: Text(n.text, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800))),
        item(Icons.add_circle_outline_rounded, s.t('addChild'), () async {
          final t = await askText(context, s.t('addChild'), hint: s.t('nodeText'));
          if (t != null && t.isNotEmpty) {
            n.children.add(MNode(newId(), t));
            s.changed();
          }
        }),
        item(Icons.edit_rounded, s.t('editNode'), () async {
          final t = await askText(context, s.t('editNode'), initial: n.text);
          if (t != null && t.isNotEmpty) {
            n.text = t;
            s.changed();
          }
        }),
        item(Icons.auto_awesome_rounded, s.t('expandAi'), () async {
          setState(() => busy = true);
          try {
            final r = await Ai(s).expand(n.text, m.title);
            n.children.addAll(r.map((e) => MNode(newId(), e)));
            s.changed();
          } catch (e) {
            if (mounted) toast(context, e.toString());
          }
          if (mounted) setState(() => busy = false);
        }),
        if (!isRoot)
          item(Icons.delete_outline_rounded, s.t('deleteNode'), () async {
            _remove(m.root, n.id);
            s.changed();
          }),
      ]),
    );
  }

  void _toCards(MindMap m) {
    final s = context.read<Store>();
    final pairs = <List<String>>[];
    void walk(MNode n) {
      if (n.children.isNotEmpty) {
        pairs.add([n.text, n.children.map((e) => e.text).join(s.lang == 'ar' ? '، ' : ', ')]);
      }
      n.children.forEach(walk);
    }

    walk(m.root);
    if (pairs.isEmpty) return;
    final dk = s.addDeck(m.title);
    s.addCards(dk.id, pairs);
    toast(context, '${s.t('created')}: ${pairs.length}');
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final m = s.maps.where((e) => e.id == widget.mapId).firstOrNull;
    if (m == null) return const Scaffold();
    final L = computeLayout(m.root, radial);
    final bg = neuCard(d);

    Widget nodeW(MNode n) {
      final dp = L.depth[n.id]!;
      final col = branchColor(L.branch[n.id]!);
      final root = dp == 0;
      final child = ConstrainedBox(
        constraints: BoxConstraints(minWidth: root ? 110 : 70, maxWidth: root ? 200 : 170),
        child: NeuBox(
          radius: root ? 26 : 18,
          depth: root ? 8 : 5,
          color: root ? kAccent : Color.lerp(bg, col, d ? .55 : .42),
          padding: EdgeInsets.symmetric(horizontal: root ? 20 : 14, vertical: root ? 16 : 10),
          child: Text(n.text,
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: root ? 18 : (dp == 1 ? 15 : 13),
                  fontWeight: root || dp == 1 ? FontWeight.w800 : FontWeight.w600,
                  color: root ? Colors.white : neuText(d))),
        ),
      );
      return Positioned(
        left: L.pos[n.id]!.dx,
        top: L.pos[n.id]!.dy,
        child: FractionalTranslation(
          translation: const Offset(-.5, -.5),
          child: TweenAnimationBuilder<double>(
            key: ValueKey(n.id),
            tween: Tween(begin: 0, end: 1),
            duration: Duration(milliseconds: 350 + dp * 140),
            curve: Curves.easeOutBack,
            builder: (c, v, ch) => Transform.scale(scale: v.clamp(0.0, 1.2), child: Opacity(opacity: v.clamp(0.0, 1.0), child: ch)),
            child: GestureDetector(onTap: () => _nodeMenu(m, n), child: child),
          ),
        ),
      );
    }

    return NeuPage(
      title: m.title,
      actions: [
        NeuIcon(Icons.hub_rounded, size: 18, filled: radial, onTap: () => setState(() {
              radial = true;
              centered = false;
            })),
        NeuIcon(Icons.account_tree_rounded, size: 18, filled: !radial, onTap: () => setState(() {
              radial = false;
              centered = false;
            })),
        NeuIcon(Icons.style_rounded, size: 18, onTap: () => _toCards(m)),
        NeuIcon(Icons.delete_outline_rounded, size: 18, onTap: () async {
          if (await confirm(context)) {
            s.deleteMap(m);
            if (context.mounted) Navigator.pop(context);
          }
        }),
      ],
      body: LayoutBuilder(builder: (c, k) {
        if (!centered) {
          centered = true;
          final root = L.pos[m.root.id]!;
          const sc = 0.9;
          final tx = radial ? k.maxWidth / 2 - root.dx * sc : 20 - (root.dx - 110) * sc;
          final ty = k.maxHeight / 2 - root.dy * sc;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            ctrl.value = Matrix4.identity()
              ..translate(tx, ty)
              ..scale(sc);
          });
        }
        return Stack(children: [
          Positioned.fill(
            child: NeuBox(
              inset: true,
              radius: 0,
              padding: EdgeInsets.zero,
              child: InteractiveViewer(
                transformationController: ctrl,
                constrained: false,
                minScale: .2,
                maxScale: 2.5,
                boundaryMargin: const EdgeInsets.all(600),
                child: SizedBox(
                  width: L.size.width,
                  height: L.size.height,
                  child: Stack(clipBehavior: Clip.none, children: [
                    Positioned.fill(child: CustomPaint(painter: _LinesPainter(L, radial, neuLo(d)))),
                    for (final n in L.nodes.values) nodeW(n),
                  ]),
                ),
              ),
            ),
          ),
          if (busy) const Positioned.fill(child: Center(child: CircularProgressIndicator())),
        ]);
      }),
    );
  }
}
