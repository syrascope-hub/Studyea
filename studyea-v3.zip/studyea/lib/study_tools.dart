import 'dart:convert';
import 'dart:io';
import 'dart:math' as math;

import 'package:archive/archive.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' as syncfusion_pdf;
import 'package:xml/xml.dart';

import 'ai.dart';
import 'models.dart';
import 'neu.dart';
import 'store.dart';
import 'study.dart';
import 'tex.dart';
import 'tts.dart';

class StudyFileImportPage extends StatefulWidget {
  final String deckId;
  const StudyFileImportPage({super.key, required this.deckId});

  @override
  State<StudyFileImportPage> createState() => _StudyFileImportPageState();
}

class _StudyFileImportPageState extends State<StudyFileImportPage> {
  final _text = TextEditingController();
  String? _fileName;
  bool _busy = false;

  @override
  void dispose() {
    _text.dispose();
    super.dispose();
  }

  Future<String> _extract(PlatformFile file) async {
    final bytes = file.bytes ?? (file.path == null ? null : await File(file.path!).readAsBytes());
    if (bytes == null) throw StateError('تعذرت قراءة الملف. حاول اختيار الملف مرة أخرى.');
    final ext = (file.extension ?? '').toLowerCase();
    if (ext == 'txt' || ext == 'md' || ext == 'csv' || ext == 'tsv') {
      return utf8.decode(bytes, allowMalformed: true).trim();
    }
    if (ext == 'pdf') {
      final document = syncfusion_pdf.PdfDocument(inputBytes: bytes);
      try {
        return syncfusion_pdf.PdfTextExtractor(document).extractText().trim();
      } finally {
        document.dispose();
      }
    }
    if (ext == 'docx') {
      final archive = ZipDecoder().decodeBytes(bytes);
      final entry = archive.findFile('word/document.xml');
      if (entry == null) throw StateError('لم يتم العثور على محتوى مستند Word.');
      final xml = XmlDocument.parse(utf8.decode(entry.content as List<int>));
      return xml.findAllElements('p').map((p) => p.findAllElements('t').map((t) => t.innerText).join()).where((p) => p.trim().isNotEmpty).join('\n');
    }
    throw StateError('نوع الملف غير مدعوم. اختر PDF أو DOCX أو TXT أو MD أو CSV.');
  }

  Future<void> _pick() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: const ['pdf', 'docx', 'txt', 'md', 'csv', 'tsv'],
        withData: true,
      );
      if (result == null || result.files.isEmpty) return;
      setState(() => _busy = true);
      final file = result.files.single;
      final extracted = await _extract(file);
      if (extracted.isEmpty) {
        throw StateError('لم يتم العثور على نص قابل للاستخراج. قد يكون PDF ممسوحًا ضوئيًا كصور.');
      }
      if (mounted) {
        setState(() {
          _fileName = file.name;
          _text.text = extracted;
        });
      }
    } catch (e) {
      if (mounted) toast(context, e.toString().replaceFirst('Bad state: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _createCards() async {
    final source = _text.text.trim();
    if (source.isEmpty) {
      toast(context, 'اختر ملفًا أو ألصق نص الدراسة أولًا.');
      return;
    }
    setState(() => _busy = true);
    try {
      // Keep prompts manageable on mobile and reduce accidental large API charges.
      final cards = await Ai(context.read<Store>()).cardsFromText(source.substring(0, source.length > 24000 ? 24000 : source.length));
      if (!mounted) return;
      if (cards.isEmpty) throw StateError('لم يُنشأ أي سؤال. حاول استخدام نص أوضح.');
      final accepted = await showDialog<bool>(
        context: context,
        builder: (dialogContext) => AlertDialog(
          title: Text('معاينة البطاقات (${cards.length})'),
          content: SizedBox(
            width: double.maxFinite,
            child: ListView.separated(
              shrinkWrap: true,
              itemCount: cards.length > 12 ? 12 : cards.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (_, i) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(cards[i][0], style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(cards[i][1]),
              ]),
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(dialogContext, false), child: const Text('إلغاء')),
            FilledButton(onPressed: () => Navigator.pop(dialogContext, true), child: const Text('إضافة إلى البطاقات')),
          ],
        ),
      );
      if (accepted == true && mounted) {
        context.read<Store>().addCards(widget.deckId, cards);
        toast(context, 'تم استيراد ${cards.length} بطاقة.');
        Navigator.pop(context);
      }
    } catch (e) {
      if (mounted) toast(context, e.toString().replaceFirst('Bad state: ', ''));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    return NeuPage(
      title: 'استيراد مواد الدراسة',
      body: ListView(padding: const EdgeInsets.all(16), children: [
        NeuBox(
          color: kAccent.withValues(alpha: d ? .20 : .10),
          child: const Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.auto_awesome_rounded, color: kAccent, size: 28),
            SizedBox(width: 12),
            Expanded(child: Text('اختر PDF أو Word أو ملفًا نصيًا. سيحوّل الذكاء الاصطناعي المحتوى إلى بطاقات، ويمكنك مراجعة المعاينة قبل الحفظ.')),
          ]),
        ),
        const SizedBox(height: 12),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final f in const [('PDF', kCoral), ('DOCX', kSky), ('TXT', kLime), ('MD', kAccent), ('CSV', kOrange)])
            NeuBox(
              radius: 10,
              depth: 2,
              color: f.$2,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              child: Text(f.$1, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w900, color: onColor(f.$2))),
            ),
        ]),
        const SizedBox(height: 14),
        NeuButton(
          filled: true,
          onTap: _busy ? null : _pick,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.upload_file_rounded),
            const SizedBox(width: 8),
            Text(_fileName == null ? 'اختيار ملف' : 'الملف: $_fileName'),
          ]),
        ),
        const SizedBox(height: 12),
        NeuField(controller: _text, maxLines: 12, hint: 'أو ألصق ملاحظات الدراسة هنا…', onChanged: (_) => setState(() {})),
        const SizedBox(height: 8),
        Text('${_text.text.length} حرف · تتم معالجة أول 24,000 حرف عند إنشاء البطاقات.',
            style: TextStyle(color: neuText(d).withValues(alpha: .62), fontSize: 12)),
        const SizedBox(height: 18),
        NeuButton(
          filled: true,
          onTap: _busy || _text.text.trim().isEmpty ? null : _createCards,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (_busy) const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            else const Icon(Icons.auto_awesome_rounded),
            const SizedBox(width: 8),
            Text(_busy ? 'جارٍ المعالجة…' : 'إنشاء بطاقات بالذكاء الاصطناعي'),
          ]),
        ),
      ]),
    );
  }
}

class _CoachMessage {
  final bool user;
  final String text;
  const _CoachMessage(this.user, this.text);
}

class StudyCoachPage extends StatefulWidget {
  const StudyCoachPage({super.key});
  @override
  State<StudyCoachPage> createState() => _StudyCoachPageState();
}

class _StudyCoachPageState extends State<StudyCoachPage> {
  final _input = TextEditingController();
  final List<_CoachMessage> _messages = [];
  bool _busy = false;
  final _scroll = ScrollController();

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final question = _input.text.trim();
    if (question.isEmpty || _busy) return;
    _input.clear();
    setState(() {
      _messages.add(_CoachMessage(true, question));
      _busy = true;
    });
    try {
      final history = _messages.take(_messages.length - 1).map((m) => '${m.user ? 'الطالب' : 'المدرب'}: ${m.text}').join('\n');
      final prompt = 'أنت مدرب دراسة ودود في StudyEA. اشرح المفاهيم بوضوح وبالتدرج، واستخدم أمثلة وأسئلة توجيهية عند الفائدة. أجب بلغة المستخدم، ولا تدّعِ أن إجابتك يقينية إذا لم تكن كذلك.\n'
          r'عند كتابة معادلات أو رموز رياضية استخدم LaTeX: ضع الصيغة بين $ ... $ داخل السطر، وبين $$ ... $$ لسطر مستقل.' '\n'
          '${history.isEmpty ? '' : 'سياق المحادثة:\n$history\n'}سؤال الطالب: $question';
      final reply = await Ai(context.read<Store>()).ask(prompt);
      if (mounted) setState(() => _messages.add(_CoachMessage(false, reply.trim())));
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (_scroll.hasClients) _scroll.animateTo(_scroll.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
      });
    } catch (e) {
      if (mounted) {
        setState(() => _messages.add(_CoachMessage(false, 'تعذّر الحصول على إجابة: ${e.toString().replaceFirst('Bad state: ', '')}')));
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _toCards(String text) async {
    final s = context.read<Store>();
    try {
      final r = await Ai(s).cardsFromText(text);
      if (r.isEmpty) throw StateError('لم يُنشأ أي سؤال.');
      final dk = s.decks.isEmpty ? s.addDeck(s.t('general')) : s.decks.first;
      s.addCards(dk.id, r);
      if (mounted) toast(context, s.tr('تمت إضافة ${r.length} بطاقة إلى «${dk.name}»', 'Added ${r.length} cards to "${dk.name}"'));
    } catch (e) {
      if (mounted) toast(context, e.toString().replaceFirst('Bad state: ', ''));
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    return NeuPage(
      title: 'مدرب الدراسة AI',
      body: Column(children: [
        Expanded(
          child: _messages.isEmpty
              ? Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.psychology_alt_rounded, size: 58, color: kAccent),
                  const SizedBox(height: 12),
                  Text('اسأل عن مفهوم، اطلب مثالًا، أو اطلب خطة لفهم موضوع صعب.', textAlign: TextAlign.center, style: TextStyle(color: neuText(d), fontSize: 16)),
                  const SizedBox(height: 8),
                  Text('تُرسل الأسئلة إلى مزوّد الذكاء الاصطناعي المختار في الإعدادات.', textAlign: TextAlign.center, style: TextStyle(color: neuText(d).withValues(alpha: .6), fontSize: 12)),
                ])))
              : ListView.builder(
                  controller: _scroll,
                  padding: const EdgeInsets.all(16),
                  itemCount: _messages.length + (_busy ? 1 : 0),
                  itemBuilder: (_, i) {
                    if (_busy && i == _messages.length) return const Padding(padding: EdgeInsets.all(12), child: Align(alignment: AlignmentDirectional.centerStart, child: CircularProgressIndicator()));
                    final m = _messages[i];
                    return Align(
                      alignment: m.user ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
                      child: Container(
                        constraints: BoxConstraints(maxWidth: MediaQuery.sizeOf(context).width * .86),
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: m.user ? kAccent.withValues(alpha: .18) : neuCard(d).withValues(alpha: .84),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: m.user ? kAccent.withValues(alpha: .28) : Colors.white.withValues(alpha: d ? .09 : .65)),
                        ),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                          RichMath(m.text, markdown: !m.user, style: TextStyle(color: neuText(d), height: 1.5)),
                          if (!m.user)
                            Padding(
                              padding: const EdgeInsets.only(top: 8),
                              child: Row(mainAxisSize: MainAxisSize.min, children: [
                                NeuIcon(Icons.volume_up_rounded, size: 16, onTap: () => speak(m.text)),
                                const SizedBox(width: 8),
                                NeuIcon(Icons.style_rounded, size: 16, onTap: () => _toCards(m.text)),
                              ]),
                            ),
                        ]),
                      ),
                    );
                  },
                ),
        ),
        Padding(
          padding: EdgeInsets.fromLTRB(12, 8, 12, 12 + MediaQuery.viewInsetsOf(context).bottom),
          child: Row(children: [
            Expanded(child: NeuField(controller: _input, hint: s.lang == 'ar' ? 'اكتب سؤالك…' : 'Ask a study question…', maxLines: 3)),
            const SizedBox(width: 10),
            NeuButton(filled: true, onTap: _busy ? null : _send, padding: const EdgeInsets.all(14), child: const Icon(Icons.send_rounded, color: Colors.white)),
          ]),
        ),
      ]),
    );
  }
}

class ListenModePage extends StatefulWidget {
  final List<CardM> cards;
  const ListenModePage({super.key, required this.cards});
  @override
  State<ListenModePage> createState() => _ListenModePageState();
}

class _Wave extends StatefulWidget {
  final bool active;
  const _Wave({required this.active});
  @override
  State<_Wave> createState() => _WaveState();
}

class _WaveState extends State<_Wave> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (ctx, _) => SizedBox(
        height: 44,
        child: Row(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.center, children: [
          for (var i = 0; i < 30; i++)
            Container(
              width: 4,
              margin: const EdgeInsets.symmetric(horizontal: 2),
              height: widget.active ? 6 + 34 * (0.5 + 0.5 * math.sin(2 * math.pi * (_c.value + i / 9))) * (0.35 + 0.65 * ((i * 7) % 5) / 4) : 6,
              decoration: BoxDecoration(color: i < 12 ? kAccent : kAccent.withValues(alpha: .35), borderRadius: BorderRadius.circular(3)),
            ),
        ]),
      ),
    );
  }
}

class _ListenModePageState extends State<ListenModePage> {
  int _index = 0;
  bool _readingAll = false;
  bool _showAnswer = false;

  @override
  void dispose() {
    _readingAll = false;
    stopSpeaking();
    super.dispose();
  }

  Future<void> _readCurrent() async {
    if (widget.cards.isEmpty) return;
    final card = widget.cards[_index.clamp(0, widget.cards.length - 1).toInt()];
    final text = _showAnswer ? cardQA(card).$2 : cardQA(card).$1;
    await speak(text);
  }

  Future<void> _readAll() async {
    if (_readingAll || widget.cards.isEmpty) return;
    setState(() => _readingAll = true);
    try {
      for (var i = _index; i < widget.cards.length && mounted && _readingAll; i++) {
        setState(() {
          _index = i;
          _showAnswer = false;
        });
        await speak(cardQA(widget.cards[i]).$1);
        if (!mounted || !_readingAll) break;
        await Future<void>.delayed(const Duration(milliseconds: 450));
        if (!mounted || !_readingAll) break;
        setState(() => _showAnswer = true);
        await speak(cardQA(widget.cards[i]).$2);
        if (!mounted || !_readingAll) break;
        await Future<void>.delayed(const Duration(milliseconds: 700));
      }
    } finally {
      if (mounted) setState(() => _readingAll = false);
    }
  }

  Future<void> _stop() async {
    setState(() => _readingAll = false);
    await stopSpeaking();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final title = s.tr('وضع الاستماع', 'Listen mode');
    if (widget.cards.isEmpty) {
      return NeuPage(title: title, body: Center(child: Text(s.tr('أضف بعض البطاقات أولًا.', 'Add some cards first.'))));
    }
    final card = widget.cards[_index.clamp(0, widget.cards.length - 1).toInt()];
    final engines = [
      ('auto', s.tr('تلقائي', 'Auto'), Icons.auto_awesome_rounded, kLime),
      ('local', s.tr('صوت الجهاز', 'Device'), Icons.phone_android_rounded, kLime),
      ('google', 'Google Cloud', Icons.cloud_rounded, kSky),
      ('elevenlabs', 'ElevenLabs', Icons.graphic_eq_rounded, kCoral),
    ];
    return NeuPage(
      title: title,
      body: ListView(padding: const EdgeInsets.all(18), children: [
        NeuBox(
          color: kAccent,
          radius: 20,
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            const Icon(Icons.headphones_rounded, color: Colors.white, size: 28),
            const SizedBox(width: 12),
            Expanded(
              child: Text(s.tr('بطاقة ${_index + 1} من ${widget.cards.length}', 'Card ${_index + 1} of ${widget.cards.length}'),
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 16)),
            ),
          ]),
        ),
        const SizedBox(height: 14),
        NeuBox(
          radius: 24,
          padding: const EdgeInsets.all(22),
          child: Column(children: [
            Text(_showAnswer ? s.tr('الإجابة', 'Answer') : s.tr('السؤال', 'Question'),
                style: const TextStyle(color: kAccent, fontWeight: FontWeight.w900)),
            const SizedBox(height: 12),
            RichMath(_showAnswer ? cardQA(card).$2 : cardQA(card).$1,
                align: TextAlign.center,
                style: TextStyle(fontSize: 22, height: 1.45, fontWeight: FontWeight.w800, color: neuText(d))),
            const SizedBox(height: 16),
            ValueListenableBuilder<bool>(valueListenable: speaking, builder: (ctx, v, _) => _Wave(active: v)),
            const SizedBox(height: 14),
            NeuButton(
                onTap: () => setState(() => _showAnswer = !_showAnswer),
                child: Text(_showAnswer ? s.tr('عرض السؤال', 'Show question') : s.tr('عرض الإجابة', 'Show answer'))),
          ]),
        ),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          NeuButton(
              onTap: _index > 0
                  ? () => setState(() {
                        _index--;
                        _showAnswer = false;
                      })
                  : null,
              child: const Icon(Icons.skip_previous_rounded)),
          const SizedBox(width: 12),
          NeuButton(
              filled: true,
              radius: 40,
              padding: const EdgeInsets.all(18),
              onTap: _readCurrent,
              child: const Icon(Icons.volume_up_rounded, size: 30)),
          const SizedBox(width: 12),
          NeuButton(
              onTap: _index < widget.cards.length - 1
                  ? () => setState(() {
                        _index++;
                        _showAnswer = false;
                      })
                  : null,
              child: const Icon(Icons.skip_next_rounded)),
        ]),
        const SizedBox(height: 12),
        NeuButton(
            filled: true,
            onTap: _readingAll ? _stop : _readAll,
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(_readingAll ? Icons.stop_rounded : Icons.play_circle_fill_rounded),
              const SizedBox(width: 8),
              Text(_readingAll ? s.tr('إيقاف القراءة المتتابعة', 'Stop continuous reading') : s.tr('استمع إلى جميع البطاقات', 'Play all cards')),
            ])),
        const SizedBox(height: 22),
        Text(s.tr('محرك الصوت', 'Voice engine'), style: TextStyle(fontWeight: FontWeight.w900, color: neuText(d))),
        const SizedBox(height: 10),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final e in engines)
            GestureDetector(
              onTap: () => s.setVoiceEngine(e.$1),
              child: NeuBox(
                radius: 14,
                depth: s.voiceEngine == e.$1 ? 0 : 3,
                color: s.voiceEngine == e.$1 ? e.$4 : null,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  Icon(e.$3, size: 18, color: s.voiceEngine == e.$1 ? kInk : neuText(d)),
                  const SizedBox(width: 6),
                  Text(e.$2, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12, color: s.voiceEngine == e.$1 ? kInk : neuText(d))),
                ]),
              ),
            ),
        ]),
        const SizedBox(height: 16),
        Row(children: [
          Text(s.tr('السرعة', 'Speed'), style: TextStyle(fontWeight: FontWeight.w900, color: neuText(d))),
          Expanded(
            child: Slider(
              value: s.voiceSpeed,
              min: 0.5,
              max: 2.0,
              divisions: 12,
              activeColor: kAccent,
              label: '${s.voiceSpeed.toStringAsFixed(2)}x',
              onChanged: (v) => s.setVoiceSpeed(v),
            ),
          ),
          Text('${s.voiceSpeed.toStringAsFixed(2)}x', style: TextStyle(color: neuText(d))),
        ]),
      ]),
    );
  }
}
