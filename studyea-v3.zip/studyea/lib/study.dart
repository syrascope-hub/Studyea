import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'models.dart';
import 'neu.dart';
import 'store.dart';
import 'tts.dart';
import 'tex.dart';

final _clozeRe = RegExp(r'\{\{(.*?)\}\}');

String _fmtSpeed(double v) => v == v.roundToDouble() ? '${v.toInt()}.0' : '$v';

(String, String) cardQA(CardM c) {
  if (c.type == 'cloze') {
    final m = _clozeRe.firstMatch(c.front);
    return (c.front.replaceAllMapped(_clozeRe, (_) => '[...]'), m?.group(1) ?? c.back);
  }
  return (c.front, c.back);
}

String clozeFull(CardM c) => c.front.replaceAllMapped(_clozeRe, (m) => m.group(1) ?? '');

class _H {
  final CardM card;
  final List<num>? snap;
  final List<CardM> queueBefore;
  final int doneBefore;
  _H(this.card, this.snap, this.queueBefore, this.doneBefore);
}

class ReviewPage extends StatefulWidget {
  final List<CardM> cards;
  final bool cram;
  const ReviewPage({super.key, required this.cards, this.cram = false});
  @override
  State<ReviewPage> createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  late List<CardM> queue = [...widget.cards]..shuffle();
  final List<_H> history = [];
  bool flipped = false;
  double dx = 0;
  int done = 0;

  void answer(int q) {
    final s = context.read<Store>();
    final c = queue.first;
    List<num>? snap;
    if (widget.cram) {
      s.addXp(q >= 3 ? 2 : 0);
    } else {
      snap = s.review(c, q);
    }
    history.add(_H(c, snap, [...queue], done));
    q >= 3 ? HapticFeedback.mediumImpact() : HapticFeedback.heavyImpact();
    setState(() {
      queue.removeAt(0);
      if (q < 3) queue.add(c);
      if (q >= 3) done++;
      flipped = false;
      dx = 0;
    });
  }

  void undo() {
    if (history.isEmpty) return;
    final s = context.read<Store>();
    final h = history.removeLast();
    if (h.snap != null) s.undoReview(h.card, h.snap!);
    HapticFeedback.selectionClick();
    setState(() {
      queue = h.queueBefore;
      done = h.doneBefore;
      flipped = false;
      dx = 0;
    });
  }

  int get total => widget.cards.length;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _autoSpeak());
  }

  @override
  void dispose() {
    stopSpeaking();
    super.dispose();
  }

  String _backOf(CardM c) => c.type == 'cloze' ? clozeFull(c) : cardQA(c).$2;

  void _autoSpeak() {
    if (!mounted || queue.isEmpty) return;
    if (context.read<Store>().autoSpeak) speak(cardQA(queue.first).$1);
  }

  void _flip() {
    HapticFeedback.selectionClick();
    setState(() => flipped = !flipped);
    final s = context.read<Store>();
    if (s.autoSpeak && queue.isNotEmpty) {
      final c = queue.first;
      speak(flipped ? _backOf(c) : cardQA(c).$1);
    }
  }

  void _cycleSpeed(Store s) {
    const l = [0.75, 1.0, 1.25, 1.5, 2.0];
    final i = l.indexWhere((x) => (x - s.voiceSpeed).abs() < .01);
    s.setVoiceSpeed(l[(i + 1) % l.length]);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final undoBtn = [NeuIcon(Icons.undo_rounded, size: 20, onTap: history.isEmpty ? null : undo)];
    if (queue.isEmpty) {
      return NeuPage(
        title: s.t('study'),
        actions: undoBtn,
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.emoji_events_rounded, size: 80, color: kAccent),
            const SizedBox(height: 12),
            Text(s.t('done'), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: neuText(d))),
            const SizedBox(height: 20),
            NeuButton(filled: true, onTap: () => Navigator.pop(context), child: Text(s.t('finish'))),
          ]),
        ),
      );
    }
    final c = queue.first;
    final qa = cardQA(c);
    final frontText = qa.$1;
    final backText = _backOf(c);
    final deckName = s.deck(c.deckId)?.name ?? '';
    final progress = total == 0 ? 0.0 : (done / total).clamp(0.0, 1.0).toDouble();
    final opts = <String>[];
    if (c.type == 'mcq') {
      opts
        ..addAll(c.options)
        ..add(c.back)
        ..shuffle(Random(c.id.hashCode));
    }

    Widget face(bool back) {
      final shown = back ? backText : frontText;
      return SizedBox(
        width: double.infinity,
        child: NeuBox(
          radius: 24,
          depth: 7,
          padding: const EdgeInsets.all(20),
          color: dx > 40
              ? Color.lerp(neuCard(d), Colors.green, .35)
              : dx < -40
                  ? Color.lerp(neuCard(d), Colors.red, .35)
                  : null,
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Row(children: [
              Expanded(
                child: Text(deckName,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(color: kAccent, fontWeight: FontWeight.w800, fontSize: 13)),
              ),
              NeuIcon(Icons.volume_up_rounded, size: 20, onTap: () => speak(shown)),
            ]),
            Expanded(
              child: Center(
                child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    if (c.image != null && File(c.image!).existsSync())
                      Padding(
                        padding: const EdgeInsets.only(bottom: 16),
                        child: ClipRRect(
                            borderRadius: BorderRadius.circular(8),
                            child: Image.file(File(c.image!), height: 160, fit: BoxFit.cover)),
                      ),
                    RichMath(shown,
                        align: TextAlign.center,
                        style: TextStyle(
                            fontSize: 24, height: 1.4, fontWeight: FontWeight.w800, color: back ? kAccent : neuText(d))),
                    if (!back)
                      for (final o in opts)
                        Padding(
                          padding: const EdgeInsets.only(top: 8),
                          child: RichMath('• $o', align: TextAlign.center, style: TextStyle(fontSize: 16, color: neuText(d))),
                        ),
                  ]),
                ),
              ),
            ),
            Text(s.t('tapFlip'), style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .5))),
          ]),
        ),
      );
    }

    final btns = [
      ('again', 0, kCoral),
      ('hard', 3, kOrange),
      ('good', 4, kLime),
      ('easy', 5, kSky),
    ];

    return NeuPage(
      title: s.t('study'),
      actions: undoBtn,
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
          child: Row(children: [
            Text('${(done + 1).clamp(1, total)} / $total',
                style: TextStyle(fontWeight: FontWeight.w900, color: neuText(d))),
            const SizedBox(width: 12),
            Expanded(
              child: NeuBox(
                inset: true,
                radius: 8,
                padding: const EdgeInsets.all(3),
                child: LayoutBuilder(
                  builder: (ctx, k) => Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: Container(
                      height: 8,
                      width: k.maxWidth * progress,
                      decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(6)),
                    ),
                  ),
                ),
              ),
            ),
          ]),
        ),
        Expanded(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Stack(fit: StackFit.expand, children: [
              if (queue.length > 2)
                Positioned(
                  left: 8,
                  right: 8,
                  top: 10,
                  bottom: 12,
                  child: NeuBox(radius: 24, depth: 0, padding: EdgeInsets.zero, child: const SizedBox.expand()),
                ),
              if (queue.length > 1)
                Positioned(
                  left: 16,
                  right: 16,
                  top: 20,
                  bottom: 0,
                  child: NeuBox(radius: 24, depth: 0, padding: EdgeInsets.zero, child: const SizedBox.expand()),
                ),
              Padding(
                padding: EdgeInsets.only(bottom: queue.length > 1 ? 22 : 0),
                child: GestureDetector(
                  onTap: _flip,
                  onHorizontalDragUpdate: (u) => setState(() => dx += u.delta.dx),
                  onHorizontalDragEnd: (_) {
                    if (dx > 110) {
                      answer(4);
                      _autoSpeak();
                    } else if (dx < -110) {
                      answer(0);
                      _autoSpeak();
                    } else {
                      setState(() => dx = 0);
                    }
                  },
                  child: Transform.translate(
                    offset: Offset(dx, 0),
                    child: Transform.rotate(
                      angle: dx / 1200,
                      child: TweenAnimationBuilder<double>(
                        key: ValueKey('${c.id}-${queue.length}-$done'),
                        tween: Tween<double>(begin: 0, end: flipped ? pi : 0),
                        duration: const Duration(milliseconds: 380),
                        curve: Curves.easeInOutCubic,
                        builder: (ctx, a, _) {
                          final back = a > pi / 2;
                          return Transform(
                            alignment: Alignment.center,
                            transform: Matrix4.identity()
                              ..setEntry(3, 2, 0.0012)
                              ..rotateY(a),
                            child: back
                                ? Transform(
                                    alignment: Alignment.center,
                                    transform: Matrix4.identity()..rotateY(pi),
                                    child: face(true))
                                : face(false),
                          );
                        },
                      ),
                    ),
                  ),
                ),
              ),
            ]),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          child: flipped
              ? Row(children: [
                  for (final b in btns)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: NeuButton(
                          fill: b.$3,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          onTap: () {
                            answer(b.$2);
                            _autoSpeak();
                          },
                          child: Center(child: Text(s.t(b.$1), style: const TextStyle(fontSize: 13))),
                        ),
                      ),
                    ),
                ])
              : SizedBox(
                  width: double.infinity,
                  child: NeuButton(
                    fill: kInk,
                    onTap: _flip,
                    child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(s.tr('إظهار الإجابة', 'Show answer')),
                      const SizedBox(width: 8),
                      const Icon(Icons.visibility_rounded, size: 20),
                    ]),
                  ),
                ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: NeuBox(
            radius: 20,
            depth: 3,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
              NeuIcon(Icons.volume_up_rounded, size: 20, onTap: () => speak(flipped ? backText : frontText)),
              GestureDetector(
                onTap: () => _cycleSpeed(s),
                child: NeuBox(
                  inset: true,
                  radius: 12,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                  child: Text('${_fmtSpeed(s.voiceSpeed)}x',
                      style: TextStyle(fontWeight: FontWeight.w900, color: neuText(d))),
                ),
              ),
              NeuIcon(Icons.record_voice_over_rounded, size: 20, filled: s.autoSpeak, onTap: () {
                s.autoSpeak = !s.autoSpeak;
                s.changed();
                toast(context, s.autoSpeak ? s.tr('القراءة التلقائية: تشغيل', 'Auto-read: on') : s.tr('القراءة التلقائية: إيقاف', 'Auto-read: off'));
                if (s.autoSpeak) _autoSpeak();
              }),
              NeuIcon(Icons.undo_rounded, size: 20, onTap: history.isEmpty ? null : undo),
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Q {
  final String text;
  final List<String> opts;
  final int correct;
  _Q(this.text, this.opts, this.correct);
}

class QuizPage extends StatefulWidget {
  final List<CardM> cards;
  final bool tf;
  const QuizPage({super.key, required this.cards, this.tf = false});
  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final rnd = Random();
  late final List<_Q> qs = _build();
  int idx = 0, score = 0, sel = -1;

  List<_Q> _build() {
    final s = context.read<Store>();
    final pool = widget.cards.map((c) => cardQA(c).$2).toSet().toList();
    final list = [...widget.cards]..shuffle(rnd);
    final out = <_Q>[];
    for (final c in list.take(10)) {
      final qa = cardQA(c);
      final wrong = <String>{...(c.type == 'mcq' ? c.options : <String>[]), ...(pool..shuffle(rnd))}
        ..remove(qa.$2)
        ..remove('');
      if (wrong.isEmpty) continue;
      if (widget.tf) {
        final truth = rnd.nextBool();
        final stmt = truth ? qa.$2 : wrong.first;
        out.add(_Q('${qa.$1}\n\n= $stmt ?', [s.t('trueT'), s.t('falseT')], truth ? 0 : 1));
      } else {
        final o = [qa.$2, ...wrong.take(3)]..shuffle(rnd);
        out.add(_Q(qa.$1, o, o.indexOf(qa.$2)));
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    if (qs.isEmpty) return NeuPage(title: s.t('quiz'), body: Center(child: Text(s.t('needMore'))));
    if (idx >= qs.length) {
      return NeuPage(
        title: s.t('quiz'),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('${s.t('score')}: $score / ${qs.length}',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: kAccent)),
            const SizedBox(height: 20),
            NeuButton(
                filled: true,
                onTap: () {
                  s.addXp(score * 3);
                  Navigator.pop(context);
                },
                child: Text(s.t('finish'))),
          ]),
        ),
      );
    }
    final q = qs[idx];
    return NeuPage(
      title: '${s.t('quiz')} ${idx + 1}/${qs.length}',
      body: ListView(padding: const EdgeInsets.all(16), children: [
        NeuBox(
          padding: const EdgeInsets.all(22),
          child: RichMath(q.text,
              align: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: neuText(d))),
        ),
        const SizedBox(height: 20),
        for (var i = 0; i < q.opts.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: NeuButton(
              fill: sel == -1
                  ? null
                  : i == q.correct
                      ? Colors.green.shade600
                      : i == sel
                          ? Colors.red.shade600
                          : null,
              onTap: () {
                if (sel != -1) return;
                i == q.correct ? HapticFeedback.mediumImpact() : HapticFeedback.heavyImpact();
                setState(() {
                  sel = i;
                  if (i == q.correct) score++;
                });
              },
              child: SizedBox(width: double.infinity, child: RichMath(q.opts[i], align: TextAlign.center)),
            ),
          ),
        if (sel != -1)
          NeuButton(
            filled: true,
            onTap: () => setState(() {
              idx++;
              sel = -1;
            }),
            child: Center(child: Text(idx + 1 >= qs.length ? s.t('finish') : '→')),
          ),
      ]),
    );
  }
}
