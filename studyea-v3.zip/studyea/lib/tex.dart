import 'package:flutter/material.dart';
import 'package:flutter_math_fork/flutter_math.dart';

/// One piece of a string: plain text, or a LaTeX formula (inline / display).
class MathSeg {
  final String text;
  final bool math;
  final bool display;
  const MathSeg(this.text, this.math, this.display);
}

final RegExp _plainNumber = RegExp(r'^[\d.,]+$');

int _closingDollar(String s, int from) {
  var j = from;
  while (j < s.length) {
    final c = s[j];
    if (c == '\\') {
      j += 2;
      continue;
    }
    if (c == r'$') return j;
    j++;
  }
  return -1;
}

/// Splits [src] into text and math segments.
/// Supported delimiters: $...$, $$...$$, \(...\), \[...\]. Use \$ for a literal dollar sign.
List<MathSeg> splitMath(String src) {
  final out = <MathSeg>[];
  final buf = StringBuffer();
  void flush() {
    if (buf.isNotEmpty) {
      out.add(MathSeg(buf.toString(), false, false));
      buf.clear();
    }
  }

  var i = 0;
  while (i < src.length) {
    final ch = src[i];
    if (ch == '\\' && i + 1 < src.length) {
      final n = src[i + 1];
      if (n == r'$') {
        buf.write(r'$');
        i += 2;
        continue;
      }
      if (n == '[' || n == '(') {
        final close = n == '[' ? '\\]' : '\\)';
        final end = src.indexOf(close, i + 2);
        if (end > 0) {
          final body = src.substring(i + 2, end).trim();
          if (body.isNotEmpty) {
            flush();
            out.add(MathSeg(body, true, n == '['));
            i = end + 2;
            continue;
          }
        }
      }
      buf.write(ch);
      i++;
      continue;
    }
    if (ch == r'$') {
      if (src.startsWith(r'$$', i)) {
        final end = src.indexOf(r'$$', i + 2);
        if (end > 0) {
          final body = src.substring(i + 2, end).trim();
          if (body.isNotEmpty) {
            flush();
            out.add(MathSeg(body, true, true));
            i = end + 2;
            continue;
          }
        }
      }
      final end = _closingDollar(src, i + 1);
      if (end > i + 1) {
        final body = src.substring(i + 1, end);
        final startsBad = body.trimLeft().length != body.length;
        final endsBad = body.trimRight().length != body.length;
        if (!startsBad && !endsBad && !_plainNumber.hasMatch(body)) {
          flush();
          out.add(MathSeg(body, true, false));
          i = end + 1;
          continue;
        }
      }
    }
    buf.write(ch);
    i++;
  }
  flush();
  return out;
}

bool hasMath(String s) => (s.contains(r'$') || s.contains('\\(') || s.contains('\\[')) && splitMath(s).any((e) => e.math);

Widget _tex(String tex, TextStyle style, {bool display = false}) {
  return Directionality(
    textDirection: TextDirection.ltr,
    child: Math.tex(
      tex,
      textStyle: style,
      mathStyle: display ? MathStyle.display : MathStyle.text,
      onErrorFallback: (err) => Text(tex, style: style.copyWith(color: const Color(0xFFFF6257))),
    ),
  );
}

final RegExp _boldRe = RegExp(r'\*\*(.+?)\*\*');

List<InlineSpan> _mdSpans(String text, {required bool markdown}) {
  if (!markdown) return [TextSpan(text: text)];
  final lines = text.split('\n').map((l) {
    var t = l;
    t = t.replaceFirst(RegExp(r'^\s*#{1,6}\s+'), '');
    t = t.replaceFirst(RegExp(r'^(\s*)[-*]\s+'), '• ');
    return t;
  }).join('\n');
  final spans = <InlineSpan>[];
  var last = 0;
  for (final m in _boldRe.allMatches(lines)) {
    if (m.start > last) spans.add(TextSpan(text: lines.substring(last, m.start)));
    spans.add(TextSpan(text: m.group(1), style: const TextStyle(fontWeight: FontWeight.w900)));
    last = m.end;
  }
  if (last < lines.length) spans.add(TextSpan(text: lines.substring(last)));
  return spans;
}

/// Text that renders LaTeX formulas ($x^2$, $$\int f$$, \(..\), \[..\]) inline with normal text.
class RichMath extends StatelessWidget {
  final String text;
  final TextStyle? style;
  final TextAlign align;
  final int? maxLines;
  final bool markdown;
  const RichMath(this.text, {super.key, this.style, this.align = TextAlign.start, this.maxLines, this.markdown = false});

  @override
  Widget build(BuildContext context) {
    final base = DefaultTextStyle.of(context).style.merge(style);
    final segs = splitMath(text);
    if (!segs.any((e) => e.math)) {
      if (!markdown) {
        return Text(text, style: style, textAlign: align, maxLines: maxLines, overflow: maxLines == null ? null : TextOverflow.ellipsis);
      }
      return Text.rich(TextSpan(children: _mdSpans(text, markdown: true)),
          style: style, textAlign: align, maxLines: maxLines, overflow: maxLines == null ? null : TextOverflow.ellipsis);
    }
    final blocks = <Widget>[];
    var cur = <InlineSpan>[];
    void flushPara() {
      if (cur.isEmpty) return;
      blocks.add(Text.rich(TextSpan(children: List<InlineSpan>.of(cur)),
          style: style, textAlign: align, maxLines: maxLines, overflow: maxLines == null ? null : TextOverflow.ellipsis));
      cur = <InlineSpan>[];
    }

    for (final seg in segs) {
      if (!seg.math) {
        cur.addAll(_mdSpans(seg.text, markdown: markdown));
      } else if (seg.display && maxLines == null) {
        flushPara();
        blocks.add(Padding(
          padding: const EdgeInsets.symmetric(vertical: 6),
          child: Center(
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: _tex(seg.text, base, display: true),
            ),
          ),
        ));
      } else {
        cur.add(WidgetSpan(alignment: PlaceholderAlignment.middle, child: _tex(seg.text, base)));
      }
    }
    flushPara();
    if (blocks.length == 1) return blocks.first;
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: align == TextAlign.center ? CrossAxisAlignment.center : CrossAxisAlignment.stretch,
      children: blocks,
    );
  }
}

// ---------------------------------------------------------------------------
// Speech: turn text containing LaTeX into something a TTS engine can read.
// ---------------------------------------------------------------------------

// [Arabic, English]
const Map<String, List<String>> _w = {
  'over': ['على', 'over'],
  'squared': ['تربيع', 'squared'],
  'cubed': ['تكعيب', 'cubed'],
  'power': ['أس', 'to the power of'],
  'sqrt': ['الجذر التربيعي لـ', 'square root of'],
  'root': ['الجذر', 'root'],
  'of': ['لـ', 'of'],
  'plus': ['زائد', 'plus'],
  'minus': ['ناقص', 'minus'],
  'equals': ['يساوي', 'equals'],
  'times': ['ضرب', 'times'],
  'divided': ['مقسومًا على', 'divided by'],
  'pm': ['زائد أو ناقص', 'plus or minus'],
  'leq': ['أصغر من أو يساوي', 'less than or equal to'],
  'geq': ['أكبر من أو يساوي', 'greater than or equal to'],
  'lt': ['أصغر من', 'less than'],
  'gt': ['أكبر من', 'greater than'],
  'neq': ['لا يساوي', 'not equal to'],
  'approx': ['يساوي تقريبًا', 'approximately equal to'],
  'infty': ['ما لا نهاية', 'infinity'],
  'sum': ['المجموع', 'the sum'],
  'prod': ['الجداء', 'the product'],
  'int': ['التكامل', 'the integral'],
  'lim': ['النهاية', 'the limit'],
  'from': ['من', 'from'],
  'to': ['إلى', 'to'],
  'as': ['عندما', 'as'],
  'approaches': ['تؤول إلى', 'approaches'],
  'sub': ['سفلي', 'sub'],
  'in': ['ينتمي إلى', 'belongs to'],
  'forall': ['لكل', 'for all'],
  'exists': ['يوجد', 'there exists'],
  'therefore': ['إذن', 'therefore'],
  'dots': ['إلى آخره', 'dot dot dot'],
  'degrees': ['درجة', 'degrees'],
  'prime': ['شرطة', 'prime'],
  'factorial': ['مضروب', 'factorial'],
  'partial': ['المشتقة الجزئية', 'partial'],
  'nabla': ['نابلا', 'nabla'],
  'sin': ['جا', 'sine'],
  'cos': ['جتا', 'cosine'],
  'tan': ['ظا', 'tangent'],
  'log': ['لوغاريتم', 'log'],
  'ln': ['اللوغاريتم الطبيعي', 'natural log'],
  'abs': ['القيمة المطلقة لـ', 'absolute value of'],
};

const Map<String, List<String>> _sym = {
  'alpha': ['ألفا', 'alpha'],
  'beta': ['بيتا', 'beta'],
  'gamma': ['غاما', 'gamma'],
  'Gamma': ['غاما', 'capital gamma'],
  'delta': ['دلتا', 'delta'],
  'Delta': ['دلتا', 'delta'],
  'epsilon': ['إبسيلون', 'epsilon'],
  'varepsilon': ['إبسيلون', 'epsilon'],
  'theta': ['ثيتا', 'theta'],
  'lambda': ['لامدا', 'lambda'],
  'mu': ['ميو', 'mu'],
  'pi': ['باي', 'pi'],
  'rho': ['رو', 'rho'],
  'sigma': ['سيجما', 'sigma'],
  'tau': ['تاو', 'tau'],
  'phi': ['فاي', 'phi'],
  'varphi': ['فاي', 'phi'],
  'omega': ['أوميغا', 'omega'],
  'Omega': ['أوميغا', 'omega'],
  'hbar': ['هـ بار', 'h bar'],
};

String _word(String k, bool ar) => (_w[k] ?? _sym[k] ?? [k, k])[ar ? 0 : 1];

bool _isLetter(String c) {
  final u = c.codeUnitAt(0);
  return (u >= 65 && u <= 90) || (u >= 97 && u <= 122);
}

class _Arg {
  final String value;
  final int next;
  const _Arg(this.value, this.next);
}

_Arg _readArg(String s, int i) {
  var k = i;
  while (k < s.length && s[k] == ' ') {
    k++;
  }
  if (k >= s.length) return _Arg('', s.length);
  if (s[k] == '{') {
    var depth = 0;
    for (var j = k; j < s.length; j++) {
      if (s[j] == '{') depth++;
      if (s[j] == '}') {
        depth--;
        if (depth == 0) return _Arg(s.substring(k + 1, j), j + 1);
      }
    }
    return _Arg(s.substring(k + 1), s.length);
  }
  if (s[k] == '\\') {
    var j = k + 1;
    if (j < s.length && _isLetter(s[j])) {
      while (j < s.length && _isLetter(s[j])) {
        j++;
      }
    } else if (j < s.length) {
      j++;
    }
    return _Arg(s.substring(k, j), j);
  }
  return _Arg(s[k], k + 1);
}

const Set<String> _passThrough = {
  'text', 'textbf', 'textit', 'mathrm', 'mathbf', 'mathit', 'mathbb', 'mathcal', 'operatorname', 'boldsymbol', 'mathsf', 'mathtt', 'rm', 'bf', 'it',
};

const Set<String> _ignore = {
  'left', 'right', 'big', 'Big', 'bigg', 'Bigg', 'displaystyle', 'textstyle', 'limits', 'nolimits', 'quad', 'qquad', 'hspace', 'vspace', 'bigl', 'bigr',
};

/// Reads a LaTeX math string aloud as words (Arabic or English).
String texToSpoken(String tex, {required bool arabic}) => _spoken(tex, arabic).replaceAll(RegExp(r'\s+'), ' ').trim();

String _spoken(String s, bool ar) {
  final b = StringBuffer();
  var limits = ''; // '' | 'ft' (sum/int/prod: from..to) | 'lim'
  var i = 0;
  while (i < s.length) {
    final c = s[i];
    if (c == '\\') {
      var j = i + 1;
      if (j >= s.length) break;
      if (!_isLetter(s[j])) {
        final sym = s[j];
        if (sym == '\\') {
          b.write(' ');
        } else if (sym == '%' || sym == '&' || sym == '#' || sym == '_') {
          b.write(sym == '_' ? ' ' : '');
        } else if (sym == '|') {
          b.write(' ${_word('abs', ar)} ');
        }
        i = j + 1;
        continue;
      }
      while (j < s.length && _isLetter(s[j])) {
        j++;
      }
      final cmd = s.substring(i + 1, j);
      i = j;
      if (_ignore.contains(cmd)) continue;
      if (_passThrough.contains(cmd)) {
        final a = _readArg(s, i);
        i = a.next;
        b.write(' ${_spoken(a.value, ar)} ');
        continue;
      }
      switch (cmd) {
        case 'frac':
        case 'dfrac':
        case 'tfrac':
          {
          final a = _readArg(s, i);
          final d = _readArg(s, a.next);
          i = d.next;
          b.write(' ${_spoken(a.value, ar)} ${_word('over', ar)} ${_spoken(d.value, ar)} ');
          }
          break;
        case 'binom':
          {
          final a = _readArg(s, i);
          final d = _readArg(s, a.next);
          i = d.next;
          b.write(' ${_spoken(a.value, ar)} ${ar ? 'اختر' : 'choose'} ${_spoken(d.value, ar)} ');
          }
          break;
        case 'sqrt':
          {
          String? index;
          var k = i;
          while (k < s.length && s[k] == ' ') {
            k++;
          }
          if (k < s.length && s[k] == '[') {
            final e = s.indexOf(']', k);
            if (e > k) {
              index = s.substring(k + 1, e);
              i = e + 1;
            }
          }
          final a = _readArg(s, i);
          i = a.next;
          if (index == null || index.trim() == '2') {
            b.write(' ${_word('sqrt', ar)} ${_spoken(a.value, ar)} ');
          } else if (index.trim() == '3') {
            b.write(' ${ar ? 'الجذر التكعيبي لـ' : 'cube root of'} ${_spoken(a.value, ar)} ');
          } else {
            b.write(' ${_word('root', ar)} ${_spoken(index, ar)} ${_word('of', ar)} ${_spoken(a.value, ar)} ');
          }
          }
          break;
        case 'sum':
        case 'prod':
        case 'int':
        case 'iint':
        case 'oint':
          b.write(' ${_word(cmd == 'sum' || cmd == 'prod' ? cmd : 'int', ar)} ');
          limits = 'ft';
          break;
        case 'lim':
          b.write(' ${_word('lim', ar)} ');
          limits = 'lim';
          break;
        case 'to':
        case 'rightarrow':
        case 'longrightarrow':
          b.write(' ${_word('approaches', ar)} ');
          break;
        case 'Rightarrow':
        case 'implies':
          b.write(' ${ar ? 'ينتج' : 'implies'} ');
          break;
        case 'leftrightarrow':
        case 'iff':
          b.write(' ${ar ? 'إذا وفقط إذا' : 'if and only if'} ');
          break;
        case 'cdot':
        case 'times':
        case 'ast':
          b.write(' ${_word('times', ar)} ');
          break;
        case 'div':
          b.write(' ${_word('divided', ar)} ');
          break;
        case 'pm':
          b.write(' ${_word('pm', ar)} ');
          break;
        case 'mp':
          b.write(ar ? ' ناقص أو زائد ' : ' minus or plus ');
          break;
        case 'leq':
        case 'le':
          b.write(' ${_word('leq', ar)} ');
          break;
        case 'geq':
        case 'ge':
          b.write(' ${_word('geq', ar)} ');
          break;
        case 'neq':
        case 'ne':
          b.write(' ${_word('neq', ar)} ');
          break;
        case 'approx':
        case 'sim':
        case 'simeq':
          b.write(' ${_word('approx', ar)} ');
          break;
        case 'infty':
          b.write(' ${_word('infty', ar)} ');
          break;
        case 'in':
          b.write(' ${_word('in', ar)} ');
          break;
        case 'forall':
          b.write(' ${_word('forall', ar)} ');
          break;
        case 'exists':
          b.write(' ${_word('exists', ar)} ');
          break;
        case 'therefore':
          b.write(' ${_word('therefore', ar)} ');
          break;
        case 'ldots':
        case 'cdots':
        case 'dots':
        case 'vdots':
          b.write(' ${_word('dots', ar)} ');
          break;
        case 'partial':
          b.write(' ${_word('partial', ar)} ');
          break;
        case 'nabla':
          b.write(' ${_word('nabla', ar)} ');
          break;
        case 'circ':
          b.write(' ${_word('degrees', ar)} ');
          break;
        case 'sin':
        case 'cos':
        case 'tan':
        case 'log':
        case 'ln':
          b.write(' ${_word(cmd, ar)} ');
          break;
        case 'sec':
        case 'csc':
        case 'cot':
        case 'sinh':
        case 'cosh':
        case 'tanh':
        case 'exp':
        case 'max':
        case 'min':
        case 'det':
        case 'arcsin':
        case 'arccos':
        case 'arctan':
          b.write(' $cmd ');
          break;
        case 'mid':
          b.write(ar ? ' بحيث ' : ' such that ');
          break;
        case 'cup':
          b.write(ar ? ' اتحاد ' : ' union ');
          break;
        case 'cap':
          b.write(ar ? ' تقاطع ' : ' intersection ');
          break;
        case 'subset':
        case 'subseteq':
          b.write(ar ? ' مجموعة جزئية من ' : ' subset of ');
          break;
        case 'emptyset':
        case 'varnothing':
          b.write(ar ? ' المجموعة الخالية ' : ' empty set ');
          break;
        case 'vec':
        case 'hat':
        case 'bar':
        case 'overline':
        case 'tilde':
        case 'dot':
          {
          final a = _readArg(s, i);
          i = a.next;
          final tag = cmd == 'vec' ? (ar ? 'متجه' : 'vector') : (cmd == 'dot' ? (ar ? 'مشتقة زمنية' : 'dot') : (cmd == 'hat' ? (ar ? 'قبعة' : 'hat') : (ar ? 'بار' : 'bar')));
          b.write(' $tag ${_spoken(a.value, ar)} ');
          }
          break;
        default:
          if (_sym.containsKey(cmd)) {
            b.write(' ${_word(cmd, ar)} ');
          } else {
            b.write(' $cmd ');
          }
      }
      continue;
    }
    if (c == '^') {
      final a = _readArg(s, i + 1);
      i = a.next;
      final v = a.value.trim();
      if (limits == 'ft') {
        b.write(' ${_word('to', ar)} ${_spoken(v, ar)} ');
        limits = '';
      } else if (v == '2') {
        b.write(' ${_word('squared', ar)} ');
      } else if (v == '3') {
        b.write(' ${_word('cubed', ar)} ');
      } else if (v == '\\circ') {
        b.write(' ${_word('degrees', ar)} ');
      } else if (v == '\\prime' || v == '\'') {
        b.write(' ${_word('prime', ar)} ');
      } else {
        b.write(' ${_word('power', ar)} ${_spoken(v, ar)} ');
      }
      continue;
    }
    if (c == '_') {
      final a = _readArg(s, i + 1);
      i = a.next;
      if (limits == 'ft') {
        b.write(' ${_word('from', ar)} ${_spoken(a.value, ar)} ');
      } else if (limits == 'lim') {
        b.write(' ${_word('as', ar)} ${_spoken(a.value, ar)} ');
        limits = '';
      } else {
        b.write(' ${_word('sub', ar)} ${_spoken(a.value, ar)} ');
      }
      continue;
    }
    switch (c) {
      case '{':
      case '}':
      case '(':
      case ')':
      case '[':
      case ']':
      case '&':
      case '~':
        b.write(' ');
        break;
      case '+':
        b.write(' ${_word('plus', ar)} ');
        break;
      case '-':
        b.write(' ${_word('minus', ar)} ');
        break;
      case '=':
        b.write(' ${_word('equals', ar)} ');
        break;
      case '<':
        b.write(' ${_word('lt', ar)} ');
        break;
      case '>':
        b.write(' ${_word('gt', ar)} ');
        break;
      case '/':
        b.write(' ${_word('over', ar)} ');
        break;
      case '*':
        b.write(' ${_word('times', ar)} ');
        break;
      case '!':
        b.write(' ${_word('factorial', ar)} ');
        break;
      case '|':
        b.write(' ${_word('abs', ar)} ');
        break;
      case '\'':
        b.write(' ${_word('prime', ar)} ');
        break;
      case ',':
        b.write(', ');
        break;
      default:
        b.write(c);
    }
    i++;
  }
  return b.toString();
}

/// Converts study text (possibly containing LaTeX and Markdown) into plain speakable text.
String latexToSpeech(String text, {required bool arabic}) {
  final b = StringBuffer();
  for (final seg in splitMath(text)) {
    if (seg.math) {
      b.write(' ${texToSpoken(seg.text, arabic: arabic)} ');
    } else {
      b.write(seg.text);
    }
  }
  return b
      .toString()
      .replaceAll(RegExp(r'\*\*|__|`'), '')
      .replaceAll(RegExp(r'^\s*#{1,6}\s+', multiLine: true), '')
      .replaceAll(RegExp(r'[ \t]+'), ' ')
      .trim();
}
