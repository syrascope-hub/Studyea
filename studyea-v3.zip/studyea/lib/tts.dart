import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;

import 'tex.dart';

final FlutterTts _tts = FlutterTts();
final AudioPlayer _onlinePlayer = AudioPlayer();
String _engine = 'auto';
String _googleKey = '';
String _elevenLabsKey = '';
double _speed = 1.0;
bool _ttsReady = false;
int _token = 0; // bumped on every speak()/stop so older playbacks are cancelled

/// A message the UI should show to the user (engine failed, no Arabic voice installed, ...).
class VoiceNotice {
  final String message;
  const VoiceNotice(this.message);
}

/// New object for every notice, so listeners fire even when the text repeats.
final ValueNotifier<VoiceNotice?> voiceNotice = ValueNotifier<VoiceNotice?>(null);

/// True while any engine is speaking (used for the waveform animation).
final ValueNotifier<bool> speaking = ValueNotifier<bool>(false);

void configureVoice({required String engine, String googleKey = '', String elevenLabsKey = '', double? speed}) {
  _engine = engine;
  _googleKey = googleKey.trim();
  _elevenLabsKey = elevenLabsKey.trim();
  if (speed != null) _speed = speed.clamp(0.5, 2.0).toDouble();
}

void _notify(String m) => voiceNotice.value = VoiceNotice(m);

Future<void> _prepareLocal() async {
  if (_ttsReady) return;
  try {
    await _tts.awaitSpeakCompletion(true);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);
  } catch (_) {}
  _ttsReady = true;
}

Future<void> stopSpeaking() async {
  _token++;
  await _stopEngines();
  speaking.value = false;
}

Future<void> _stopEngines() async {
  try {
    await _tts.stop();
  } catch (_) {}
  try {
    await _onlinePlayer.stop();
  } catch (_) {}
}

Future<void> _setLocalLanguage(bool arabic) async {
  final candidates = arabic ? ['ar-SA', 'ar', 'ar-EG', 'ar-AE', 'ar-XA'] : ['en-US', 'en-GB', 'en'];
  for (final c in candidates) {
    try {
      final ok = await _tts.isLanguageAvailable(c);
      if (ok == true || ok == 1) {
        await _tts.setLanguage(c);
        return;
      }
    } catch (_) {}
  }
  if (arabic) {
    throw StateError('لا يوجد صوت عربي مثبّت في محرك صوت الجهاز. ثبّت بيانات الصوت العربي من إعدادات الجهاز ← تحويل النص إلى كلام.');
  }
  try {
    await _tts.setLanguage('en-US');
  } catch (_) {}
}

Future<void> _speakLocal(String text, bool arabic, int token) async {
  await _prepareLocal();
  await _setLocalLanguage(arabic);
  await _tts.setSpeechRate((0.45 * _speed).clamp(0.1, 1.0).toDouble());
  if (token != _token) return;
  await _tts.speak(text);
}

String _httpMessage(String name, http.Response r) {
  String detail = '';
  try {
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    final e = j is Map ? (j['error'] ?? j['detail']) : null;
    if (e is Map) {
      detail = (e['message'] ?? e['status'] ?? '').toString();
    } else if (e != null) {
      detail = e.toString();
    }
  } catch (_) {}
  var hint = '';
  if (r.statusCode == 400 || r.statusCode == 401) hint = ' (تحقق من صحة المفتاح)';
  if (r.statusCode == 403) hint = ' (تأكد من تفعيل الخدمة على حساب المفتاح، أو أن بلدك غير محجوب)';
  if (r.statusCode == 429 || r.statusCode == 402) hint = ' (انتهت الحصة المجانية أو تجاوزت الحد)';
  return '$name: HTTP ${r.statusCode}${detail.isEmpty ? '' : ' - $detail'}$hint';
}

Future<Uint8List> _googleSpeech(String text, bool arabic) async {
  final http.Response response;
  try {
    response = await http
        .post(
          Uri.parse('https://texttospeech.googleapis.com/v1/text:synthesize?key=${Uri.encodeQueryComponent(_googleKey)}'),
          headers: const {'Content-Type': 'application/json'},
          body: jsonEncode({
            'input': {'text': text},
            'voice': {
              'languageCode': arabic ? 'ar-XA' : 'en-US',
              'ssmlGender': 'NEUTRAL',
            },
            'audioConfig': {'audioEncoding': 'MP3', 'speakingRate': _speed.clamp(0.25, 2.0)},
          }),
        )
        .timeout(const Duration(seconds: 35));
  } on TimeoutException {
    throw StateError('Google TTS: انتهت مهلة الاتصال (قد تكون الخدمة محجوبة في شبكتك)');
  } catch (e) {
    throw StateError('Google TTS: تعذر الاتصال بالإنترنت ($e)');
  }
  if (response.statusCode < 200 || response.statusCode >= 300) {
    throw StateError(_httpMessage('Google TTS', response));
  }
  final data = jsonDecode(utf8.decode(response.bodyBytes));
  final encoded = data['audioContent'] as String?;
  if (encoded == null || encoded.isEmpty) throw StateError('Google TTS: لم يرجع الخادم أي صوت.');
  return base64Decode(encoded);
}

Future<Uint8List> _elevenLabsSpeech(String text) async {
  // A multilingual voice is used so the same voice can read Arabic and English content.
  const voiceId = 'EXAVITQu4vr4xnSDxMaL';
  final http.Response response;
  try {
    response = await http
        .post(
          Uri.parse('https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128'),
          headers: {
            'Content-Type': 'application/json',
            'xi-api-key': _elevenLabsKey,
            'Accept': 'audio/mpeg',
          },
          body: jsonEncode({
            'text': text,
            'model_id': 'eleven_multilingual_v2',
            'voice_settings': {'stability': 0.5, 'similarity_boost': 0.75},
          }),
        )
        .timeout(const Duration(seconds: 45));
  } on TimeoutException {
    throw StateError('ElevenLabs: انتهت مهلة الاتصال (قد تكون الخدمة محجوبة في شبكتك)');
  } catch (e) {
    throw StateError('ElevenLabs: تعذر الاتصال بالإنترنت ($e)');
  }
  if (response.statusCode < 200 || response.statusCode >= 300) {
    throw StateError(_httpMessage('ElevenLabs', response));
  }
  if (response.bodyBytes.isEmpty) throw StateError('ElevenLabs: لم يرجع الخادم أي صوت.');
  return response.bodyBytes;
}

/// Plays bytes and completes when playback ends OR is stopped (so stop never leaves callers hanging).
Future<void> _playBytes(Uint8List bytes, int token, double rate) async {
  if (token != _token) return;
  final done = Completer<void>();
  final s1 = _onlinePlayer.onPlayerComplete.listen((_) {
    if (!done.isCompleted) done.complete();
  });
  final s2 = _onlinePlayer.onPlayerStateChanged.listen((st) {
    if ((st == PlayerState.stopped || st == PlayerState.completed) && !done.isCompleted) done.complete();
  });
  try {
    await _onlinePlayer.setPlaybackRate(rate);
    await _onlinePlayer.play(BytesSource(bytes));
    await done.future.timeout(const Duration(minutes: 5), onTimeout: () {});
  } finally {
    await s1.cancel();
    await s2.cancel();
  }
}

List<String> _chunks(String text, int max) {
  if (text.length <= max) return [text];
  final out = <String>[];
  final parts = text.split(RegExp(r'(?<=[.!?؟۔\n])\s+'));
  var cur = StringBuffer();
  for (final p in parts) {
    if (cur.length + p.length + 1 > max && cur.isNotEmpty) {
      out.add(cur.toString().trim());
      cur = StringBuffer();
    }
    if (p.length > max) {
      for (var i = 0; i < p.length; i += max) {
        out.add(p.substring(i, i + max > p.length ? p.length : i + max));
      }
    } else {
      cur.write('$p ');
    }
  }
  if (cur.toString().trim().isNotEmpty) out.add(cur.toString().trim());
  return out;
}

/// Speaks one chunk with one specific engine. Throws a readable error when that engine fails.
Future<void> _speakWith(String engine, String chunk, bool arabic, int token) async {
  switch (engine) {
    case 'google':
      {
        if (_googleKey.isEmpty) throw StateError('Google TTS: لم يتم إدخال المفتاح في الإعدادات.');
        final bytes = await _googleSpeech(chunk, arabic);
        await _playBytes(bytes, token, 1.0);
        return;
      }
    case 'elevenlabs':
      {
        if (_elevenLabsKey.isEmpty) throw StateError('ElevenLabs: لم يتم إدخال المفتاح في الإعدادات.');
        final bytes = await _elevenLabsSpeech(chunk);
        await _playBytes(bytes, token, _speed);
        return;
      }
    default:
      await _speakLocal(chunk, arabic, token);
  }
}

List<String> _enginePlan() {
  switch (_engine) {
    case 'google':
      return ['google', 'local'];
    case 'elevenlabs':
      return ['elevenlabs', 'local'];
    case 'local':
      return ['local'];
    default:
      return [if (_googleKey.isNotEmpty) 'google', if (_elevenLabsKey.isNotEmpty) 'elevenlabs', 'local'];
  }
}

final RegExp _arabicRe = RegExp(r'[؀-ۿ]');

/// Reads text (LaTeX formulas are converted to words) using the selected engine.
/// Falls back to the device voice when an online engine fails, and tells the user why.
Future<void> speak(String text) async {
  final raw = text.replaceAll(RegExp(r'\{\{|\}\}'), '').trim();
  if (raw.isEmpty) return;
  final arabic = _arabicRe.hasMatch(raw);
  final clean = latexToSpeech(raw, arabic: arabic);
  if (clean.isEmpty) return;
  final my = ++_token;
  await _stopEngines();
  speaking.value = true;
  final failed = <String>{};
  try {
    for (final chunk in _chunks(clean, 900)) {
      if (my != _token) return;
      var spoke = false;
      for (final e in _enginePlan()) {
        if (failed.contains(e)) continue;
        if (my != _token) return;
        try {
          await _speakWith(e, chunk, arabic, my);
          spoke = true;
          break;
        } catch (err) {
          failed.add(e);
          final msg = err.toString().replaceFirst('Bad state: ', '');
          if (e == 'local') {
            _notify(msg);
          } else {
            _notify('$msg\nتم استخدام صوت الجهاز بدلًا منه.');
          }
        }
      }
      if (!spoke) return;
    }
  } finally {
    if (my == _token) speaking.value = false;
  }
}

/// Used by Settings: speaks a sample with exactly one engine and returns null on success or an error text.
Future<String?> testVoice(String engine, {String googleKey = '', String elevenLabsKey = '', bool arabic = true}) async {
  final oldG = _googleKey, oldE = _elevenLabsKey;
  if (googleKey.trim().isNotEmpty) _googleKey = googleKey.trim();
  if (elevenLabsKey.trim().isNotEmpty) _elevenLabsKey = elevenLabsKey.trim();
  try {
    final my = ++_token;
    await _stopEngines();
    speaking.value = true;
    final sample = arabic ? r'مرحبًا، هذا اختبار الصوت في ستديا. الدالة $x^2$ تُقرأ هكذا.' : r'Hello, this is a Studyea voice test. The function $x^2$ is read like this.';
    final spoken = latexToSpeech(sample, arabic: arabic);
    await _speakWith(engine, spoken, arabic, my);
    return null;
  } catch (e) {
    return e.toString().replaceFirst('Bad state: ', '');
  } finally {
    speaking.value = false;
    _googleKey = oldG;
    _elevenLabsKey = oldE;
  }
}
