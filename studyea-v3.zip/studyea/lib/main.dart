import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quick_actions/quick_actions.dart';
import 'store.dart';
import 'neu.dart';
import 'decks.dart';
import 'mind.dart';
import 'splash.dart';
import 'onboarding.dart';
import 'study.dart';
import 'home.dart';
import 'focus.dart';
import 'more.dart';
import 'tts.dart';

final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();
final GlobalKey<ScaffoldMessengerState> msgKey = GlobalKey<ScaffoldMessengerState>();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ChangeNotifierProvider(create: (_) => Store()..load(), child: const StudyeaApp()));
}

class StudyeaApp extends StatefulWidget {
  const StudyeaApp({super.key});
  @override
  State<StudyeaApp> createState() => _StudyeaAppState();
}

class _StudyeaAppState extends State<StudyeaApp> {
  bool splashDone = false;
  String? pending;

  void _onVoice() {
    final n = voiceNotice.value;
    if (n == null) return;
    msgKey.currentState
      ?..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(n.message),
        duration: const Duration(seconds: 6),
        behavior: SnackBarBehavior.floating,
      ));
  }

  @override
  void dispose() {
    voiceNotice.removeListener(_onVoice);
    super.dispose();
  }

  @override
  void initState() {
    super.initState();
    voiceNotice.addListener(_onVoice);
    try {
      final qa = QuickActions();
      qa.initialize((type) {
        pending = type;
        _tryQuick();
      });
      qa.setShortcutItems([
        ShortcutItem(type: 'review', localizedTitle: 'Review / مراجعة'),
        ShortcutItem(type: 'add', localizedTitle: 'New card / بطاقة جديدة'),
      ]);
    } catch (_) {}
  }

  void _tryQuick() {
    final s = context.read<Store>();
    if (pending == null || !(s.loaded && splashDone && s.onboarded)) return;
    final nav = navKey.currentState;
    if (nav == null) return;
    final t = pending!;
    pending = null;
    if (t == 'review') {
      final now = DateTime.now().millisecondsSinceEpoch;
      final due = s.cards.where((c) => c.due <= now).toList();
      if (due.isNotEmpty) nav.push(MaterialPageRoute(builder: (_) => ReviewPage(cards: due)));
    } else {
      final dk = s.decks.isEmpty ? s.addDeck(s.t('general')) : s.decks.first;
      nav.push(MaterialPageRoute(builder: (_) => CardEditor(deckId: dk.id)));
    }
  }

  void _after() => WidgetsBinding.instance.addPostFrameCallback((_) => _tryQuick());

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    gTheme = s.themeIdx;
    final b = s.dark ? Brightness.dark : Brightness.light;
    Widget home;
    if (!(s.loaded && splashDone)) {
      home = Splash(
        key: const ValueKey('splash'),
        onDone: () {
          setState(() => splashDone = true);
          _after();
        },
      );
    } else if (!s.onboarded) {
      home = Onboarding(
        key: const ValueKey('onb'),
        onDone: () {
          s.onboarded = true;
          s.changed();
          _after();
        },
      );
    } else {
      home = const Shell(key: ValueKey('shell'));
    }
    return MaterialApp(
      title: 'Studyea',
      navigatorKey: navKey,
      scaffoldMessengerKey: msgKey,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: b,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kAccent,
          brightness: b,
          surface: neuCard(s.dark),
          primary: kAccent,
          secondary: kLime,
          tertiary: kOrange,
          error: kCoral,
          onPrimary: Colors.white,
          onSecondary: kInk,
          onTertiary: kInk,
        ),
        scaffoldBackgroundColor: neuBg(s.dark),
        appBarTheme: AppBarTheme(
          backgroundColor: neuBg(s.dark),
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: neuText(s.dark),
            fontSize: 22,
            fontWeight: FontWeight.w900,
          ),
        ),
        cardTheme: CardThemeData(
          color: neuCard(s.dark),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: s.dark ? kCream : kInk, width: 2),
          ),
        ),
        dividerTheme: DividerThemeData(
          color: s.dark ? Colors.white24 : Colors.black26,
          thickness: 1.5,
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: s.dark ? const Color(0xFF302A3A) : kInk,
          contentTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
      builder: (c, child) => MediaQuery(
        data: MediaQuery.of(c).copyWith(textScaler: TextScaler.linear(s.fontScale)),
        child: Directionality(
          textDirection: s.lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
          child: child!,
        ),
      ),
      home: AnimatedSwitcher(duration: const Duration(milliseconds: 500), child: home),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  void go(int k) => setState(() => i = k);

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final tabs = [
      (Icons.home_rounded, s.tr('الرئيسية', 'Home')),
      (Icons.style_rounded, s.tr('مكتبتي', 'Library')),
      (Icons.account_tree_rounded, s.tr('الخرائط', 'Maps')),
      (Icons.timer_rounded, s.tr('التركيز', 'Focus')),
      (Icons.grid_view_rounded, s.tr('المزيد', 'More')),
    ];
    return Scaffold(
      backgroundColor: neuBg(d),
      body: IndexedStack(index: i, children: [
        HomePage(onTab: go),
        const DecksPage(),
        const MapsPage(),
        const FocusPage(),
        const MorePage(),
      ]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 10),
          child: NeuBox(
            radius: 24,
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
            child: Row(children: [
              for (var k = 0; k < tabs.length; k++)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => go(k),
                    child: NeuBox(
                      inset: i == k,
                      radius: 18,
                      padding: const EdgeInsets.symmetric(vertical: 7),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(tabs[k].$1, size: 22, color: i == k ? kAccent : neuText(d).withValues(alpha: .6)),
                        const SizedBox(height: 2),
                        Text(tabs[k].$2,
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                                fontSize: 10,
                                fontWeight: FontWeight.w800,
                                color: i == k ? kAccent : neuText(d).withValues(alpha: .6))),
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}
