import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neu.dart';
import 'store.dart';

class Onboarding extends StatefulWidget {
  final VoidCallback onDone;
  const Onboarding({super.key, required this.onDone});
  @override
  State<Onboarding> createState() => _OnboardingState();
}

class _OnboardingState extends State<Onboarding> {
  final pc = PageController();
  final nameC = TextEditingController();
  int i = 0;
  static const icons = [Icons.style_rounded, Icons.insights_rounded, Icons.account_tree_rounded, Icons.notifications_active_rounded];

  @override
  void dispose() {
    pc.dispose();
    nameC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final last = i == 3;
    return Scaffold(
      backgroundColor: neuBg(d),
      body: SafeArea(
        child: Column(children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              for (final l in [('ar', 'العربية'), ('en', 'English')])
                Padding(
                  padding: const EdgeInsetsDirectional.only(end: 8),
                  child: NeuButton(
                    filled: s.lang == l.$1,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    onTap: () {
                      s.lang = l.$1;
                      s.changed();
                    },
                    child: Text(l.$2, style: const TextStyle(fontSize: 12)),
                  ),
                ),
              const Spacer(),
              if (!last) NeuButton(padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8), onTap: widget.onDone, child: Text(s.t('skip'), style: const TextStyle(fontSize: 12))),
            ]),
          ),
          Expanded(
            child: PageView.builder(
              controller: pc,
              itemCount: 4,
              onPageChanged: (v) => setState(() => i = v),
              itemBuilder: (_, k) => Center(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(28),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                  NeuBox(
                    depth: 8,
                    radius: 28,
                    padding: const EdgeInsets.all(36),
                    child: Icon(icons[k], size: 90, color: kAccent),
                  ),
                  const SizedBox(height: 40),
                  Text(s.t('onb${k + 1}t'),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 28, fontWeight: FontWeight.w900, color: neuText(d))),
                  const SizedBox(height: 14),
                  Text(s.t('onb${k + 1}d'),
                      textAlign: TextAlign.center,
                      style: TextStyle(fontSize: 15, height: 1.6, color: neuText(d).withValues(alpha: .75))),
                  if (k == 3) ...[
                    const SizedBox(height: 22),
                    NeuField(controller: nameC, hint: s.tr('اسمك (اختياري)', 'Your name (optional)')),
                  ],
                ]),
                ),
              ),
            ),
          ),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            for (var k = 0; k < 4; k++)
              AnimatedContainer(
                duration: const Duration(milliseconds: 250),
                margin: const EdgeInsets.all(4),
                width: k == i ? 28 : 12,
                height: 12,
                decoration: BoxDecoration(
                  color: k == i ? kAccent : neuBg(d),
                  border: Border.all(color: neuLo(d), width: 2),
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
          ]),
          Padding(
            padding: const EdgeInsets.all(20),
            child: SizedBox(
              width: double.infinity,
              child: NeuButton(
                filled: true,
                onTap: () {
                  if (last) {
                    s.userName = nameC.text.trim();
                    widget.onDone();
                  } else {
                    pc.nextPage(duration: const Duration(milliseconds: 350), curve: Curves.easeOutCubic);
                  }
                },
                child: Center(child: Text(last ? s.t('letsGo') : s.t('next'))),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
