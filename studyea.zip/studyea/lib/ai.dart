import 'dart:convert';
import 'dart:typed_data';
import 'package:http/http.dart' as http;
import 'models.dart';
import 'store.dart';

dynamic extractJson(String text) {
  var s = text.replaceAll('```json', '').replaceAll('```', '').trim();
  final a = s.indexOf(RegExp(r'[\[{]'));
  if (a < 0) throw 'Bad AI response';
  final isArr = s[a] == '[';
  final b = s.lastIndexOf(isArr ? ']' : '}');
  if (b <= a) throw 'Bad AI response';
  return jsonDecode(s.substring(a, b + 1));
}

class Ai {
  final Store s;
  Ai(this.s);

  String get _langName => s.lang == 'ar' ? 'Arabic' : 'English';

  Future<String> ask(String prompt) async {
    if (s.provider == 'gemini') {
      if (s.geminiKey.isEmpty) throw s.t('aiNeedsKey');
      final m = s.model.isEmpty ? 'gemini-2.0-flash' : s.model;
      final r = await http
          .post(
            Uri.parse('https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent'),
            headers: {'Content-Type': 'application/json', 'x-goog-api-key': s.geminiKey},
            body: jsonEncode({
              'contents': [
                {
                  'parts': [
                    {'text': prompt}
                  ]
                }
              ]
            }),
          )
          .timeout(const Duration(seconds: 60));
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      if (r.statusCode != 200) throw (j['error']?['message'] ?? 'HTTP ${r.statusCode}').toString();
      return j['candidates'][0]['content']['parts'][0]['text'] as String;
    } else {
      if (s.hfKey.isEmpty) throw s.t('aiNeedsKey');
      final m = s.model.isEmpty ? 'meta-llama/Llama-3.1-8B-Instruct' : s.model;
      final r = await http
          .post(
            Uri.parse('https://router.huggingface.co/v1/chat/completions'),
            headers: {'Content-Type': 'application/json', 'Authorization': 'Bearer ${s.hfKey}'},
            body: jsonEncode({
              'model': m,
              'messages': [
                {'role': 'user', 'content': prompt}
              ],
              'max_tokens': 2000,
            }),
          )
          .timeout(const Duration(seconds: 60));
      final j = jsonDecode(utf8.decode(r.bodyBytes));
      if (r.statusCode != 200) throw (j['error']?['message'] ?? j['error'] ?? 'HTTP ${r.statusCode}').toString();
      return j['choices'][0]['message']['content'] as String;
    }
  }

  Future<List<List<String>>> cardsFromText(String text) async {
    final out = await ask(
        'Create flashcards from the text below. Return ONLY a JSON array like [{"front":"...","back":"..."}]. '
        'Keep them short. Language: $_langName unless the text is in another language.\n\nTEXT:\n$text');
    final j = extractJson(out) as List;
    return j.map<List<String>>((e) => [e['front'].toString(), e['back'].toString()]).toList();
  }

  Future<List<String>> examples(String word) async {
    final out = await ask('Give 3 short natural example sentences using "$word". '
        'Return ONLY a JSON array of strings, in the same language as the word.');
    return (extractJson(out) as List).map((e) => e.toString()).toList();
  }

  Future<String> explain(String front, String back) =>
      ask('Explain this flashcard simply in $_langName, in at most 5 sentences.\nFront: $front\nBack: $back');

  Future<MNode> mindMap(String topic) async {
    final out = await ask(
        'Create a mind map about "$topic". Return ONLY JSON: {"text":"...","children":[{"text":"...","children":[]}]}. '
        'Use 4-6 main branches, max depth 3, labels of 1-4 words, language: $_langName.');
    return _toNode(extractJson(out));
  }

  Future<List<String>> expand(String topic, String context) async {
    final out = await ask('Mind map about "$context". Suggest 3-5 sub-branches for "$topic". '
        'Return ONLY a JSON array of short strings (1-4 words), language: $_langName.');
    return (extractJson(out) as List).map((e) => e.toString()).toList();
  }

  MNode _toNode(dynamic j) => MNode(newId(), j['text'].toString(),
      (j['children'] as List? ?? []).map<MNode>((e) => _toNode(e)).toList());

  Future<Uint8List> image(String prompt) async {
    final p = 'simple clear educational illustration of: $prompt';
    if (s.hfKey.isNotEmpty) {
      try {
        final r = await http
            .post(
              Uri.parse('https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell'),
              headers: {'Authorization': 'Bearer ${s.hfKey}', 'Content-Type': 'application/json'},
              body: jsonEncode({'inputs': p}),
            )
            .timeout(const Duration(seconds: 90));
        if (r.statusCode == 200 && (r.headers['content-type'] ?? '').startsWith('image')) return r.bodyBytes;
      } catch (_) {}
    }
    final r = await http
        .get(Uri.https('image.pollinations.ai', '/prompt/${Uri.encodeComponent(p)}',
            {'width': '512', 'height': '512', 'nologo': 'true'}))
        .timeout(const Duration(seconds: 90));
    if (r.statusCode != 200) throw 'Image error ${r.statusCode}';
    return r.bodyBytes;
  }
}
