import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models.dart';
import 'neu.dart';
import 'store.dart';
import 'tts.dart';

final _clozeRe = RegExp(r'\{\{(.*?)\}\}');

(String, String) cardQA(CardM c) {
  if (c.type == 'cloze') {
    final m = _clozeRe.firstMatch(c.front);
    return (c.front.replaceAllMapped(_clozeRe, (_) => '[...]'), m?.group(1) ?? c.back);
  }
  return (c.front, c.back);
}

String clozeFull(CardM c) => c.front.replaceAllMapped(_clozeRe, (m) => m.group(1) ?? '');

class ReviewPage extends StatefulWidget {
  final List<CardM> cards;
  final bool cram;
  const ReviewPage({super.key, required this.cards, this.cram = false});
  @override
  State<ReviewPage> createState() => _ReviewPageState();
}

class _ReviewPageState extends State<ReviewPage> {
  late List<CardM> queue = [...widget.cards]..shuffle();
  bool flipped = false;
  double dx = 0;
  int done = 0;

  void answer(int q) {
    final s = context.read<Store>();
    final c = queue.first;
    if (widget.cram) {
      s.addXp(q >= 3 ? 2 : 0);
    } else {
      s.review(c, q);
    }
    setState(() {
      queue.removeAt(0);
      if (q < 3) queue.add(c);
      if (q >= 3) done++;
      flipped = false;
      dx = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    if (queue.isEmpty) {
      return NeuPage(
        title: s.t('study'),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Icon(Icons.emoji_events_rounded, size: 80, color: kAccent),
            const SizedBox(height: 12),
            Text(s.t('done'), style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: neuText(d))),
            const SizedBox(height: 20),
            NeuButton(filled: true, onTap: () => Navigator.pop(context), child: Text(s.t('finish'))),
          ]),
        ),
      );
    }
    final c = queue.first;
    final qa = cardQA(c);
    final shownText = flipped ? (c.type == 'cloze' ? clozeFull(c) : qa.$2) : qa.$1;
    final opts = <String>[];
    if (c.type == 'mcq' && !flipped) {
      opts
        ..addAll(c.options)
        ..add(c.back)
        ..shuffle(Random(c.id.hashCode));
    }
    return NeuPage(
      title: '${s.t('study')} · ${queue.length}',
      body: Column(children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: GestureDetector(
              onTap: () => setState(() => flipped = !flipped),
              onHorizontalDragUpdate: (u) => setState(() => dx += u.delta.dx),
              onHorizontalDragEnd: (_) {
                if (dx > 110) {
                  answer(4);
                } else if (dx < -110) {
                  answer(0);
                } else {
                  setState(() => dx = 0);
                }
              },
              child: Transform.translate(
                offset: Offset(dx, 0),
                child: Transform.rotate(
                  angle: dx / 1200,
                  child: SizedBox(
                    width: double.infinity,
                    child: NeuBox(
                      radius: 28,
                      depth: 9,
                      padding: const EdgeInsets.all(22),
                      color: dx > 40
                          ? Color.lerp(neuBg(d), Colors.green, .25)
                          : dx < -40
                              ? Color.lerp(neuBg(d), Colors.red, .25)
                              : null,
                      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                        Align(
                          alignment: AlignmentDirectional.topEnd,
                          child: NeuIcon(Icons.volume_up_rounded, size: 20, onTap: () => speak(shownText)),
                        ),
                        Expanded(
                          child: Center(
                            child: SingleChildScrollView(
                              child: Column(mainAxisSize: MainAxisSize.min, children: [
                                if (c.image != null && File(c.image!).existsSync())
                                  Padding(
                                    padding: const EdgeInsets.only(bottom: 16),
                                    child: ClipRRect(
                                        borderRadius: BorderRadius.circular(16),
                                        child: Image.file(File(c.image!), height: 160, fit: BoxFit.cover)),
                                  ),
                                Text(shownText,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        fontSize: 24,
                                        fontWeight: FontWeight.w700,
                                        color: flipped ? kAccent : neuText(d))),
                                for (final o in opts)
                                  Padding(
                                    padding: const EdgeInsets.only(top: 8),
                                    child: Text('• $o', style: TextStyle(fontSize: 16, color: neuText(d))),
                                  ),
                              ]),
                            ),
                          ),
                        ),
                        Text(s.t('tapFlip'), style: TextStyle(fontSize: 12, color: neuText(d).withOpacity(.5))),
                      ]),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
          child: flipped
              ? Row(children: [
                  for (final b in [('again', 0), ('hard', 3), ('good', 4), ('easy', 5)])
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 4),
                        child: NeuButton(
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          onTap: () => answer(b.$2),
                          child: Center(child: Text(s.t(b.$1), style: const TextStyle(fontSize: 13))),
                        ),
                      ),
                    ),
                ])
              : Text(s.t('swipeHint'),
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: neuText(d).withOpacity(.6))),
        ),
      ]),
    );
  }
}

class _Q {
  final String text;
  final List<String> opts;
  final int correct;
  _Q(this.text, this.opts, this.correct);
}

class QuizPage extends StatefulWidget {
  final List<CardM> cards;
  final bool tf;
  const QuizPage({super.key, required this.cards, this.tf = false});
  @override
  State<QuizPage> createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  final rnd = Random();
  late final List<_Q> qs = _build();
  int idx = 0, score = 0, sel = -1;

  List<_Q> _build() {
    final s = context.read<Store>();
    final pool = widget.cards.map((c) => cardQA(c).$2).toSet().toList();
    final list = [...widget.cards]..shuffle(rnd);
    final out = <_Q>[];
    for (final c in list.take(10)) {
      final qa = cardQA(c);
      final wrong = <String>{...(c.type == 'mcq' ? c.options : <String>[]), ...(pool..shuffle(rnd))}
        ..remove(qa.$2)
        ..remove('');
      if (wrong.isEmpty) continue;
      if (widget.tf) {
        final truth = rnd.nextBool();
        final stmt = truth ? qa.$2 : wrong.first;
        out.add(_Q('${qa.$1}\n\n= $stmt ?', [s.t('trueT'), s.t('falseT')], truth ? 0 : 1));
      } else {
        final o = [qa.$2, ...wrong.take(3)]..shuffle(rnd);
        out.add(_Q(qa.$1, o, o.indexOf(qa.$2)));
      }
    }
    return out;
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    if (qs.isEmpty) return NeuPage(title: s.t('quiz'), body: Center(child: Text(s.t('needMore'))));
    if (idx >= qs.length) {
      return NeuPage(
        title: s.t('quiz'),
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('${s.t('score')}: $score / ${qs.length}',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, color: kAccent)),
            const SizedBox(height: 20),
            NeuButton(
                filled: true,
                onTap: () {
                  s.addXp(score * 3);
                  Navigator.pop(context);
                },
                child: Text(s.t('finish'))),
          ]),
        ),
      );
    }
    final q = qs[idx];
    return NeuPage(
      title: '${s.t('quiz')} ${idx + 1}/${qs.length}',
      body: ListView(padding: const EdgeInsets.all(16), children: [
        NeuBox(
          padding: const EdgeInsets.all(22),
          child: Text(q.text,
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w700, color: neuText(d))),
        ),
        const SizedBox(height: 20),
        for (var i = 0; i < q.opts.length; i++)
          Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: NeuButton(
              fill: sel == -1
                  ? null
                  : i == q.correct
                      ? Colors.green.shade600
                      : i == sel
                          ? Colors.red.shade600
                          : null,
              onTap: () {
                if (sel != -1) return;
                setState(() {
                  sel = i;
                  if (i == q.correct) score++;
                });
              },
              child: SizedBox(width: double.infinity, child: Text(q.opts[i], textAlign: TextAlign.center)),
            ),
          ),
        if (sel != -1)
          NeuButton(
            filled: true,
            onTap: () => setState(() {
              idx++;
              sel = -1;
            }),
            child: Center(child: Text(idx + 1 >= qs.length ? s.t('finish') : '→')),
          ),
      ]),
    );
  }
}
