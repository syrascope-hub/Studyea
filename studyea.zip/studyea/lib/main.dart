import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'store.dart';
import 'neu.dart';
import 'decks.dart';
import 'mind.dart';
import 'other.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ChangeNotifierProvider(create: (_) => Store()..load(), child: const StudyeaApp()));
}

class StudyeaApp extends StatelessWidget {
  const StudyeaApp({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final b = s.dark ? Brightness.dark : Brightness.light;
    return MaterialApp(
      title: 'Studyea',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: b,
        useMaterial3: true,
        colorSchemeSeed: kAccent,
        scaffoldBackgroundColor: neuBg(s.dark),
      ),
      builder: (c, child) => Directionality(
        textDirection: s.lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
        child: child!,
      ),
      home: s.loaded ? const Shell() : const Scaffold(body: Center(child: CircularProgressIndicator())),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final tabs = [
      (Icons.style_rounded, s.t('decks')),
      (Icons.account_tree_rounded, s.t('mindmaps')),
      (Icons.insights_rounded, s.t('stats')),
      (Icons.tune_rounded, s.t('settings')),
    ];
    return Scaffold(
      backgroundColor: neuBg(d),
      body: IndexedStack(index: i, children: const [DecksPage(), MapsPage(), StatsPage(), SettingsPage()]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: NeuBox(
            radius: 26,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(children: [
              for (var k = 0; k < tabs.length; k++)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => setState(() => i = k),
                    child: NeuBox(
                      inset: i == k,
                      radius: 20,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(tabs[k].$1, color: i == k ? kAccent : neuText(d).withOpacity(.6)),
                        Text(tabs[k].$2,
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: i == k ? kAccent : neuText(d).withOpacity(.6))),
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}
