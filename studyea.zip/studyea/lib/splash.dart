import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neu.dart';
import 'store.dart';

class AppLogo extends StatelessWidget {
  final double size, fan;
  const AppLogo({super.key, this.size = 120, this.fan = 1});
  @override
  Widget build(BuildContext context) => CustomPaint(size: Size(size, size), painter: _LogoPainter(fan));
}

class _LogoPainter extends CustomPainter {
  final double fan;
  _LogoPainter(this.fan);
  @override
  void paint(Canvas c, Size sz) {
    final w = sz.width;
    final bg = RRect.fromRectAndRadius(Rect.fromLTWH(0, 0, w, w), Radius.circular(w * .24));
    c.drawShadow(Path()..addRRect(bg), Colors.black, 10, true);
    c.drawRRect(
        bg,
        Paint()
          ..shader = const LinearGradient(
                  begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF8E85FF), Color(0xFF5B52E8)])
              .createShader(Rect.fromLTWH(0, 0, w, w)));
    void card(double rot, Offset off, Color col, bool details) {
      c.save();
      c.translate(w / 2 + off.dx * w, w / 2 + off.dy * w);
      c.rotate(rot);
      final r = RRect.fromRectAndRadius(
          Rect.fromCenter(center: Offset.zero, width: w * .46, height: w * .58), Radius.circular(w * .07));
      c.drawShadow(Path()..addRRect(r), Colors.black, 6, true);
      c.drawRRect(r, Paint()..color = col);
      if (details) {
        final acc = Paint()..color = const Color(0xFF6C63FF);
        final cw = w * .46, ch = w * .58;
        c.drawCircle(Offset(-cw * .26, -ch * .28), cw * .1, acc);
        final chk = Paint()
          ..color = Colors.white
          ..style = PaintingStyle.stroke
          ..strokeCap = StrokeCap.round
          ..strokeWidth = w * .016;
        final cx = -cw * .26, cy = -ch * .28;
        c.drawPath(
            Path()
              ..moveTo(cx - cw * .05, cy)
              ..lineTo(cx - cw * .01, cy + cw * .04)
              ..lineTo(cx + cw * .06, cy - cw * .04),
            chk);
        for (var i = 0; i < 3; i++) {
          final ln = [.9, .7, .8][i];
          c.drawRRect(
              RRect.fromRectAndRadius(
                  Rect.fromLTWH(-cw * .36, ch * (-.04 + i * .16), cw * .72 * ln, ch * .06), Radius.circular(ch * .03)),
              Paint()..color = const Color(0x556C63FF));
        }
      }
      c.restore();
    }

    card(0.24 * fan, Offset(-.07 * fan, 0), const Color(0x99FFFFFF), false);
    card(-0.14 * fan, Offset(.04 * fan, .01), Colors.white, true);
  }

  @override
  bool shouldRepaint(covariant _LogoPainter o) => o.fan != fan;
}

class Splash extends StatefulWidget {
  final VoidCallback onDone;
  const Splash({super.key, required this.onDone});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> with SingleTickerProviderStateMixin {
  late final AnimationController c = AnimationController(vsync: this, duration: const Duration(milliseconds: 3200));

  @override
  void initState() {
    super.initState();
    c.forward().then((_) async {
      await Future.delayed(const Duration(milliseconds: 250));
      if (mounted) widget.onDone();
    });
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  Animation<double> iv(double a, double b, Curve cv) => CurvedAnimation(parent: c, curve: Interval(a, b, curve: cv));

  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    final s = context.read<Store>();
    const name = 'Studyea';
    final logo = iv(0.0, .5, Curves.elasticOut);
    final fan = iv(.2, .6, Curves.easeOutCubic);
    final tag = iv(.65, .9, Curves.easeOut);
    return Scaffold(
      backgroundColor: neuBg(d),
      body: AnimatedBuilder(
        animation: c,
        builder: (context, _) {
          final t = c.value;
          return Stack(alignment: Alignment.center, children: [
            // floating blurred orbs
            for (var i = 0; i < 3; i++)
              Positioned(
                left: MediaQuery.of(context).size.width * [.1, .65, .35][i] + sin(t * 4 + i) * 14,
                top: MediaQuery.of(context).size.height * [.12, .25, .72][i] + cos(t * 3 + i) * 14,
                child: Container(
                  width: [150.0, 110.0, 180.0][i],
                  height: [150.0, 110.0, 180.0][i],
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    gradient: RadialGradient(colors: [
                      [kAccent, const Color(0xFF00B894), const Color(0xFFFF7675)][i].withOpacity(d ? .22 : .16),
                      Colors.transparent
                    ]),
                  ),
                ),
              ),
            Column(mainAxisSize: MainAxisSize.min, children: [
              Transform.rotate(
                angle: (1 - logo.value) * -0.9,
                child: Transform.scale(
                  scale: logo.value.clamp(0.0, 1.25),
                  child: Opacity(
                    opacity: (t * 6).clamp(0.0, 1.0),
                    child: AppLogo(size: 150, fan: fan.value),
                  ),
                ),
              ),
              const SizedBox(height: 34),
              Row(mainAxisSize: MainAxisSize.min, children: [
                for (var i = 0; i < name.length; i++)
                  Builder(builder: (_) {
                    final v = iv(.35 + i * .045, .55 + i * .045, Curves.easeOutBack).value;
                    return Opacity(
                      opacity: v.clamp(0.0, 1.0),
                      child: Transform.translate(
                        offset: Offset(0, (1 - v) * 26),
                        child: Text(name[i],
                            style: TextStyle(
                                fontSize: 40,
                                fontWeight: FontWeight.w900,
                                letterSpacing: 1.5,
                                color: i % 2 == 0 ? neuText(d) : kAccent)),
                      ),
                    );
                  }),
              ]),
              const SizedBox(height: 12),
              Opacity(
                opacity: tag.value.clamp(0.0, 1.0),
                child: Transform.translate(
                  offset: Offset(0, (1 - tag.value) * 12),
                  child: Text(s.t('tagline'),
                      style: TextStyle(fontSize: 15, color: neuText(d).withOpacity(.65), letterSpacing: .5)),
                ),
              ),
              const SizedBox(height: 40),
              SizedBox(
                width: 140,
                child: NeuBox(
                  inset: true,
                  radius: 8,
                  padding: const EdgeInsets.all(3),
                  child: Align(
                    alignment: AlignmentDirectional.centerStart,
                    child: FractionallySizedBox(
                      widthFactor: t.clamp(0.02, 1.0),
                      child: Container(
                          height: 6,
                          decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(6))),
                    ),
                  ),
                ),
              ),
            ]),
          ]);
        },
      ),
    );
  }
}
