import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'models.dart';
import 'neu.dart';
import 'store.dart';
import 'study.dart';

class PomodoroPage extends StatefulWidget {
  const PomodoroPage({super.key});
  @override
  State<PomodoroPage> createState() => _PomodoroPageState();
}

class _PomodoroPageState extends State<PomodoroPage> {
  bool focus = true, running = false;
  int left = 25 * 60;
  Timer? timer;

  void toggle() {
    if (running) {
      timer?.cancel();
      setState(() => running = false);
      return;
    }
    setState(() => running = true);
    timer = Timer.periodic(const Duration(seconds: 1), (_) {
      if (left <= 1) {
        if (focus) context.read<Store>().addXp(25);
        setState(() {
          focus = !focus;
          left = (focus ? 25 : 5) * 60;
        });
      } else {
        setState(() => left--);
      }
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final mm = (left ~/ 60).toString().padLeft(2, '0'), ss = (left % 60).toString().padLeft(2, '0');
    final total = (focus ? 25 : 5) * 60;
    return NeuPage(
      title: s.t('pomodoro'),
      body: Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(focus ? s.t('focus') : s.t('breakT'),
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: focus ? kAccent : Colors.green)),
          const SizedBox(height: 24),
          NeuBox(
            radius: 200,
            depth: 12,
            padding: const EdgeInsets.all(18),
            child: NeuBox(
              inset: true,
              radius: 200,
              padding: const EdgeInsets.all(30),
              child: SizedBox(
                width: 190,
                height: 190,
                child: Stack(alignment: Alignment.center, children: [
                  SizedBox.expand(
                    child: CircularProgressIndicator(
                        value: 1 - left / total, strokeWidth: 8, color: kAccent, backgroundColor: Colors.transparent),
                  ),
                  Text('$mm:$ss', style: TextStyle(fontSize: 44, fontWeight: FontWeight.w800, color: neuText(d))),
                ]),
              ),
            ),
          ),
          const SizedBox(height: 32),
          Row(mainAxisSize: MainAxisSize.min, children: [
            NeuButton(filled: true, onTap: toggle, child: Text(running ? s.t('pause') : s.t('start'))),
            const SizedBox(width: 14),
            NeuButton(
                onTap: () {
                  timer?.cancel();
                  setState(() {
                    running = false;
                    focus = true;
                    left = 25 * 60;
                  });
                },
                child: Text(s.t('reset'))),
          ]),
        ]),
      ),
    );
  }
}

class MatchPage extends StatefulWidget {
  final List<CardM> cards;
  const MatchPage({super.key, required this.cards});
  @override
  State<MatchPage> createState() => _MatchPageState();
}

class _MatchPageState extends State<MatchPage> {
  late final List<CardM> items = ([...widget.cards]..shuffle()).take(6).toList();
  late final List<CardM> right = [...items]..shuffle();
  final matched = <String>{};
  String? selL;
  String? wrongId;
  int mistakes = 0;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final finished = matched.length == items.length;

    Widget cell(CardM c, String text, bool left) {
      final ok = matched.contains(c.id);
      final sel = left && selL == c.id;
      final bad = wrongId == c.id && !left;
      return Padding(
        padding: const EdgeInsets.only(bottom: 12),
        child: NeuButton(
          fill: ok ? Colors.green.shade600 : (bad ? Colors.red.shade600 : null),
          onTap: ok
              ? null
              : () async {
                  if (left) {
                    setState(() => selL = c.id);
                  } else if (selL != null) {
                    if (selL == c.id) {
                      setState(() {
                        matched.add(c.id);
                        selL = null;
                      });
                      if (matched.length == items.length) s.addXp(items.length * 3 - mistakes);
                    } else {
                      setState(() {
                        mistakes++;
                        wrongId = c.id;
                      });
                      await Future.delayed(const Duration(milliseconds: 500));
                      if (mounted) setState(() => wrongId = null);
                    }
                  }
                },
          child: SizedBox(
            width: double.infinity,
            height: 52,
            child: Center(
              child: Text(text,
                  maxLines: 3,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 13,
                      color: ok ? Colors.white : (sel ? kAccent : neuText(d)))),
            ),
          ),
        ),
      );
    }

    return NeuPage(
      title: s.t('match'),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text('${s.t('matchHint')} · ${s.t('mistakes')}: $mistakes',
            style: TextStyle(fontSize: 12, color: neuText(d).withOpacity(.6))),
        const SizedBox(height: 14),
        Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(child: Column(children: [for (final c in items) cell(c, cardQA(c).$1, true)])),
          const SizedBox(width: 12),
          Expanded(child: Column(children: [for (final c in right) cell(c, cardQA(c).$2, false)])),
        ]),
        if (finished)
          Padding(
            padding: const EdgeInsets.only(top: 12),
            child: NeuButton(filled: true, onTap: () => Navigator.pop(context), child: Center(child: Text(s.t('finish')))),
          ),
      ]),
    );
  }
}
