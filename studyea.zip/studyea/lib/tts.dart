import 'package:flutter_tts/flutter_tts.dart';

final FlutterTts _tts = FlutterTts();

Future<void> speak(String text) async {
  final t = text.replaceAll(RegExp(r'\{\{|\}\}'), '');
  if (t.trim().isEmpty) return;
  final ar = RegExp(r'[؀-ۿ]').hasMatch(t);
  try {
    await _tts.stop();
    await _tts.setLanguage(ar ? 'ar-SA' : 'en-US');
    await _tts.setSpeechRate(0.45);
    await _tts.speak(t);
  } catch (_) {}
}
