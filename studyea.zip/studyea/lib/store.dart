import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:uuid/uuid.dart';
import 'models.dart';
import 'strings.dart';

const _uuid = Uuid();
String newId() => _uuid.v4();

String dayKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class Store extends ChangeNotifier {
  List<Deck> decks = [];
  List<CardM> cards = [];
  List<MindMap> maps = [];
  String lang = 'ar', provider = 'gemini', geminiKey = '', hfKey = '', model = '';
  bool dark = false, loaded = false;
  int dailyGoal = 20, xp = 0, streak = 0, totalReviews = 0;
  String lastDay = '';
  Map<String, int> byDay = {};
  late Directory dir;

  String t(String k) {
    final v = kStr[k];
    if (v == null) return k;
    return v[lang == 'ar' ? 0 : 1];
  }

  int get level => xp ~/ 100 + 1;
  int get today => byDay[dayKey(DateTime.now())] ?? 0;

  Future<void> load() async {
    dir = await getApplicationDocumentsDirectory();
    await Directory('${dir.path}/images').create(recursive: true);
    final f = File('${dir.path}/studyea.json');
    if (await f.exists()) {
      try {
        fromMap(jsonDecode(await f.readAsString()));
      } catch (_) {}
    }
    loaded = true;
    notifyListeners();
  }

  void fromMap(Map<String, dynamic> j) {
    decks = (j['decks'] as List).map((e) => Deck.fromJson(e)).toList();
    cards = (j['cards'] as List).map((e) => CardM.fromJson(e)).toList();
    maps = (j['maps'] as List? ?? []).map((e) => MindMap.fromJson(e)).toList();
    lang = j['lang'] ?? 'ar';
    dark = j['dark'] ?? false;
    provider = j['provider'] ?? 'gemini';
    geminiKey = j['geminiKey'] ?? '';
    hfKey = j['hfKey'] ?? '';
    model = j['model'] ?? '';
    dailyGoal = j['dailyGoal'] ?? 20;
    xp = j['xp'] ?? 0;
    streak = j['streak'] ?? 0;
    totalReviews = j['totalReviews'] ?? 0;
    lastDay = j['lastDay'] ?? '';
    byDay = Map<String, int>.from(j['byDay'] ?? {});
  }

  Map<String, dynamic> toMap() => {
        'decks': decks.map((e) => e.toJson()).toList(),
        'cards': cards.map((e) => e.toJson()).toList(),
        'maps': maps.map((e) => e.toJson()).toList(),
        'lang': lang,
        'dark': dark,
        'provider': provider,
        'geminiKey': geminiKey,
        'hfKey': hfKey,
        'model': model,
        'dailyGoal': dailyGoal,
        'xp': xp,
        'streak': streak,
        'totalReviews': totalReviews,
        'lastDay': lastDay,
        'byDay': byDay,
      };

  Future<void> _save() async {
    await File('${dir.path}/studyea.json').writeAsString(jsonEncode(toMap()));
  }

  void changed() {
    notifyListeners();
    _save();
  }

  // ---------- decks ----------
  List<Deck> children(String? parent) => decks.where((d) => d.parentId == parent).toList();
  Deck? deck(String id) {
    for (final d in decks) {
      if (d.id == id) return d;
    }
    return null;
  }

  Set<String> deckTree(String id) {
    final out = <String>{id};
    for (final c in children(id)) {
      out.addAll(deckTree(c.id));
    }
    return out;
  }

  List<CardM> cardsOf(String deckId, {bool recursive = true}) {
    final ids = recursive ? deckTree(deckId) : {deckId};
    return cards.where((c) => ids.contains(c.deckId)).toList();
  }

  int dueCount(String deckId) {
    final now = DateTime.now().millisecondsSinceEpoch;
    return cardsOf(deckId).where((c) => c.due <= now).length;
  }

  Deck addDeck(String name, [String? parent]) {
    final d = Deck(newId(), name, parent);
    decks.add(d);
    changed();
    return d;
  }

  void renameDeck(Deck d, String name) {
    d.name = name;
    changed();
  }

  void deleteDeck(String id) {
    final ids = deckTree(id);
    decks.removeWhere((d) => ids.contains(d.id));
    cards.removeWhere((c) => ids.contains(c.deckId));
    changed();
  }

  // ---------- cards ----------
  void addCard(CardM c) {
    cards.add(c);
    changed();
  }

  void addCards(String deckId, List<List<String>> pairs) {
    for (final p in pairs) {
      cards.add(CardM(id: newId(), deckId: deckId, front: p[0], back: p[1]));
    }
    changed();
  }

  void deleteCard(CardM c) {
    cards.removeWhere((e) => e.id == c.id);
    changed();
  }

  Future<String> saveImage(Uint8List bytes) async {
    final p = '${dir.path}/images/${newId()}.jpg';
    await File(p).writeAsBytes(bytes);
    return p;
  }

  // ---------- SM-2 ----------
  void review(CardM c, int q) {
    // q: 0 again, 3 hard, 4 good, 5 easy
    final now = DateTime.now();
    if (q < 3) {
      c.reps = 0;
      c.lapses++;
      c.interval = 0;
      c.due = now.add(const Duration(minutes: 10)).millisecondsSinceEpoch;
      c.ease = max(1.3, c.ease - 0.2);
    } else {
      if (c.reps == 0) {
        c.interval = 1;
      } else if (c.reps == 1) {
        c.interval = 6;
      } else {
        c.interval = max(c.interval + 1, (c.interval * c.ease).round());
      }
      c.reps++;
      c.ease = max(1.3, c.ease + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02));
      c.due = now.add(Duration(days: c.interval)).millisecondsSinceEpoch;
    }
    final dk = dayKey(now);
    if (lastDay != dk) {
      final y = dayKey(now.subtract(const Duration(days: 1)));
      streak = lastDay == y ? streak + 1 : 1;
      lastDay = dk;
    }
    byDay[dk] = (byDay[dk] ?? 0) + 1;
    totalReviews++;
    xp += q >= 3 ? 10 : 2;
    changed();
  }

  void addXp(int n) {
    xp += n;
    changed();
  }

  // ---------- maps ----------
  void addMap(MindMap m) {
    maps.add(m);
    changed();
  }

  void deleteMap(MindMap m) {
    maps.removeWhere((e) => e.id == m.id);
    changed();
  }
}
