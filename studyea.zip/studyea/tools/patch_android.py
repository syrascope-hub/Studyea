import os, re
base = 'android/app/'
# --- gradle: core library desugaring (needed by flutter_local_notifications)
for fn in ['build.gradle.kts', 'build.gradle']:
    p = base + fn
    if not os.path.exists(p):
        continue
    s = open(p).read()
    if 'desugar_jdk_libs' in s:
        continue
    if fn.endswith('.kts'):
        s = s.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
        s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    else:
        s = s.replace('compileOptions {', 'compileOptions {\n        coreLibraryDesugaringEnabled true', 1)
        s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    open(p, 'w').write(s)
    print('patched', p)

# --- manifest
m = base + 'src/main/AndroidManifest.xml'
s = open(m).read()
s = re.sub(r'android:label="[^"]*"', 'android:label="Studyea"', s, count=1)
perms = ''.join('    <uses-permission android:name="android.permission.%s"/>\n' % x for x in
                ['INTERNET', 'CAMERA', 'VIBRATE', 'POST_NOTIFICATIONS', 'RECEIVE_BOOT_COMPLETED'])
s = s.replace('<application', perms + '    <application', 1)
receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MOCKED_BOOT_COMPLETED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
    </application>'''
s = s.replace('</application>', receivers, 1)
open(m, 'w').write(s)
print('manifest ok')
