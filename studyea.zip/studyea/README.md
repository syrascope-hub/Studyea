# Studyea
Flutter flashcards app (Neumorphism): decks + subdecks, manual / text / AI card creation, TTS per card,
AI & gallery images, SM-2 spaced repetition, quizzes, stats, mind maps (manual + AI), PDF export, Arabic/English (RTL).

Build: push to GitHub → Actions → "Build APK" (generates the android folder automatically).
Local: `flutter create --platforms=android .` then `flutter run`. Add AI keys in Settings.
