import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:quick_actions/quick_actions.dart';
import 'store.dart';
import 'neu.dart';
import 'decks.dart';
import 'mind.dart';
import 'other.dart';
import 'splash.dart';
import 'onboarding.dart';
import 'study.dart';

final GlobalKey<NavigatorState> navKey = GlobalKey<NavigatorState>();

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(ChangeNotifierProvider(create: (_) => Store()..load(), child: const StudyeaApp()));
}

class StudyeaApp extends StatefulWidget {
  const StudyeaApp({super.key});
  @override
  State<StudyeaApp> createState() => _StudyeaAppState();
}

class _StudyeaAppState extends State<StudyeaApp> {
  bool splashDone = false;
  String? pending;

  @override
  void initState() {
    super.initState();
    try {
      final qa = QuickActions();
      qa.initialize((type) {
        pending = type;
        _tryQuick();
      });
      qa.setShortcutItems([
        ShortcutItem(type: 'review', localizedTitle: 'Review / مراجعة'),
        ShortcutItem(type: 'add', localizedTitle: 'New card / بطاقة جديدة'),
      ]);
    } catch (_) {}
  }

  void _tryQuick() {
    final s = context.read<Store>();
    if (pending == null || !(s.loaded && splashDone && s.onboarded)) return;
    final nav = navKey.currentState;
    if (nav == null) return;
    final t = pending!;
    pending = null;
    if (t == 'review') {
      final now = DateTime.now().millisecondsSinceEpoch;
      final due = s.cards.where((c) => c.due <= now).toList();
      if (due.isNotEmpty) nav.push(MaterialPageRoute(builder: (_) => ReviewPage(cards: due)));
    } else {
      final dk = s.decks.isEmpty ? s.addDeck(s.t('general')) : s.decks.first;
      nav.push(MaterialPageRoute(builder: (_) => CardEditor(deckId: dk.id)));
    }
  }

  void _after() => WidgetsBinding.instance.addPostFrameCallback((_) => _tryQuick());

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    gTheme = s.themeIdx;
    final b = s.dark ? Brightness.dark : Brightness.light;
    Widget home;
    if (!(s.loaded && splashDone)) {
      home = Splash(
        key: const ValueKey('splash'),
        onDone: () {
          setState(() => splashDone = true);
          _after();
        },
      );
    } else if (!s.onboarded) {
      home = Onboarding(
        key: const ValueKey('onb'),
        onDone: () {
          s.onboarded = true;
          s.changed();
          _after();
        },
      );
    } else {
      home = const Shell(key: ValueKey('shell'));
    }
    return MaterialApp(
      title: 'Studyea',
      navigatorKey: navKey,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: b,
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: kAccent,
          brightness: b,
          surface: neuCard(s.dark),
          primary: kAccent,
          secondary: kLime,
          tertiary: kOrange,
          error: kCoral,
          onPrimary: Colors.white,
          onSecondary: kInk,
          onTertiary: kInk,
        ),
        scaffoldBackgroundColor: neuBg(s.dark),
        appBarTheme: AppBarTheme(
          backgroundColor: neuBg(s.dark),
          surfaceTintColor: Colors.transparent,
          elevation: 0,
          titleTextStyle: TextStyle(
            color: neuText(s.dark),
            fontSize: 22,
            fontWeight: FontWeight.w900,
          ),
        ),
        cardTheme: CardThemeData(
          color: neuCard(s.dark),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
            side: BorderSide(color: s.dark ? kCream : kInk, width: 2),
          ),
        ),
        dividerTheme: DividerThemeData(
          color: s.dark ? Colors.white24 : Colors.black26,
          thickness: 1.5,
        ),
        snackBarTheme: SnackBarThemeData(
          behavior: SnackBarBehavior.floating,
          backgroundColor: s.dark ? const Color(0xFF302A3A) : kInk,
          contentTextStyle: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        ),
      ),
      builder: (c, child) => MediaQuery(
        data: MediaQuery.of(c).copyWith(textScaler: TextScaler.linear(s.fontScale)),
        child: Directionality(
          textDirection: s.lang == 'ar' ? TextDirection.rtl : TextDirection.ltr,
          child: child!,
        ),
      ),
      home: AnimatedSwitcher(duration: const Duration(milliseconds: 500), child: home),
    );
  }
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int i = 0;
  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final tabs = [
      (Icons.style_rounded, s.t('decks')),
      (Icons.account_tree_rounded, s.t('mindmaps')),
      (Icons.insights_rounded, s.t('stats')),
      (Icons.tune_rounded, s.t('settings')),
    ];
    return Scaffold(
      backgroundColor: neuBg(d),
      body: IndexedStack(index: i, children: const [DecksPage(), MapsPage(), StatsPage(), SettingsPage()]),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: NeuBox(
            radius: 26,
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
            child: Row(children: [
              for (var k = 0; k < tabs.length; k++)
                Expanded(
                  child: GestureDetector(
                    behavior: HitTestBehavior.opaque,
                    onTap: () => setState(() => i = k),
                    child: NeuBox(
                      inset: i == k,
                      radius: 20,
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Icon(tabs[k].$1, color: i == k ? kAccent : neuText(d).withValues(alpha: .6)),
                        Text(tabs[k].$2,
                            style: TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w700,
                                color: i == k ? kAccent : neuText(d).withValues(alpha: .6))),
                      ]),
                    ),
                  ),
                ),
            ]),
          ),
        ),
      ),
    );
  }
}
