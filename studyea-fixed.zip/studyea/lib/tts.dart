import 'dart:convert';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;

final FlutterTts _tts = FlutterTts();
final AudioPlayer _onlinePlayer = AudioPlayer();
String _engine = 'auto';
String _googleKey = '';
String _elevenLabsKey = '';
bool _ttsReady = false;

void configureVoice({required String engine, String googleKey = '', String elevenLabsKey = ''}) {
  _engine = engine;
  _googleKey = googleKey;
  _elevenLabsKey = elevenLabsKey;
}

Future<void> _prepareLocal() async {
  if (_ttsReady) return;
  await _tts.awaitSpeakCompletion(true);
  await _tts.setSpeechRate(0.45);
  _ttsReady = true;
}

Future<void> stopSpeaking() async {
  try {
    await _tts.stop();
  } catch (_) {}
  try {
    await _onlinePlayer.stop();
  } catch (_) {}
}

Future<void> _speakLocal(String text, bool arabic) async {
  await _prepareLocal();
  await _tts.setLanguage(arabic ? 'ar-SA' : 'en-US');
  await _tts.speak(text);
}

Future<Uint8List> _googleSpeech(String text, bool arabic) async {
  final response = await http
      .post(
        Uri.parse('https://texttospeech.googleapis.com/v1/text:synthesize?key=${Uri.encodeQueryComponent(_googleKey)}'),
        headers: const {'Content-Type': 'application/json'},
        body: jsonEncode({
          'input': {'text': text},
          'voice': {
            'languageCode': arabic ? 'ar-XA' : 'en-US',
            'ssmlGender': 'NEUTRAL',
          },
          'audioConfig': {'audioEncoding': 'MP3', 'speakingRate': 0.95},
        }),
      )
      .timeout(const Duration(seconds: 35));
  final data = jsonDecode(utf8.decode(response.bodyBytes));
  if (response.statusCode < 200 || response.statusCode >= 300) {
    throw StateError(data['error']?['message']?.toString() ?? 'Google TTS HTTP ${response.statusCode}');
  }
  final encoded = data['audioContent'] as String?;
  if (encoded == null || encoded.isEmpty) throw StateError('Google TTS returned no audio.');
  return base64Decode(encoded);
}

Future<Uint8List> _elevenLabsSpeech(String text) async {
  // A multilingual voice is used so the same voice can read Arabic and English content.
  const voiceId = 'EXAVITQu4vr4xnSDxMaL';
  final response = await http
      .post(
        Uri.parse('https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128'),
        headers: {
          'Content-Type': 'application/json',
          'xi-api-key': _elevenLabsKey,
          'Accept': 'audio/mpeg',
        },
        body: jsonEncode({
          'text': text,
          'model_id': 'eleven_multilingual_v2',
          'voice_settings': {'stability': 0.5, 'similarity_boost': 0.75},
        }),
      )
      .timeout(const Duration(seconds: 45));
  if (response.statusCode < 200 || response.statusCode >= 300) {
    throw StateError('ElevenLabs HTTP ${response.statusCode}: ${utf8.decode(response.bodyBytes, allowMalformed: true)}');
  }
  return response.bodyBytes;
}

Future<void> _playBytes(Uint8List bytes) async {
  final finished = _onlinePlayer.onPlayerComplete.first.timeout(const Duration(minutes: 3));
  await _onlinePlayer.play(BytesSource(bytes));
  await finished;
}

/// Reads text using the selected online engine, falling back to Android's local TTS.
/// "auto" prefers Google Cloud, then ElevenLabs, then local TTS.
Future<void> speak(String text) async {
  final clean = text.replaceAll(RegExp(r'\{\{|\}\}'), '').trim();
  if (clean.isEmpty) return;
  await stopSpeaking();
  final arabic = RegExp(r'[؀-ۿ]').hasMatch(clean);
  final preferred = _engine == 'auto'
      ? (_googleKey.isNotEmpty ? 'google' : (_elevenLabsKey.isNotEmpty ? 'elevenlabs' : 'local'))
      : _engine;
  try {
    if (preferred == 'google' && _googleKey.isNotEmpty) {
      await _playBytes(await _googleSpeech(clean, arabic));
      return;
    }
    if (preferred == 'elevenlabs' && _elevenLabsKey.isNotEmpty) {
      await _playBytes(await _elevenLabsSpeech(clean));
      return;
    }
  } catch (_) {
    // Offline fallback is intentional; a failed remote voice must not block studying.
  }
  await _speakLocal(clean, arabic);
}
