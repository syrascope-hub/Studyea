import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'store.dart';

const kAccent = Color(0xFF5125F5); // electric violet from the StudyEA reference
const kLime = Color(0xFFD7FF3F);
const kOrange = Color(0xFFFFA63D);
const kCoral = Color(0xFFFF6257);
const kInk = Color(0xFF111111);
const kCream = Color(0xFFF5F0E7);
const kPaper = Color(0xFFFFFCF5);
const kMuted = Color(0xFF716B63);
bool isDark(BuildContext c) => Theme.of(c).brightness == Brightness.dark;
int gTheme = 0;
const _bgs = [0xFFF5F0E7, 0xFFF5F0E7, 0xFFF5F0E7, 0xFFF5F0E7];
const _ins = [0xFFE8E1D6, 0xFFE8E1D6, 0xFFE8E1D6, 0xFFE8E1D6];
const kThemeCount = 4;
Color themeSwatch(int i) => const Color(0xFFF5F0E7);
Color neuBg(bool d) => d ? const Color(0xFF17151D) : kCream;
Color neuCard(bool d) => d ? const Color(0xFF26232D) : kPaper;
Color neuInset(bool d) => d ? const Color(0xFF211E27) : const Color(0xFFE8E1D6);
Color neuLo(bool d) => d ? kCream : kInk;
Color neuHi(bool d) => neuCard(d);
Color neuText(bool d) => d ? const Color(0xFFF7F4EE) : const Color(0xFF111111);

class NeuBox extends StatelessWidget {
  final Widget? child;
  final double radius, depth;
  final bool inset;
  final EdgeInsets padding;
  final double? width, height;
  final Color? color;
  const NeuBox({
    super.key,
    this.child,
    this.radius = 20,
    this.depth = 6,
    this.inset = false,
    this.padding = const EdgeInsets.all(14),
    this.width,
    this.height,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    final r = radius >= 50 ? radius : radius.clamp(8.0, 18.0).toDouble();
    final fill = color ?? (inset ? neuInset(d) : neuCard(d));
    return Transform.translate(
      offset: inset ? Offset.zero : Offset(0, depth > 0 ? 2 : 0),
      child: Container(
        width: width,
        height: height,
        padding: padding,
        decoration: BoxDecoration(
          color: fill,
          borderRadius: BorderRadius.circular(r),
          border: Border.all(color: d ? kCream : kInk, width: 2),
          boxShadow: inset || depth <= 0
              ? const []
              : [
                  BoxShadow(
                    color: d ? kAccent : kInk,
                    offset: Offset(depth.clamp(2, 7).toDouble(), depth.clamp(2, 7).toDouble()),
                    blurRadius: 0,
                    spreadRadius: 0,
                  ),
                ],
        ),
        child: child,
      ),
    );
  }
}

class NeuButton extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final double radius;
  final EdgeInsets padding;
  final bool filled;
  final Color? fill;
  const NeuButton({
    super.key,
    required this.child,
    this.onTap,
    this.radius = 16,
    this.padding = const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
    this.filled = false,
    this.fill,
  });
  @override
  State<NeuButton> createState() => _NeuButtonState();
}

class _NeuButtonState extends State<NeuButton> {
  bool down = false;
  @override
  Widget build(BuildContext context) {
    final fillColor = widget.fill ?? (widget.filled ? kAccent : null);
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: (_) => setState(() => down = true),
      onTapCancel: () => setState(() => down = false),
      onTapUp: (_) => setState(() => down = false),
      onTap: widget.onTap,
      child: Opacity(
        opacity: widget.onTap == null ? .5 : 1,
        child: Transform.translate(
          offset: down ? const Offset(4, 4) : Offset.zero,
          child: NeuBox(
          radius: widget.radius,
          depth: down ? 0 : 4,
          padding: widget.padding,
          color: fillColor,
          child: DefaultTextStyle.merge(
            style: TextStyle(
              fontWeight: FontWeight.w800,
              color: fillColor != null ? Colors.white : neuText(isDark(context)),
            ),
            child: IconTheme.merge(
              data: IconThemeData(color: fillColor != null ? Colors.white : neuText(isDark(context))),
              child: widget.child,
            ),
          ),
        ),
        ),
      ),
    );
  }
}

class NeuIcon extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;
  final double size;
  final bool filled;
  const NeuIcon(this.icon, {super.key, this.onTap, this.size = 22, this.filled = false});
  @override
  Widget build(BuildContext context) => NeuButton(
        onTap: onTap,
        radius: 8,
        filled: filled,
        padding: const EdgeInsets.all(10),
        child: Icon(icon, size: size),
      );
}

class NeuField extends StatelessWidget {
  final TextEditingController? controller;
  final String? hint;
  final int maxLines;
  final ValueChanged<String>? onChanged;
  final bool obscure;
  const NeuField({super.key, this.controller, this.hint, this.maxLines = 1, this.onChanged, this.obscure = false});
  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    return NeuBox(
      inset: true,
      radius: 16,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 2),
      child: TextField(
        controller: controller,
        maxLines: obscure ? 1 : maxLines,
        minLines: 1,
        obscureText: obscure,
        onChanged: onChanged,
        style: TextStyle(color: neuText(d)),
        decoration: InputDecoration(
          border: InputBorder.none,
          hintText: hint,
          hintStyle: TextStyle(color: neuText(d).withValues(alpha: .45)),
        ),
      ),
    );
  }
}

class NeuPage extends StatelessWidget {
  final String title;
  final Widget body;
  final List<Widget> actions;
  final Widget? bottom;
  final bool back;
  const NeuPage({super.key, required this.title, required this.body, this.actions = const [], this.bottom, this.back = true});
  @override
  Widget build(BuildContext context) {
    final d = isDark(context);
    return Scaffold(
      backgroundColor: neuBg(d),
      body: SafeArea(
        child: Column(children: [
          Container(
            decoration: BoxDecoration(
                border: Border(bottom: BorderSide(color: (d ? Colors.white : kAccent).withValues(alpha: .12), width: 1))),
            padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
            child: Row(children: [
              if (back && Navigator.of(context).canPop()) ...[
                NeuIcon(Icons.arrow_back_ios_new_rounded, size: 18, onTap: () => Navigator.pop(context)),
                const SizedBox(width: 12),
              ],
              Expanded(
                child: Text(title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: neuText(d))),
              ),
              for (final a in actions) Padding(padding: const EdgeInsetsDirectional.only(start: 8), child: a),
            ]),
          ),
          Expanded(child: body),
          if (bottom != null) bottom!,
        ]),
      ),
    );
  }
}

Future<String?> askText(BuildContext context, String title, {String initial = '', String? hint}) {
  final c = TextEditingController(text: initial);
  final s = context.read<Store>();
  return showDialog<String>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: neuBg(isDark(context)),
      title: Text(title, style: TextStyle(color: neuText(isDark(context)))),
      content: NeuField(controller: c, hint: hint),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(ctx, c.text.trim()), child: Text(s.t('ok'))),
      ],
    ),
  );
}

Future<bool> confirm(BuildContext context) async {
  final s = context.read<Store>();
  final r = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      backgroundColor: neuBg(isDark(context)),
      content: Text(s.t('confirmDelete'), style: TextStyle(color: neuText(isDark(context)))),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(s.t('delete'))),
      ],
    ),
  );
  return r == true;
}

void toast(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m), behavior: SnackBarBehavior.floating));

Future<T?> neuSheet<T>(BuildContext context, Widget Function(BuildContext) b) => showModalBottomSheet<T>(
      context: context,
      isScrollControlled: true,
      backgroundColor: neuBg(isDark(context)),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 16 + MediaQuery.of(ctx).viewInsets.bottom),
        child: SingleChildScrollView(child: b(ctx)),
      ),
    );
