import os, re
base = 'android/app/'
# --- gradle: core library desugaring (needed by flutter_local_notifications)
for fn in ['build.gradle.kts', 'build.gradle']:
    p = base + fn
    if not os.path.exists(p):
        continue
    s = open(p).read()
    if 'desugar_jdk_libs' in s:
        continue
    if fn.endswith('.kts'):
        s = s.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
        s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    else:
        s = s.replace('compileOptions {', 'compileOptions {\n        coreLibraryDesugaringEnabled true', 1)
        s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    open(p, 'w').write(s)
    print('patched', p)

# --- release signing: use android/key.properties when present, otherwise fall back to debug
for fn in ['build.gradle.kts', 'build.gradle']:
    p = base + fn
    if not os.path.exists(p):
        continue
    s = open(p).read()
    if 'key.properties' in s:
        continue
    if fn.endswith('.kts'):
        s = ('import java.util.Properties\nimport java.io.FileInputStream\n\n'
             'val keystoreProperties = Properties()\n'
             'val keystorePropertiesFile = rootProject.file("key.properties")\n'
             'if (keystorePropertiesFile.exists()) { keystoreProperties.load(FileInputStream(keystorePropertiesFile)) }\n\n') + s
        s = s.replace('android {', """android {
    signingConfigs {
        create("release") {
            if (keystorePropertiesFile.exists()) {
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
            }
        }
    }""", 1)
        s = s.replace('signingConfig = signingConfigs.getByName("debug")',
                      'signingConfig = if (keystorePropertiesFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")')
    else:
        s = ('def keystoreProperties = new Properties()\n'
             'def keystorePropertiesFile = rootProject.file("key.properties")\n'
             'if (keystorePropertiesFile.exists()) { keystoreProperties.load(new FileInputStream(keystorePropertiesFile)) }\n\n') + s
        s = s.replace('android {', """android {
    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
            }
        }
    }""", 1)
        s = s.replace('signingConfig signingConfigs.debug',
                      'signingConfig keystorePropertiesFile.exists() ? signingConfigs.release : signingConfigs.debug')
    open(p, 'w').write(s)
    print('signing patched', p)

# --- manifest
m = base + 'src/main/AndroidManifest.xml'
s = open(m).read()
s = re.sub(r'android:label="[^"]*"', 'android:label="Studyea"', s, count=1)
# Secure storage relies on device-bound encryption keys; avoid restoring an encrypted data blob
# onto a different installation where its key may no longer exist.
if 'android:allowBackup=' not in s:
    s = s.replace('<application', '<application android:allowBackup="false"', 1)
perms = ''.join('    <uses-permission android:name="android.permission.%s"/>\n' % x for x in
                ['INTERNET', 'VIBRATE', 'POST_NOTIFICATIONS', 'RECEIVE_BOOT_COMPLETED'])
s = s.replace('<application', perms + '    <application', 1)
receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MOCKED_BOOT_COMPLETED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
    </application>'''
s = s.replace('</application>', receivers, 1)
open(m, 'w').write(s)
print('manifest ok')
