import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import 'ai.dart';
import 'neu.dart';
import 'store.dart';

/// One search hit. [thumb] is a medium-size picture (good enough for a card and small to download).
class WebImage {
  final String thumb, full, title, credit;
  const WebImage(this.thumb, this.full, this.title, this.credit);
}

const _ua = 'StudyEA/1.4 (flashcard app; image search)';

Future<List<WebImage>> _openverse(String q) async {
  final r = await http
      .get(Uri.https('api.openverse.org', '/v1/images/', {'q': q, 'page_size': '18', 'mature': 'false'}), headers: const {'User-Agent': _ua})
      .timeout(const Duration(seconds: 20));
  if (r.statusCode != 200) throw 'Openverse HTTP ${r.statusCode}';
  final j = jsonDecode(utf8.decode(r.bodyBytes));
  final out = <WebImage>[];
  for (final e in (j['results'] as List? ?? [])) {
    final thumb = (e['thumbnail'] ?? e['url'] ?? '').toString();
    if (thumb.isEmpty) continue;
    final lic = '${e['license'] ?? ''} ${e['license_version'] ?? ''}'.trim().toUpperCase();
    out.add(WebImage(thumb, (e['url'] ?? thumb).toString(), (e['title'] ?? '').toString(),
        '${e['creator'] ?? e['source'] ?? 'Openverse'}${lic.isEmpty ? '' : ' · CC $lic'}'));
  }
  return out;
}

Future<List<WebImage>> _wikimedia(String q) async {
  final r = await http
      .get(
          Uri.https('commons.wikimedia.org', '/w/api.php', {
            'action': 'query',
            'generator': 'search',
            'gsrnamespace': '6',
            'gsrsearch': q,
            'gsrlimit': '18',
            'prop': 'imageinfo',
            'iiprop': 'url|mime',
            'iiurlwidth': '600',
            'format': 'json',
          }),
          headers: const {'User-Agent': _ua})
      .timeout(const Duration(seconds: 20));
  if (r.statusCode != 200) throw 'Wikimedia HTTP ${r.statusCode}';
  final j = jsonDecode(utf8.decode(r.bodyBytes));
  final pages = (j['query']?['pages'] as Map?)?.values.toList() ?? [];
  final out = <WebImage>[];
  for (final p in pages) {
    final info = (p['imageinfo'] as List?)?.first;
    if (info == null) continue;
    final mime = (info['mime'] ?? '').toString();
    if (!mime.startsWith('image/') || mime.contains('svg') || mime.contains('tiff')) continue;
    final thumb = (info['thumburl'] ?? info['url'] ?? '').toString();
    if (thumb.isEmpty) continue;
    out.add(WebImage(thumb, (info['url'] ?? thumb).toString(), (p['title'] ?? '').toString().replaceFirst('File:', ''), 'Wikimedia Commons'));
  }
  return out;
}

/// Searches Openverse and Wikimedia Commons (no API key needed) and merges the results.
Future<List<WebImage>> searchWebImages(String q) async {
  final results = await Future.wait<List<WebImage>>([
    _openverse(q).catchError((_) => <WebImage>[]),
    _wikimedia(q).catchError((_) => <WebImage>[]),
  ]);
  final out = <WebImage>[];
  final a = results[0], b = results[1];
  for (var i = 0; i < a.length || i < b.length; i++) {
    if (i < a.length) out.add(a[i]);
    if (i < b.length) out.add(b[i]);
  }
  return out;
}

Future<Uint8List> _download(String url) async {
  final r = await http.get(Uri.parse(url), headers: const {'User-Agent': _ua}).timeout(const Duration(seconds: 30));
  if (r.statusCode != 200) throw 'HTTP ${r.statusCode}';
  final type = r.headers['content-type'] ?? '';
  if (!type.startsWith('image/') || type.contains('svg')) throw 'not a picture';
  if (r.bodyBytes.length > 8 * 1024 * 1024) throw 'too large';
  return r.bodyBytes;
}

/// Image search screen. Pops with the chosen picture's bytes (or null when cancelled).
class WebImagePage extends StatefulWidget {
  final String initialQuery;
  const WebImagePage({super.key, this.initialQuery = ''});
  @override
  State<WebImagePage> createState() => _WebImagePageState();
}

class _WebImagePageState extends State<WebImagePage> {
  late final q = TextEditingController(text: widget.initialQuery);
  List<WebImage> results = [];
  bool busy = false, searched = false;
  String? error;
  final _arabic = RegExp(r'[؀-ۿ]');

  @override
  void initState() {
    super.initState();
    if (widget.initialQuery.trim().isNotEmpty) WidgetsBinding.instance.addPostFrameCallback((_) => _search());
  }

  @override
  void dispose() {
    q.dispose();
    super.dispose();
  }

  bool _hasAi(Store s) => (s.provider == 'gemini' ? s.geminiKey : s.provider == 'openrouter' ? s.openRouterKey : s.hfKey).isNotEmpty;

  Future<void> _search() async {
    final text = q.text.trim();
    if (text.isEmpty) return;
    setState(() {
      busy = true;
      error = null;
    });
    try {
      final r = await searchWebImages(text);
      if (!mounted) return;
      setState(() {
        results = r;
        searched = true;
      });
    } catch (e) {
      if (mounted) setState(() => error = e.toString());
    }
    if (mounted) setState(() => busy = false);
  }

  /// Image libraries index mostly English captions, so Arabic words are translated first.
  Future<void> _translate() async {
    final s = context.read<Store>();
    setState(() => busy = true);
    try {
      final out = await Ai(s).ask('Translate this into one or two simple English words for an image search. Return ONLY the English words, nothing else: ${q.text.trim()}');
      final t = out.replaceAll(RegExp(r'["\n.]'), '').trim();
      if (t.isNotEmpty) q.text = t;
    } catch (e) {
      if (mounted) toast(context, e.toString());
    }
    if (mounted) setState(() => busy = false);
    if (mounted) await _search();
  }

  Future<void> _pick(WebImage w) async {
    final s = context.read<Store>();
    setState(() => busy = true);
    try {
      Uint8List bytes;
      try {
        bytes = await _download(w.thumb);
      } catch (_) {
        bytes = await _download(w.full);
      }
      if (mounted) Navigator.pop(context, bytes);
      return;
    } catch (e) {
      if (mounted) toast(context, s.tr('تعذّر تنزيل الصورة، جرّب غيرها', 'Could not download this picture, try another'));
    }
    if (mounted) setState(() => busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    return NeuPage(
      title: s.tr('صور من الإنترنت', 'Web images'),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(children: [
            Expanded(child: NeuField(controller: q, hint: s.tr('ابحث عن صورة…', 'Search for a picture…'))),
            const SizedBox(width: 10),
            NeuButton(
              filled: true,
              onTap: busy ? null : _search,
              padding: const EdgeInsets.all(14),
              child: const Icon(Icons.search_rounded),
            ),
          ]),
        ),
        if (_arabic.hasMatch(q.text) && _hasAi(s))
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Align(
              alignment: AlignmentDirectional.centerStart,
              child: NeuButton(
                onTap: busy ? null : _translate,
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                child: Text(s.tr('ترجم للإنجليزية وابحث (أدق)', 'Translate to English and search'), style: const TextStyle(fontSize: 12)),
              ),
            ),
          ),
        if (busy) const LinearProgressIndicator(minHeight: 3),
        Expanded(
          child: error != null
              ? Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(error!, textAlign: TextAlign.center, style: TextStyle(color: neuText(d)))))
              : searched && results.isEmpty && !busy
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(24),
                        child: Text(s.tr('لا توجد نتائج. جرّب كلمة إنجليزية أبسط.', 'No results. Try a simpler English word.'),
                            textAlign: TextAlign.center, style: TextStyle(color: neuText(d).withValues(alpha: .7))),
                      ),
                    )
                  : GridView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 3, mainAxisSpacing: 8, crossAxisSpacing: 8),
                      itemCount: results.length,
                      itemBuilder: (_, i) {
                        final w = results[i];
                        return GestureDetector(
                          onTap: busy ? null : () => _pick(w),
                          onLongPress: () => toast(context, '${w.title}\n${w.credit}'),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(12),
                            child: Image.network(
                              w.thumb,
                              fit: BoxFit.cover,
                              headers: const {'User-Agent': _ua},
                              loadingBuilder: (c, child, p) => p == null ? child : const Center(child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2))),
                              errorBuilder: (_, __, ___) => Container(color: Colors.black12, child: const Icon(Icons.broken_image_rounded)),
                            ),
                          ),
                        );
                      },
                    ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 10),
          child: Text(
            s.tr('الصور من Openverse وWikimedia Commons وأغلبها بترخيص مفتوح. اضغط مطولًا على صورة لرؤية اسم صاحبها.',
                'Pictures come from Openverse and Wikimedia Commons, mostly under open licences. Long-press a picture to see its author.'),
            style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .6)),
          ),
        ),
      ]),
    );
  }
}
