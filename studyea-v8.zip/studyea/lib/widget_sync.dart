import 'package:flutter/foundation.dart';
import 'package:home_widget/home_widget.dart';

String _lastSig = '';

/// Pushes today's numbers to the Android home-screen widget (streak, due cards, daily goal).
/// Does nothing when nothing changed, and never throws (a missing widget must not break the app).
Future<void> pushHomeWidget({
  required bool ar,
  required int streak,
  required int due,
  required int today,
  required int goal,
}) async {
  if (kIsWeb || defaultTargetPlatform != TargetPlatform.android) return;
  try {
    final g = goal < 1 ? 1 : goal;
    final pct = (today * 100 ~/ g).clamp(0, 100).toInt();
    final data = <String, String>{
      'w_title': 'StudyEA',
      'w_streak': ar ? '🔥 $streak يوم متتالي' : '🔥 $streak-day streak',
      'w_due': due == 0
          ? (ar ? 'لا توجد مراجعات الآن 🎉' : 'All caught up 🎉')
          : (ar ? '$due بطاقة للمراجعة' : '$due cards to review'),
      'w_goal': ar ? '$today / $g اليوم' : '$today / $g today',
      'w_pct': '$pct',
    };
    final sig = data.values.join('|');
    if (sig == _lastSig) return;
    _lastSig = sig;
    for (final e in data.entries) {
      await HomeWidget.saveWidgetData<String>(e.key, e.value);
    }
    await HomeWidget.updateWidget(androidName: 'StudyeaWidgetProvider');
  } catch (_) {}
}
