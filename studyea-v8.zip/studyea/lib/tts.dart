import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

import 'tex.dart';

final FlutterTts _tts = FlutterTts();
final AudioPlayer _onlinePlayer = AudioPlayer();
String _engine = 'auto';
String _googleKey = '';
String _elevenLabsKey = '';
double _speed = 1.0;
bool _ttsReady = false;
int _token = 0; // bumped on every speak()/stop so older playbacks are cancelled

/// A message the UI should show to the user (engine failed, no Arabic voice installed, ...).
class VoiceNotice {
  final String message;
  const VoiceNotice(this.message);
}

/// New object for every notice, so listeners fire even when the text repeats.
final ValueNotifier<VoiceNotice?> voiceNotice = ValueNotifier<VoiceNotice?>(null);

/// True while any engine is speaking (used for the waveform animation).
final ValueNotifier<bool> speaking = ValueNotifier<bool>(false);

void configureVoice({required String engine, String googleKey = '', String elevenLabsKey = '', double? speed}) {
  _engine = engine;
  _googleKey = googleKey.trim();
  _elevenLabsKey = elevenLabsKey.trim();
  if (speed != null) _speed = speed.clamp(0.5, 2.0).toDouble();
}

void _notify(String m) => voiceNotice.value = VoiceNotice(m);

Future<void> _prepareLocal() async {
  if (_ttsReady) return;
  try {
    await _tts.awaitSpeakCompletion(true);
    await _tts.setVolume(1.0);
    await _tts.setPitch(1.0);
  } catch (_) {}
  _ttsReady = true;
}

Future<void> stopSpeaking() async {
  _token++;
  await _stopEngines();
  speaking.value = false;
}

Future<void> _stopEngines() async {
  try {
    await _tts.stop();
  } catch (_) {}
  try {
    await _onlinePlayer.stop();
  } catch (_) {}
}

Future<void> _setLocalLanguage(bool arabic) async {
  final candidates = arabic ? ['ar-SA', 'ar', 'ar-EG', 'ar-AE', 'ar-XA'] : ['en-US', 'en-GB', 'en'];
  for (final c in candidates) {
    try {
      final ok = await _tts.isLanguageAvailable(c);
      if (ok == true || ok == 1) {
        await _tts.setLanguage(c);
        return;
      }
    } catch (_) {}
  }
  if (arabic) {
    throw StateError('لا يوجد صوت عربي مثبّت في محرك صوت الجهاز. ثبّت بيانات الصوت العربي من إعدادات الجهاز ← تحويل النص إلى كلام.');
  }
  try {
    await _tts.setLanguage('en-US');
  } catch (_) {}
}

Future<void> _speakLocal(String text, bool arabic, int token) async {
  await _prepareLocal();
  await _setLocalLanguage(arabic);
  await _tts.setSpeechRate((0.45 * _speed).clamp(0.1, 1.0).toDouble());
  if (token != _token) return;
  await _tts.speak(text);
}

String _httpMessage(String name, http.Response r) {
  String detail = '';
  try {
    final j = jsonDecode(utf8.decode(r.bodyBytes));
    final e = j is Map ? (j['error'] ?? j['detail']) : null;
    if (e is Map) {
      detail = (e['message'] ?? e['status'] ?? '').toString();
    } else if (e != null) {
      detail = e.toString();
    }
  } catch (_) {}
  var hint = '';
  if (r.statusCode == 400 || r.statusCode == 401) hint = ' (تحقق من صحة المفتاح)';
  if (r.statusCode == 403) hint = ' (تأكد من تفعيل الخدمة على حساب المفتاح، أو أن بلدك غير محجوب)';
  if (r.statusCode == 429 || r.statusCode == 402) hint = ' (انتهت الحصة المجانية أو تجاوزت الحد)';
  return '$name: HTTP ${r.statusCode}${detail.isEmpty ? '' : ' - $detail'}$hint';
}

Future<Uint8List> _googleSpeech(String text, bool arabic) async {
  final http.Response response;
  try {
    response = await http
        .post(
          Uri.parse('https://texttospeech.googleapis.com/v1/text:synthesize?key=${Uri.encodeQueryComponent(_googleKey)}'),
          headers: const {'Content-Type': 'application/json'},
          body: jsonEncode({
            'input': {'text': text},
            'voice': {
              'languageCode': arabic ? 'ar-XA' : 'en-US',
              'ssmlGender': 'NEUTRAL',
            },
            'audioConfig': {'audioEncoding': 'MP3', 'speakingRate': _speed.clamp(0.25, 2.0)},
          }),
        )
        .timeout(const Duration(seconds: 35));
  } on TimeoutException {
    throw StateError('Google TTS: انتهت مهلة الاتصال (قد تكون الخدمة محجوبة في شبكتك)');
  } catch (e) {
    throw StateError('Google TTS: تعذر الاتصال بالإنترنت ($e)');
  }
  if (response.statusCode < 200 || response.statusCode >= 300) {
    throw StateError(_httpMessage('Google TTS', response));
  }
  final data = jsonDecode(utf8.decode(response.bodyBytes));
  final encoded = data['audioContent'] as String?;
  if (encoded == null || encoded.isEmpty) throw StateError('Google TTS: لم يرجع الخادم أي صوت.');
  return base64Decode(encoded);
}

Future<Uint8List> _elevenLabsSpeech(String text) async {
  // A multilingual voice is used so the same voice can read Arabic and English content.
  const voiceId = 'EXAVITQu4vr4xnSDxMaL';
  final http.Response response;
  try {
    response = await http
        .post(
          Uri.parse('https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128'),
          headers: {
            'Content-Type': 'application/json',
            'xi-api-key': _elevenLabsKey,
            'Accept': 'audio/mpeg',
          },
          body: jsonEncode({
            'text': text,
            'model_id': 'eleven_multilingual_v2',
            'voice_settings': {'stability': 0.5, 'similarity_boost': 0.75},
          }),
        )
        .timeout(const Duration(seconds: 45));
  } on TimeoutException {
    throw StateError('ElevenLabs: انتهت مهلة الاتصال (قد تكون الخدمة محجوبة في شبكتك)');
  } catch (e) {
    throw StateError('ElevenLabs: تعذر الاتصال بالإنترنت ($e)');
  }
  if (response.statusCode < 200 || response.statusCode >= 300) {
    throw StateError(_httpMessage('ElevenLabs', response));
  }
  if (response.bodyBytes.isEmpty) throw StateError('ElevenLabs: لم يرجع الخادم أي صوت.');
  return response.bodyBytes;
}

/// Plays an audio file and completes when playback ends OR is stopped (so stop never leaves callers hanging).
Future<void> _playFile(String path, int token, double rate) async {
  if (token != _token) return;
  final done = Completer<void>();
  final s1 = _onlinePlayer.onPlayerComplete.listen((_) {
    if (!done.isCompleted) done.complete();
  });
  final s2 = _onlinePlayer.onPlayerStateChanged.listen((st) {
    if ((st == PlayerState.stopped || st == PlayerState.completed) && !done.isCompleted) done.complete();
  });
  try {
    await _onlinePlayer.setPlaybackRate(rate);
    await _onlinePlayer.play(DeviceFileSource(path));
    await done.future.timeout(const Duration(minutes: 5), onTimeout: () {});
  } finally {
    await s1.cancel();
    await s2.cancel();
  }
}

// ---------------------------------------------------------------------------------------------
// Free online voice (no API key) + on-disk audio cache.
// Every online sentence is downloaded once, saved on the device, and replayed instantly afterwards.
// ---------------------------------------------------------------------------------------------

const int _cacheLimit = 150 * 1024 * 1024; // oldest files are deleted beyond ~150 MB
Directory? _cacheDir;
final Map<String, Future<File>> _pending = {};
int _writes = 0;
int _prefetchGen = 0;
bool _bypassCache = false; // set while testing an engine so a cached file cannot hide a bad key
DateTime _lastNotice = DateTime.fromMillisecondsSinceEpoch(0);

Future<Directory> _cache() async {
  final c = _cacheDir;
  if (c != null) return c;
  final base = await getApplicationSupportDirectory();
  final d = Directory('${base.path}/tts_cache');
  if (!await d.exists()) await d.create(recursive: true);
  return _cacheDir = d;
}

String _hash(String s) {
  var a = 0x811c9dc5, b = 0x5bd1e995;
  for (final u in s.codeUnits) {
    a = ((a ^ u) * 0x01000193) & 0xFFFFFFFF;
    b = (((b + u) * 0x5bd1e995) ^ (b >> 13)) & 0xFFFFFFFF;
  }
  return '${a.toRadixString(16)}${b.toRadixString(16)}${s.length}';
}

Future<Uint8List> _freeSpeech(String text, bool arabic) async {
  final uri = Uri.https('translate.google.com', '/translate_tts', {
    'ie': 'UTF-8',
    'client': 'tw-ob',
    'tl': arabic ? 'ar' : 'en',
    'q': text,
    'textlen': '${text.length}',
  });
  final http.Response response;
  try {
    response = await http.get(uri, headers: const {
      'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36',
      'Referer': 'https://translate.google.com/',
    }).timeout(const Duration(seconds: 20));
  } on TimeoutException {
    throw StateError('الصوت المجاني: انتهت مهلة الاتصال (تحقق من الإنترنت)');
  } catch (e) {
    throw StateError('الصوت المجاني: تعذر الاتصال بالإنترنت');
  }
  if (response.statusCode != 200) {
    final extra = response.statusCode == 429 ? ' (طلبات كثيرة، انتظر قليلًا)' : '';
    throw StateError('الصوت المجاني: HTTP ${response.statusCode}$extra');
  }
  final type = response.headers['content-type'] ?? '';
  if (response.bodyBytes.isEmpty || !type.contains('audio')) {
    throw StateError('الصوت المجاني: لم يرجع الخادم صوتًا صالحًا.');
  }
  return response.bodyBytes;
}

Future<Uint8List> _download(String engine, String text, bool arabic) {
  switch (engine) {
    case 'google':
      return _googleSpeech(text, arabic);
    case 'elevenlabs':
      return _elevenLabsSpeech(text);
    default:
      return _freeSpeech(text, arabic);
  }
}

/// Returns the cached mp3 for this text, downloading it first when it is not on the device yet.
Future<File> _audioFile(String engine, String text, bool arabic) async {
  final dir = await _cache();
  final speedKey = engine == 'google' ? _speed.toStringAsFixed(2) : '-';
  final key = _hash('$engine|${arabic ? 'ar' : 'en'}|$speedKey|$text');
  final file = File('${dir.path}/$key.mp3');
  if (!_bypassCache && await file.exists() && await file.length() > 0) {
    try {
      await file.setLastModified(DateTime.now()); // recently used files are kept longest
    } catch (_) {}
    return file;
  }
  return _pending.putIfAbsent(key, () async {
    try {
      final bytes = await _download(engine, text, arabic);
      final tmp = File('${file.path}.part');
      await tmp.writeAsBytes(bytes, flush: true);
      await tmp.rename(file.path);
      if (++_writes % 25 == 0) unawaited(_trimCache());
      return file;
    } finally {
      _pending.remove(key);
    }
  });
}

Future<void> _trimCache() async {
  try {
    final dir = await _cache();
    final files = <File>[];
    var total = 0;
    await for (final e in dir.list()) {
      if (e is File && e.path.endsWith('.mp3')) {
        files.add(e);
        total += await e.length();
      }
    }
    if (total <= _cacheLimit) return;
    final times = <String, DateTime>{for (final f in files) f.path: await f.lastModified()};
    files.sort((x, y) => times[x.path]!.compareTo(times[y.path]!));
    for (final f in files) {
      if (total <= _cacheLimit * 0.8) break;
      total -= await f.length();
      await f.delete();
    }
  } catch (_) {}
}

/// Size of the downloaded voice cache in bytes (shown in Settings).
Future<int> speechCacheBytes() async {
  try {
    final dir = await _cache();
    var total = 0;
    await for (final e in dir.list()) {
      if (e is File) total += await e.length();
    }
    return total;
  } catch (_) {
    return 0;
  }
}

Future<void> clearSpeechCache() async {
  try {
    final dir = await _cache();
    await for (final e in dir.list()) {
      if (e is File) await e.delete();
    }
  } catch (_) {}
}

/// Downloads the audio of upcoming cards in the background so they start instantly.
/// Only the free engine is prefetched - paid keys are never spent in the background.
Future<void> prefetchSpeech(Iterable<String> texts) async {
  final gen = ++_prefetchGen;
  final e = _enginePlan().first;
  if (e != 'online') return;
  for (final t in texts.take(8)) {
    if (gen != _prefetchGen) return;
    final raw = t.replaceAll(RegExp(r'\{\{|\}\}'), '').trim();
    if (raw.isEmpty) continue;
    final arabic = _arabicRe.hasMatch(raw);
    final clean = latexToSpeech(raw, arabic: arabic);
    if (clean.isEmpty) continue;
    try {
      for (final chunk in _chunks(clean, 900)) {
        for (final piece in _chunks(chunk, 180)) {
          if (gen != _prefetchGen) return;
          await _audioFile('online', piece, arabic);
        }
      }
    } catch (_) {
      return; // offline or rate-limited: stop quietly
    }
  }
}

List<String> _chunks(String text, int max) {
  if (text.length <= max) return [text];
  final out = <String>[];
  final parts = text.split(RegExp(r'(?<=[.!?؟۔\n])\s+'));
  var cur = StringBuffer();
  for (final p in parts) {
    if (cur.length + p.length + 1 > max && cur.isNotEmpty) {
      out.add(cur.toString().trim());
      cur = StringBuffer();
    }
    if (p.length > max) {
      for (var i = 0; i < p.length; i += max) {
        out.add(p.substring(i, i + max > p.length ? p.length : i + max));
      }
    } else {
      cur.write('$p ');
    }
  }
  if (cur.toString().trim().isNotEmpty) out.add(cur.toString().trim());
  return out;
}

/// Speaks one chunk with one specific engine. Throws a readable error when that engine fails.
Future<void> _speakWith(String engine, String chunk, bool arabic, int token) async {
  switch (engine) {
    case 'google':
      {
        if (_googleKey.isEmpty) throw StateError('Google TTS: لم يتم إدخال المفتاح في الإعدادات.');
        final f = await _audioFile('google', chunk, arabic);
        await _playFile(f.path, token, 1.0);
        return;
      }
    case 'elevenlabs':
      {
        if (_elevenLabsKey.isEmpty) throw StateError('ElevenLabs: لم يتم إدخال المفتاح في الإعدادات.');
        final f = await _audioFile('elevenlabs', chunk, arabic);
        await _playFile(f.path, token, _speed);
        return;
      }
    case 'online':
      {
        // The free voice accepts short texts only, so long chunks are split; the next piece is
        // downloaded while the current one is playing.
        final pieces = _chunks(chunk, 180);
        var next = _audioFile('online', pieces.first, arabic);
        for (var i = 0; i < pieces.length; i++) {
          if (token != _token) return;
          final current = await next;
          if (i + 1 < pieces.length) {
            next = _audioFile('online', pieces[i + 1], arabic);
            next.ignore(); // its error (if any) is handled when it is awaited on the next loop
          }
          await _playFile(current.path, token, _speed);
        }
        return;
      }
    default:
      await _speakLocal(chunk, arabic, token);
  }
}

List<String> _enginePlan() {
  switch (_engine) {
    case 'google':
      return ['google', 'online', 'local'];
    case 'elevenlabs':
      return ['elevenlabs', 'online', 'local'];
    case 'online':
      return ['online', 'local'];
    case 'local':
      return ['local'];
    default:
      return [if (_googleKey.isNotEmpty) 'google', if (_elevenLabsKey.isNotEmpty) 'elevenlabs', 'online', 'local'];
  }
}

final RegExp _arabicRe = RegExp(r'[؀-ۿ]');

/// Reads text (LaTeX formulas are converted to words) using the selected engine.
/// Falls back to the device voice when an online engine fails, and tells the user why.
Future<void> speak(String text) async {
  final raw = text.replaceAll(RegExp(r'\{\{|\}\}'), '').trim();
  if (raw.isEmpty) return;
  final arabic = _arabicRe.hasMatch(raw);
  final clean = latexToSpeech(raw, arabic: arabic);
  if (clean.isEmpty) return;
  final my = ++_token;
  await _stopEngines();
  speaking.value = true;
  final failed = <String>{};
  try {
    for (final chunk in _chunks(clean, 900)) {
      if (my != _token) return;
      var spoke = false;
      for (final e in _enginePlan()) {
        if (failed.contains(e)) continue;
        if (my != _token) return;
        try {
          await _speakWith(e, chunk, arabic, my);
          spoke = true;
          break;
        } catch (err) {
          failed.add(e);
          final msg = err.toString().replaceFirst('Bad state: ', '');
          if (e == 'local') {
            _notify(msg);
          } else if (DateTime.now().difference(_lastNotice).inSeconds > 30) {
            _lastNotice = DateTime.now();
            _notify('$msg\nتم استخدام صوت بديل بدلًا منه.');
          }
        }
      }
      if (!spoke) return;
    }
  } finally {
    if (my == _token) speaking.value = false;
  }
}

/// Used by Settings: speaks a sample with exactly one engine and returns null on success or an error text.
Future<String?> testVoice(String engine, {String googleKey = '', String elevenLabsKey = '', bool arabic = true}) async {
  final oldG = _googleKey, oldE = _elevenLabsKey;
  if (googleKey.trim().isNotEmpty) _googleKey = googleKey.trim();
  if (elevenLabsKey.trim().isNotEmpty) _elevenLabsKey = elevenLabsKey.trim();
  _bypassCache = true;
  try {
    final my = ++_token;
    await _stopEngines();
    speaking.value = true;
    final sample = arabic ? r'مرحبًا، هذا اختبار الصوت في ستديا. الدالة $x^2$ تُقرأ هكذا.' : r'Hello, this is a Studyea voice test. The function $x^2$ is read like this.';
    final spoken = latexToSpeech(sample, arabic: arabic);
    await _speakWith(engine, spoken, arabic, my);
    return null;
  } catch (e) {
    return e.toString().replaceFirst('Bad state: ', '');
  } finally {
    _bypassCache = false;
    speaking.value = false;
    _googleKey = oldG;
    _elevenLabsKey = oldE;
  }
}
