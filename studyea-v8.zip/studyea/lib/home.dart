import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'decks.dart';
import 'neu.dart';
import 'store.dart';
import 'study.dart';
import 'study_tools.dart';
import 'tex.dart';

/// The new home screen: greeting, today's session, progress, subjects and shortcuts.
class HomePage extends StatelessWidget {
  final void Function(int tab) onTab;
  const HomePage({super.key, required this.onTab});

  void _push(BuildContext c, Widget w) => Navigator.push(c, MaterialPageRoute(builder: (_) => w));

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final due = s.dueCards();
    final goal = s.dailyGoal <= 0 ? 1 : s.dailyGoal;
    final progress = (s.today / goal).clamp(0.0, 1.0).toDouble();
    final roots = s.children(null);
    final last = s.lastDeckId.isEmpty ? null : s.deck(s.lastDeckId);
    final name = s.userName.trim();
    final initial = name.isEmpty ? 'S' : String.fromCharCode(name.runes.first).toUpperCase();

    Widget sectionTitle(String t, {String? action, VoidCallback? onAction}) => Padding(
          padding: const EdgeInsets.only(top: 22, bottom: 10),
          child: Row(children: [
            Expanded(child: Text(t, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: neuText(d)))),
            if (action != null)
              GestureDetector(
                onTap: onAction,
                child: Text(action, style: const TextStyle(color: kAccent, fontWeight: FontWeight.w800, fontSize: 13)),
              ),
          ]),
        );

    Widget shortcut(IconData icon, String label, Color color, VoidCallback onTap) => Expanded(
          child: GestureDetector(
            onTap: onTap,
            child: NeuBox(
              depth: 4,
              radius: 16,
              color: color,
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
              child: Column(children: [
                Icon(icon, color: onColor(color)),
                const SizedBox(height: 6),
                Text(label,
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: onColor(color))),
              ]),
            ),
          ),
        );

    return Scaffold(
      backgroundColor: neuBg(d),
      body: SafeArea(
        child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 24), children: [
          // Greeting
          Row(children: [
            NeuBox(
              radius: 50,
              depth: 3,
              color: kLime,
              padding: EdgeInsets.zero,
              width: 46,
              height: 46,
              child: Center(child: Text(initial, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: kInk))),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text(name.isEmpty ? s.tr('مرحباً 👋', 'Hello 👋') : s.tr('مرحباً، $name 👋', 'Hi, $name 👋'),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: neuText(d))),
                Text(s.tr('مستعد لبدء يومك الدراسي؟', 'Ready for today\'s study?'),
                    style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
              ]),
            ),
            NeuIcon(Icons.notifications_none_rounded, size: 20, onTap: () => onTab(4)),
          ]),
          const SizedBox(height: 18),

          // Today's session
          NeuBox(
            radius: 22,
            depth: 6,
            color: kLime,
            padding: const EdgeInsets.all(18),
            child: Row(children: [
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.tr('جلسة اليوم', 'Today\'s session'),
                      style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: kInk)),
                  const SizedBox(height: 4),
                  Text(
                      due.isEmpty
                          ? s.tr('لا توجد بطاقات مستحقة الآن 🎉', 'Nothing due right now 🎉')
                          : s.tr('${due.length} بطاقة مستحقة للمراجعة', '${due.length} cards due for review'),
                      style: const TextStyle(fontSize: 13, color: kInk)),
                  const SizedBox(height: 14),
                  GestureDetector(
                    onTap: () {
                      if (due.isEmpty) {
                        if (s.cards.isEmpty) {
                          toast(context, s.tr('أضف بطاقات أولًا من تبويب مكتبتي.', 'Add some cards in Library first.'));
                          onTab(1);
                        } else {
                          _push(context, ReviewPage(cards: List.of(s.cards), cram: true));
                        }
                      } else {
                        _push(context, ReviewPage(cards: due));
                      }
                    },
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 11),
                      decoration: BoxDecoration(color: kInk, borderRadius: BorderRadius.circular(12)),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Text(due.isEmpty && s.cards.isNotEmpty ? s.tr('دراسة مكثفة', 'Cram') : s.tr('ابدأ المراجعة', 'Start review'),
                            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800)),
                        const SizedBox(width: 8),
                        const Icon(Icons.arrow_forward_rounded, color: Colors.white, size: 18),
                      ]),
                    ),
                  ),
                ]),
              ),
              const Icon(Icons.track_changes_rounded, size: 64, color: kInk),
            ]),
          ),
          const SizedBox(height: 14),

          // Progress + streak
          Row(children: [
            Expanded(
              child: NeuBox(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.tr('إجمالي التقدم', 'Daily progress'), style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
                  const SizedBox(height: 4),
                  Text('${(progress * 100).round()}%', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: neuText(d))),
                  const SizedBox(height: 8),
                  NeuBox(
                    inset: true,
                    radius: 8,
                    padding: const EdgeInsets.all(3),
                    child: LayoutBuilder(
                      builder: (c, k) => Align(
                        alignment: AlignmentDirectional.centerStart,
                        child: Container(
                          height: 8,
                          width: k.maxWidth * progress,
                          decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(6)),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text('${s.today} / ${s.dailyGoal}', style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .6))),
                ]),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: NeuBox(
                padding: const EdgeInsets.all(14),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(s.tr('أيام متتالية', 'Day streak'), style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
                  const SizedBox(height: 4),
                  Row(children: [
                    Text('${s.streak}', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w900, color: neuText(d))),
                    const SizedBox(width: 6),
                    const Icon(Icons.local_fire_department_rounded, color: kOrange, size: 28),
                  ]),
                  const SizedBox(height: 8),
                  Text('${s.tr('المستوى', 'Level')} ${s.level} · ${s.xp} XP',
                      style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .6))),
                ]),
              ),
            ),
          ]),

          // Subjects
          sectionTitle(s.tr('موادي', 'My subjects'), action: s.tr('عرض الكل', 'View all'), onAction: () => onTab(1)),
          if (roots.isEmpty)
            GestureDetector(
              onTap: () async {
                final n = await askText(context, s.t('newDeck'), hint: s.t('deckName'));
                if (n != null && n.isNotEmpty) s.addDeck(n);
              },
              child: NeuBox(
                color: kAccent.withValues(alpha: d ? .18 : .08),
                child: Row(children: [
                  const Icon(Icons.add_circle_rounded, color: kAccent, size: 30),
                  const SizedBox(width: 12),
                  Expanded(child: Text(s.tr('أنشئ أول مادة دراسية', 'Create your first subject'), style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d)))),
                ]),
              ),
            )
          else
            SizedBox(
              height: 128,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                clipBehavior: Clip.none,
                itemCount: roots.length > 8 ? 8 : roots.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (_, k) {
                  final dk = roots[k];
                  final col = deckColor(dk);
                  final fg = onColor(col);
                  final total = s.cardsOf(dk.id).length;
                  return GestureDetector(
                    onTap: () => _push(context, DeckPage(deckId: dk.id)),
                    child: SizedBox(
                      width: 118,
                      child: NeuBox(
                        depth: 5,
                        radius: 18,
                        color: col,
                        padding: const EdgeInsets.all(12),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Icon(Icons.style_rounded, color: fg),
                          const Spacer(),
                          Text(dk.name, maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w900, color: fg)),
                          Text('$total ${s.t('cards')}', style: TextStyle(fontSize: 11, color: fg.withValues(alpha: .8))),
                        ]),
                      ),
                    ),
                  );
                },
              ),
            ),

          // Shortcuts
          sectionTitle(s.tr('اختصارات', 'Shortcuts')),
          Row(children: [
            shortcut(Icons.psychology_alt_rounded, s.tr('المدرب الذكي', 'AI coach'), kAccent, () => _push(context, const StudyCoachPage())),
            const SizedBox(width: 10),
            shortcut(Icons.upload_file_rounded, s.tr('استيراد ملف', 'Import file'), kLime, () {
              final target = s.decks.isEmpty ? s.addDeck(s.t('general')) : s.decks.first;
              _push(context, StudyFileImportPage(deckId: target.id));
            }),
            const SizedBox(width: 10),
            shortcut(Icons.headphones_rounded, s.tr('وضع الاستماع', 'Listen'), kOrange, () {
              if (s.cards.isEmpty) {
                toast(context, s.tr('أضف بطاقات قبل بدء وضع الاستماع.', 'Add cards before using Listen mode.'));
                return;
              }
              _push(context, ListenModePage(cards: List.of(s.cards)));
            }),
            const SizedBox(width: 10),
            shortcut(Icons.timer_rounded, s.tr('التركيز', 'Focus'), kSky, () => onTab(3)),
          ]),

          // Last studied
          if (last != null) ...[
            sectionTitle(s.tr('آخر ما درسته', 'Continue studying')),
            GestureDetector(
              onTap: () => _push(context, DeckPage(deckId: last.id)),
              child: NeuBox(
                child: Row(children: [
                  NeuBox(
                    radius: 12,
                    depth: 0,
                    color: deckColor(last),
                    padding: const EdgeInsets.all(10),
                    child: Icon(Icons.style_rounded, color: onColor(deckColor(last))),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      RichMath(last.name, style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d))),
                      Text('${s.cardsOf(last.id).length} ${s.t('cards')} · ${s.dueCount(last.id)} ${s.t('due')}',
                          style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .6))),
                    ]),
                  ),
                  Icon(Icons.chevron_right_rounded, color: neuText(d).withValues(alpha: .5)),
                ]),
              ),
            ),
          ],
        ]),
      ),
    );
  }
}
