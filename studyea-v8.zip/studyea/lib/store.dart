import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:flutter/foundation.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'tts.dart';
import 'widget_sync.dart';
import 'package:uuid/uuid.dart';
import 'fsrs.dart';
import 'models.dart';
import 'strings.dart';

const _uuid = Uuid();
const _secretStorage = FlutterSecureStorage();
String newId() => _uuid.v4();

String dayKey(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

class Store extends ChangeNotifier {
  List<Deck> decks = [];
  List<CardM> cards = [];
  List<MindMap> maps = [];
  String lang = 'ar', provider = 'openrouter', geminiKey = '', hfKey = '', openRouterKey = '', googleTtsKey = '', elevenLabsKey = '', model = '';
  String voiceEngine = 'auto';
  String userName = '', ambient = '', lastDeckId = '';
  double voiceSpeed = 1.0;
  bool autoSpeak = false;
  int focusMin = 25, focusTotal = 0;
  bool dark = false, loaded = false;
  int dailyGoal = 20, xp = 0, streak = 0, totalReviews = 0, themeIdx = 0, remindH = 20, remindM = 0;
  double fontScale = 1.0;
  bool remindOn = false, onboarded = false;
  String lastDay = '';
  Map<String, int> byDay = {};
  // Scheduler: 'fsrs' (default, more accurate) or 'sm2' (classic). retention = target recall probability.
  String scheduler = 'fsrs';
  double retention = 0.9;
  int newPerDay = 20; // max brand-new cards introduced per day (0 = unlimited)
  Map<String, int> newByDay = {};
  late Directory dir;
  bool _loadFailed = false;
  Future<void> _saveChain = Future.value();

  String t(String k) {
    final v = kStr[k];
    if (v == null) return k;
    return v[lang == 'ar' ? 0 : 1];
  }

  bool get ar => lang == 'ar';
  String tr(String a, String e) => lang == 'ar' ? a : e;

  int get level => xp ~/ 100 + 1;
  int get today => byDay[dayKey(DateTime.now())] ?? 0;

  /// Never leaves the app stuck on the splash screen: whatever fails while loading, the UI is released.
  Future<void> load() async {
    try {
      await _loadInner();
    } catch (_) {
      // Keep the app usable (empty state) rather than hanging on the splash screen.
    } finally {
      loaded = true;
      notifyListeners();
    }
  }

  Future<void> _loadInner() async {
    dir = await getApplicationDocumentsDirectory();
    await Directory('${dir.path}/images').create(recursive: true);
    final f = File('${dir.path}/studyea.json');
    Map<String, dynamic>? loadedMap;
    if (await f.exists()) {
      try {
        loadedMap = Map<String, dynamic>.from(jsonDecode(await f.readAsString()));
        fromMap(loadedMap);
      } catch (_) {
        // Never overwrite an unreadable data file: keep a copy and block saving this session.
        try {
          await f.copy('${dir.path}/studyea.corrupt-${DateTime.now().millisecondsSinceEpoch}.json');
        } catch (_) {}
        decks = [];
        cards = [];
        maps = [];
        _loadFailed = true;
      }
    }
    // Migrate older plaintext API keys to platform secure storage, then remove them from JSON.
    await _loadSecret('geminiKey', loadedMap?['geminiKey']?.toString() ?? '', (v) => geminiKey = v);
    await _loadSecret('hfKey', loadedMap?['hfKey']?.toString() ?? '', (v) => hfKey = v);
    await _loadSecret('openRouterKey', loadedMap?['openRouterKey']?.toString() ?? '', (v) => openRouterKey = v);
    await _loadSecret('googleTtsKey', loadedMap?['googleTtsKey']?.toString() ?? '', (v) => googleTtsKey = v);
    await _loadSecret('elevenLabsKey', loadedMap?['elevenLabsKey']?.toString() ?? '', (v) => elevenLabsKey = v);
    configureVoice(engine: voiceEngine, googleKey: googleTtsKey, elevenLabsKey: elevenLabsKey, speed: voiceSpeed);
    // Save a sanitized file without any secret material.
    await _save();
    loaded = true;
    notifyListeners();
    _pushWidget();
  }

  void fromMap(Map<String, dynamic> j) {
    decks = (j['decks'] as List).map((e) => Deck.fromJson(e)).toList();
    cards = (j['cards'] as List).map((e) => CardM.fromJson(e)).toList();
    maps = (j['maps'] as List? ?? []).map((e) => MindMap.fromJson(e)).toList();
    lang = j['lang'] ?? 'ar';
    dark = j['dark'] ?? false;
    provider = j['provider'] ?? 'gemini';
    model = j['model'] ?? '';
    voiceEngine = j['voiceEngine'] ?? 'auto';
    userName = j['userName'] ?? '';
    ambient = j['ambient'] ?? '';
    lastDeckId = j['lastDeckId'] ?? '';
    voiceSpeed = (j['voiceSpeed'] ?? 1.0).toDouble();
    autoSpeak = j['autoSpeak'] ?? false;
    focusMin = j['focusMin'] ?? 25;
    focusTotal = j['focusTotal'] ?? 0;
    dailyGoal = j['dailyGoal'] ?? 20;
    xp = j['xp'] ?? 0;
    streak = j['streak'] ?? 0;
    totalReviews = j['totalReviews'] ?? 0;
    lastDay = j['lastDay'] ?? '';
    byDay = Map<String, int>.from(j['byDay'] ?? {});
    themeIdx = j['themeIdx'] ?? 0;
    fontScale = (j['fontScale'] ?? 1.0).toDouble();
    remindOn = j['remindOn'] ?? false;
    remindH = j['remindH'] ?? 20;
    remindM = j['remindM'] ?? 0;
    onboarded = j['onboarded'] ?? false;
    scheduler = j['scheduler'] == 'sm2' ? 'sm2' : 'fsrs';
    retention = ((j['retention'] ?? 0.9).toDouble()).clamp(0.7, 0.97).toDouble();
    newPerDay = j['newPerDay'] ?? 20;
    newByDay = Map<String, int>.from(j['newByDay'] ?? {});
  }

  Map<String, dynamic> toMap() => {
        'decks': decks.map((e) => e.toJson()).toList(),
        'cards': cards.map((e) => e.toJson()).toList(),
        'maps': maps.map((e) => e.toJson()).toList(),
        'lang': lang,
        'dark': dark,
        'provider': provider,
        // API keys are deliberately excluded; they live in platform secure storage.
        'model': model,
        'voiceEngine': voiceEngine,
        'userName': userName,
        'ambient': ambient,
        'lastDeckId': lastDeckId,
        'voiceSpeed': voiceSpeed,
        'autoSpeak': autoSpeak,
        'focusMin': focusMin,
        'focusTotal': focusTotal,
        'dailyGoal': dailyGoal,
        'xp': xp,
        'streak': streak,
        'totalReviews': totalReviews,
        'lastDay': lastDay,
        'byDay': byDay,
        'themeIdx': themeIdx,
        'fontScale': fontScale,
        'remindOn': remindOn,
        'remindH': remindH,
        'remindM': remindM,
        'onboarded': onboarded,
        'scheduler': scheduler,
        'retention': retention,
        'newPerDay': newPerDay,
        'newByDay': newByDay,
      };

  Future<void> _loadSecret(String key, String legacyValue, void Function(String) assign) async {
    var value = '';
    try {
      value = await _secretStorage.read(key: key) ?? '';
      if (value.isEmpty && legacyValue.trim().isNotEmpty) {
        value = legacyValue.trim();
        await _secretStorage.write(key: key, value: value);
      }
    } catch (_) {
      // Keep the app usable even when secure storage is unavailable on a test device.
      value = legacyValue.trim();
    }
    assign(value);
  }

  Future<void> updateSecret(String key, String value) async {
    final clean = value.trim();
    try {
      if (clean.isEmpty) {
        await _secretStorage.delete(key: key);
      } else {
        await _secretStorage.write(key: key, value: clean);
      }
    } catch (_) {
      // Do not silently claim a key was secured if the platform plugin failed.
      rethrow;
    }
    switch (key) {
      case 'geminiKey': geminiKey = clean; break;
      case 'hfKey': hfKey = clean; break;
      case 'openRouterKey': openRouterKey = clean; break;
      case 'googleTtsKey': googleTtsKey = clean; break;
      case 'elevenLabsKey': elevenLabsKey = clean; break;
    }
    configureVoice(engine: voiceEngine, googleKey: googleTtsKey, elevenLabsKey: elevenLabsKey, speed: voiceSpeed);
    notifyListeners();
  }

  void setVoiceEngine(String value) {
    voiceEngine = value;
    configureVoice(engine: voiceEngine, googleKey: googleTtsKey, elevenLabsKey: elevenLabsKey, speed: voiceSpeed);
    changed();
  }

  void setVoiceSpeed(double v) {
    voiceSpeed = v;
    configureVoice(engine: voiceEngine, googleKey: googleTtsKey, elevenLabsKey: elevenLabsKey, speed: voiceSpeed);
    changed();
  }

  Future<void> _save() {
    // Serialized + atomic (temp file then rename) so overlapping saves cannot corrupt the data file.
    _saveChain = _saveChain.then((_) async {
      if (_loadFailed) return;
      try {
        final tmp = File('${dir.path}/studyea.json.tmp');
        await tmp.writeAsString(jsonEncode(toMap()), flush: true);
        await tmp.rename('${dir.path}/studyea.json');
      } catch (_) {}
    });
    return _saveChain;
  }

  void changed() {
    notifyListeners();
    _save();
    _pushWidget();
  }

  void _pushWidget() {
    if (!loaded) return;
    pushHomeWidget(ar: ar, streak: streak, due: dueCards().length, today: today, goal: dailyGoal);
  }

  // ---------- decks ----------
  List<Deck> children(String? parent) => decks.where((d) => d.parentId == parent).toList();
  Deck? deck(String id) {
    for (final d in decks) {
      if (d.id == id) return d;
    }
    return null;
  }

  Set<String> deckTree(String id) {
    final out = <String>{id};
    for (final c in children(id)) {
      out.addAll(deckTree(c.id));
    }
    return out;
  }

  List<CardM> cardsOf(String deckId, {bool recursive = true}) {
    final ids = recursive ? deckTree(deckId) : {deckId};
    return cards.where((c) => ids.contains(c.deckId)).toList();
  }

  int get newToday => newByDay[dayKey(DateTime.now())] ?? 0;

  /// Cards to study now: every due review, plus brand-new cards only up to today's remaining
  /// "new cards per day" budget (so importing 500 cards does not bury you under 500 "due" cards).
  List<CardM> dueCards([Iterable<CardM>? source]) {
    final now = DateTime.now().millisecondsSinceEpoch;
    final reviews = <CardM>[];
    final fresh = <CardM>[];
    for (final c in (source ?? cards)) {
      if (c.due > now) continue;
      if (c.isNew) {
        fresh.add(c);
      } else {
        reviews.add(c);
      }
    }
    final room = newPerDay <= 0 ? fresh.length : max(0, newPerDay - newToday);
    return [...reviews, ...fresh.take(room)];
  }

  int dueCount(String deckId) => dueCards(cardsOf(deckId)).length;

  Deck addDeck(String name, [String? parent]) {
    final d = Deck(newId(), name, parent, decks.length % kDeckColorCount);
    decks.add(d);
    changed();
    return d;
  }

  void setExam(Deck d, DateTime? when) {
    d.exam = when == null ? null : DateTime(when.year, when.month, when.day, 23, 59).millisecondsSinceEpoch;
    changed();
  }

  /// Study plan toward the deck's exam: days left, cards never studied, reviews due now and the
  /// number of new cards to learn per day (the last two days are kept for review only).
  ({int days, int unseen, int due, int total, int perDay})? examPlan(Deck d) {
    final e = d.exam;
    if (e == null) return null;
    final end = DateTime.fromMillisecondsSinceEpoch(e);
    final n = DateTime.now();
    final days = DateTime(end.year, end.month, end.day).difference(DateTime(n.year, n.month, n.day)).inDays;
    final list = cardsOf(d.id);
    final unseen = list.where((c) => c.isNew).length;
    final due = dueCards(list).where((c) => !c.isNew).length;
    final learnDays = max(1, days - 2);
    final perDay = days < 0 ? 0 : (unseen / learnDays).ceil();
    return (days: days, unseen: unseen, due: due, total: list.length, perDay: perDay);
  }

  void renameDeck(Deck d, String name) {
    d.name = name;
    changed();
  }

  void deleteDeck(String id) {
    final ids = deckTree(id);
    decks.removeWhere((d) => ids.contains(d.id));
    cards.removeWhere((c) => ids.contains(c.deckId));
    changed();
  }

  // ---------- cards ----------
  void addCard(CardM c) {
    cards.add(c);
    changed();
  }

  void addCards(String deckId, List<List<String>> pairs) {
    for (final p in pairs) {
      cards.add(CardM(id: newId(), deckId: deckId, front: p[0], back: p[1]));
    }
    changed();
  }

  void deleteCard(CardM c) {
    cards.removeWhere((e) => e.id == c.id);
    changed();
  }

  Future<String> saveImage(Uint8List bytes) async {
    final p = '${dir.path}/images/${newId()}.jpg';
    await File(p).writeAsBytes(bytes);
    return p;
  }

  // ---------- scheduling (FSRS / SM-2) ----------
  static const int _dayMs = 86400000;

  /// Computes what reviewing [c] with rating [q] (0 again, 3 hard, 4 good, 5 easy) would do,
  /// without changing the card.
  SchedResult plan(CardM c, int q, [DateTime? at]) {
    final now = at ?? DateTime.now();
    return scheduler == 'sm2' ? _planSm2(c, q, now) : _planFsrs(c, q, now);
  }

  SchedResult _planSm2(CardM c, int q, DateTime now) {
    var ease = c.ease;
    var interval = c.interval;
    var reps = c.reps;
    var lapses = c.lapses;
    int due;
    if (q < 3) {
      reps = 0;
      lapses++;
      interval = 0;
      due = now.add(const Duration(minutes: 10)).millisecondsSinceEpoch;
      ease = max(1.3, ease - 0.2);
    } else {
      if (reps == 0) {
        interval = 1;
      } else if (reps == 1) {
        interval = 6;
      } else {
        interval = max(interval + 1, (interval * ease).round());
      }
      reps++;
      ease = max(1.3, ease + 0.1 - (5 - q) * (0.08 + (5 - q) * 0.02));
      due = now.add(Duration(days: interval)).millisecondsSinceEpoch;
    }
    // stab = 0 so that switching back to FSRS re-derives the memory state from interval/ease.
    return SchedResult(
        ease: ease,
        stab: 0,
        diff: 0,
        interval: interval,
        reps: reps,
        lapses: lapses,
        due: due,
        lastRev: now.millisecondsSinceEpoch);
  }

  SchedResult _planFsrs(CardM c, int q, DateTime now) {
    final g = Fsrs.grade(q);
    final nowMs = now.millisecondsSinceEpoch;
    var stab = c.stab;
    var diff = c.diff;
    var last = c.lastRev;
    if (!c.isNew && stab <= 0) {
      // Card last scheduled by SM-2: derive an FSRS memory state from its interval and ease.
      stab = max(1.0, c.interval.toDouble());
      diff = (11 - c.ease * 2.3).clamp(1.0, 10.0).toDouble();
      last = c.interval > 0 ? c.due - c.interval * _dayMs : nowMs - _dayMs;
    }
    double newS;
    double newD;
    if (c.isNew) {
      newS = Fsrs.initStability(g);
      newD = Fsrs.initDifficulty(g);
    } else {
      final elapsed = max(0.0, (nowMs - last) / _dayMs);
      final r = Fsrs.retrievability(elapsed, stab);
      newD = Fsrs.nextDifficulty(diff, g);
      if (elapsed < 1) {
        newS = Fsrs.shortTerm(stab, g);
      } else if (g == 1) {
        newS = Fsrs.nextForget(diff, stab, r);
      } else {
        newS = Fsrs.nextRecall(diff, stab, r, g);
      }
    }
    var reps = c.reps;
    var lapses = c.lapses;
    int interval;
    int due;
    if (g == 1) {
      lapses++;
      interval = 0;
      due = now.add(const Duration(minutes: 10)).millisecondsSinceEpoch;
    } else {
      reps++;
      interval = Fsrs.intervalDays(newS, retention);
      due = now.add(Duration(days: interval)).millisecondsSinceEpoch;
    }
    return SchedResult(
        ease: c.ease,
        stab: newS,
        diff: newD,
        interval: interval,
        reps: reps,
        lapses: lapses,
        due: due,
        lastRev: nowMs);
  }

  /// Short label for the next interval shown under each answer button (e.g. "10m", "3d", "2mo").
  String previewLabel(CardM c, int q) {
    final r = plan(c, q);
    if (r.interval <= 0) return '10${tr('د', 'm')}';
    final d = r.interval;
    if (d < 30) return '$d${tr('ي', 'd')}';
    if (d < 365) return '${(d / 30).round()}${tr('ش', 'mo')}';
    final y = d / 365;
    return '${y.toStringAsFixed(y < 10 ? 1 : 0)}${tr('س', 'y')}';
  }

  /// Applies a review. Returns a snapshot that [undoReview] can restore.
  /// q: 0 again, 3 hard, 4 good, 5 easy
  List<num> review(CardM c, int q) {
    final wasNew = c.isNew;
    final snap = <num>[
      c.ease, c.interval, c.reps, c.lapses, c.due, q, q >= 3 ? 10 : 2, //
      c.stab, c.diff, c.lastRev, wasNew ? 1 : 0,
    ];
    final now = DateTime.now();
    final r = plan(c, q, now);
    c.ease = r.ease;
    c.interval = r.interval;
    c.reps = r.reps;
    c.lapses = r.lapses;
    c.due = r.due;
    c.stab = r.stab;
    c.diff = r.diff;
    c.lastRev = r.lastRev;
    lastDeckId = c.deckId;
    final dk = dayKey(now);
    if (lastDay != dk) {
      final y = dayKey(now.subtract(const Duration(days: 1)));
      streak = lastDay == y ? streak + 1 : 1;
      lastDay = dk;
    }
    byDay[dk] = (byDay[dk] ?? 0) + 1;
    if (wasNew) newByDay[dk] = (newByDay[dk] ?? 0) + 1;
    totalReviews++;
    xp += q >= 3 ? 10 : 2;
    changed();
    return snap;
  }

  void undoReview(CardM c, List<num> snap) {
    c.ease = snap[0].toDouble();
    c.interval = snap[1].toInt();
    c.reps = snap[2].toInt();
    c.lapses = snap[3].toInt();
    c.due = snap[4].toInt();
    if (snap.length > 10) {
      c.stab = snap[7].toDouble();
      c.diff = snap[8].toDouble();
      c.lastRev = snap[9].toInt();
    }
    final dk = dayKey(DateTime.now());
    byDay[dk] = max(0, (byDay[dk] ?? 1) - 1);
    if (snap.length > 10 && snap[10] == 1) newByDay[dk] = max(0, (newByDay[dk] ?? 1) - 1);
    totalReviews = max(0, totalReviews - 1);
    xp = max(0, xp - snap[6].toInt());
    changed();
  }

  void addXp(int n) {
    xp += n;
    changed();
  }

  // ---------- maps ----------
  void addMap(MindMap m) {
    maps.add(m);
    changed();
  }

  void deleteMap(MindMap m) {
    maps.removeWhere((e) => e.id == m.id);
    changed();
  }
}
