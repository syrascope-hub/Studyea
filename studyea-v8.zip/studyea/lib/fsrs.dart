import 'dart:math';

/// FSRS-5 (Free Spaced Repetition Scheduler) - the memory model used by modern Anki.
///
/// Every card has a stability S (days until recall probability falls to 90%), a difficulty D (1-10)
/// and a retrievability R (current recall probability). Unlike SM-2, which folds everything into one
/// "ease" number, FSRS models these separately and schedules the next review for the day R reaches
/// the user's desired retention. Default weights are the published FSRS-5 defaults.
class Fsrs {
  static const List<double> w = [
    0.40255, 1.18385, 3.173, 15.69105, 7.1949, 0.5345, 1.4604, 0.0046, 1.54575, 0.1192, //
    1.01925, 1.9395, 0.11, 0.29605, 2.2698, 0.2315, 2.9898, 0.51655, 0.6621,
  ];
  static const double decay = -0.5;
  static const double factor = 19 / 81;
  static const double minStab = 0.1;
  static const double maxStab = 36500;
  static const int maxInterval = 36500;

  /// App rating (0 again, 3 hard, 4 good, 5 easy) -> FSRS grade (1..4).
  static int grade(int q) => q < 3 ? 1 : (q == 3 ? 2 : (q == 4 ? 3 : 4));

  static double _d(double v) => v < 1.0 ? 1.0 : (v > 10.0 ? 10.0 : v);
  static double _s(double v) => v < minStab ? minStab : (v > maxStab ? maxStab : v);

  /// Probability of recalling the card after [t] days given stability [s].
  static double retrievability(double t, double s) => pow(1 + factor * t / s, decay).toDouble();

  /// Days until retrievability falls to [retention].
  static double intervalFor(double s, double retention) => s / factor * (pow(retention, 1 / decay).toDouble() - 1);

  static int intervalDays(double s, double retention) {
    final v = intervalFor(s, retention).round();
    return v < 1 ? 1 : (v > maxInterval ? maxInterval : v);
  }

  static double initStability(int g) => _s(w[g - 1]);

  static double initDifficulty(int g) => _d(w[4] - exp(w[5] * (g - 1)) + 1);

  static double nextDifficulty(double d, int g) {
    final delta = -w[6] * (g - 3);
    final damped = d + delta * (10 - d) / 9; // linear damping
    final reverted = w[7] * initDifficulty(4) + (1 - w[7]) * damped; // mean reversion
    return _d(reverted);
  }

  /// Stability after a successful review (Hard / Good / Easy).
  static double nextRecall(double d, double s, double r, int g) {
    final hard = g == 2 ? w[15] : 1.0;
    final easy = g == 4 ? w[16] : 1.0;
    final inc = 1 +
        exp(w[8]) * (11 - d) * pow(s, -w[9]).toDouble() * (exp(w[10] * (1 - r)) - 1) * hard * easy;
    return _s(s * inc);
  }

  /// Stability after a lapse (Again).
  static double nextForget(double d, double s, double r) {
    final v = w[11] * pow(d, -w[12]).toDouble() * (pow(s + 1, w[13]).toDouble() - 1) * exp(w[14] * (1 - r));
    return _s(min(s, v));
  }

  /// Stability after a same-day review (less than one day since the previous one).
  static double shortTerm(double s, int g) {
    var v = s * exp(w[17] * (g - 3 + w[18]));
    if (g >= 3 && v < s) v = s;
    return _s(v);
  }
}

/// A scheduling outcome. Pure data: computing it never mutates the card, so it is also used to
/// preview the next interval on the answer buttons.
class SchedResult {
  final double ease, stab, diff;
  final int interval, reps, lapses, due, lastRev;
  const SchedResult({
    required this.ease,
    required this.stab,
    required this.diff,
    required this.interval,
    required this.reps,
    required this.lapses,
    required this.due,
    required this.lastRev,
  });
}
