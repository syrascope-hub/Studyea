import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neu.dart';
import 'store.dart';
import 'study.dart';
import 'extras.dart';
import 'notify.dart';
import 'tts.dart';
import 'dart:convert';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/services.dart';

class StatsPage extends StatelessWidget {
  const StatsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    final now = DateTime.now();
    final days = [for (var i = 6; i >= 0; i--) now.subtract(Duration(days: i))];
    final vals = [for (final x in days) s.byDay[dayKey(x)] ?? 0];
    final mx = vals.fold<int>(1, (a, b) => b > a ? b : a);
    final nNew = s.cards.where((c) => c.isNew).length;
    final nMature = s.cards.where((c) => c.interval >= 21).length;
    final nLearn = s.cards.length - nNew - nMature;
    final hardest = [...s.cards]..sort((a, b) => b.lapses.compareTo(a.lapses));

    // Forecast: how many reviews fall due on each of the next 7 days (overdue cards count as today).
    final today0 = DateTime(now.year, now.month, now.day);
    final ahead = [for (var i = 0; i < 7; i++) now.add(Duration(days: i))];
    final fc = List<int>.filled(7, 0);
    for (final c in s.cards) {
      if (c.isNew) continue;
      final dd = DateTime.fromMillisecondsSinceEpoch(c.due);
      final k = (DateTime(dd.year, dd.month, dd.day).difference(today0).inHours / 24).round();
      if (k < 7) fc[k < 0 ? 0 : k]++;
    }
    final fcMax = fc.fold<int>(1, (a, b) => b > a ? b : a);
    // Activity heat-map: the last 84 days, oldest first, 7 per column.
    final heat = [for (var i = 83; i >= 0; i--) s.byDay[dayKey(now.subtract(Duration(days: i)))] ?? 0];
    final heatMax = heat.fold<int>(1, (a, b) => b > a ? b : a);

    Widget bars(List<int> v, List<String> labels, int top) => NeuBox(
          child: SizedBox(
            height: 120,
            child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
              for (var i = 0; i < v.length; i++)
                Expanded(
                  child: Column(mainAxisAlignment: MainAxisAlignment.end, children: [
                    Text('${v[i]}', style: TextStyle(fontSize: 10, color: neuText(d))),
                    const SizedBox(height: 4),
                    Container(
                      height: 8 + 70.0 * v[i] / top,
                      margin: const EdgeInsets.symmetric(horizontal: 6),
                      decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(8)),
                    ),
                    const SizedBox(height: 4),
                    Text(labels[i], style: TextStyle(fontSize: 10, color: neuText(d).withValues(alpha: .6))),
                  ]),
                ),
            ]),
          ),
        );

    Widget tile(String label, String v, IconData i) => Expanded(
          child: NeuBox(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
            child: Column(children: [
              Icon(i, color: kAccent),
              const SizedBox(height: 6),
              Text(v, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: neuText(d))),
              Text(label,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .6))),
            ]),
          ),
        );
    Widget h(String t) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 10),
        child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: neuText(d))));

    return NeuPage(
      title: s.t('stats'),
      actions: [
        NeuIcon(Icons.timer_rounded, size: 20,
            onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PomodoroPage())))
      ],
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Row(children: [
          tile(s.t('streak'), '${s.streak}', Icons.local_fire_department_rounded),
          const SizedBox(width: 12),
          tile('${s.t('level')}', '${s.level}', Icons.military_tech_rounded),
          const SizedBox(width: 12),
          tile(s.t('xp'), '${s.xp}', Icons.bolt_rounded),
        ]),
        h('${s.t('dailyGoal')}: ${s.today}/${s.dailyGoal}'),
        NeuBox(
          inset: true,
          radius: 12,
          padding: const EdgeInsets.all(4),
          child: LayoutBuilder(
            builder: (c, k) => Align(
              alignment: AlignmentDirectional.centerStart,
              child: Container(
                height: 14,
                width: k.maxWidth * (s.dailyGoal == 0 ? 0 : (s.today / s.dailyGoal).clamp(0, 1).toDouble()),
                decoration: BoxDecoration(color: kAccent, borderRadius: BorderRadius.circular(8)),
              ),
            ),
          ),
        ),
        h(s.t('last7')),
        bars(vals, [for (final x in days) '${x.day}'], mx),
        h(s.tr('توقّع المراجعات (7 أيام القادمة)', 'Review forecast (next 7 days)')),
        bars(fc, [for (final x in ahead) '${x.day}'], fcMax),
        h(s.tr('النشاط (آخر 12 أسبوعًا)', 'Activity (last 12 weeks)')),
        NeuBox(
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var wk = 0; wk < 12; wk++)
                Column(children: [
                  for (var dy = 0; dy < 7; dy++)
                    Builder(builder: (_) {
                      final v = heat[wk * 7 + dy];
                      return Container(
                        width: 15,
                        height: 15,
                        margin: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: v == 0 ? neuInset(d) : kAccent.withValues(alpha: (0.25 + 0.75 * v / heatMax).clamp(0.0, 1.0)),
                          borderRadius: BorderRadius.circular(4),
                        ),
                      );
                    }),
                ]),
            ]),
          ),
        ),
        h(s.t('mastery')),
        Row(children: [
          tile(s.t('mNew'), '$nNew', Icons.fiber_new_rounded),
          const SizedBox(width: 12),
          tile(s.t('mLearning'), '$nLearn', Icons.school_rounded),
          const SizedBox(width: 12),
          tile(s.t('mMature'), '$nMature', Icons.verified_rounded),
        ]),
        h(s.t('badges')),
        Builder(builder: (_) {
          final exams = s.decks.where((x) => x.exam != null).length;
          // (arabic, english, current, target)
          final ach = <(String, String, int, int)>[
            ('أول مراجعة', 'First review', s.totalReviews, 1),
            ('100 مراجعة', '100 reviews', s.totalReviews, 100),
            ('1000 مراجعة', '1,000 reviews', s.totalReviews, 1000),
            ('5000 مراجعة', '5,000 reviews', s.totalReviews, 5000),
            ('7 أيام متتالية', '7-day streak', s.streak, 7),
            ('30 يومًا متتالية', '30-day streak', s.streak, 30),
            ('100 يوم متتالية', '100-day streak', s.streak, 100),
            ('100 بطاقة', '100 cards', s.cards.length, 100),
            ('500 بطاقة', '500 cards', s.cards.length, 500),
            ('50 بطاقة متقنة', '50 mastered cards', nMature, 50),
            ('300 بطاقة متقنة', '300 mastered cards', nMature, 300),
            ('المستوى 5', 'Level 5', s.level, 5),
            ('المستوى 10', 'Level 10', s.level, 10),
            ('المستوى 25', 'Level 25', s.level, 25),
            ('ساعة تركيز', '1 hour of focus', s.focusTotal, 60),
            ('10 ساعات تركيز', '10 hours of focus', s.focusTotal, 600),
            ('أنجزت هدف اليوم', 'Daily goal reached', s.today, s.dailyGoal < 1 ? 1 : s.dailyGoal),
            ('خطة امتحان', 'Exam planned', exams, 1),
          ];
          final done = ach.where((e) => e.$3 >= e.$4).length;
          return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.tr('أنجزت $done من ${ach.length}', 'Unlocked $done of ${ach.length}'),
                style: TextStyle(fontSize: 12, color: neuText(d).withValues(alpha: .65))),
            const SizedBox(height: 8),
            Wrap(spacing: 10, runSpacing: 10, children: [
              for (final b in ach)
                Opacity(
                  opacity: b.$3 >= b.$4 ? 1 : .55,
                  child: NeuBox(
                    inset: b.$3 < b.$4,
                    radius: 14,
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Icon(Icons.workspace_premium_rounded, size: 18, color: b.$3 >= b.$4 ? Colors.amber.shade700 : null),
                      const SizedBox(width: 6),
                      Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
                        Text(s.tr(b.$1, b.$2), style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
                        if (b.$3 < b.$4)
                          Text('${b.$3} / ${b.$4}', style: TextStyle(fontSize: 10, color: neuText(d).withValues(alpha: .65))),
                      ]),
                    ]),
                  ),
                ),
            ]),
          ]);
        }),
        h(s.t('hardest')),
        for (final c in hardest.where((c) => c.lapses > 0).take(5))
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: NeuBox(
              padding: const EdgeInsets.all(12),
              child: Row(children: [
                Expanded(
                    child: Text(cardQA(c).$1,
                        maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: neuText(d)))),
                Text('${c.lapses} ✗', style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w700)),
              ]),
            ),
          ),
      ]),
    );
  }
}

class SettingsPage extends StatefulWidget {
  const SettingsPage({super.key});
  @override
  State<SettingsPage> createState() => _SettingsPageState();
}

class _SettingsPageState extends State<SettingsPage> {
  late final gk = TextEditingController(text: context.read<Store>().geminiKey);
  late final hk = TextEditingController(text: context.read<Store>().hfKey);
  late final ork = TextEditingController(text: context.read<Store>().openRouterKey);
  late final gtts = TextEditingController(text: context.read<Store>().googleTtsKey);
  late final elk = TextEditingController(text: context.read<Store>().elevenLabsKey);
  late final mdl = TextEditingController(text: context.read<Store>().model);
  late final nameC = TextEditingController(text: context.read<Store>().userName);
  bool savingKeys = false;
  String testing = '';

  Future<void> _test(String engine) async {
    final st = context.read<Store>();
    setState(() => testing = engine);
    final err = await testVoice(engine, googleKey: gtts.text, elevenLabsKey: elk.text, arabic: st.lang == 'ar');
    if (!mounted) return;
    setState(() => testing = '');
    if (err == null) {
      toast(context, st.tr('✓ المحرك يعمل', '✓ Engine works'));
    } else {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          backgroundColor: neuBg(isDark(context)),
          title: Text(st.tr('تعذّر تشغيل المحرك', 'Engine failed')),
          content: SingleChildScrollView(child: SelectableText(err)),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: Text(st.t('ok')))],
        ),
      );
    }
  }

  Future<void> _saveKeys() async {
    setState(() => savingKeys = true);
    try {
      final store = context.read<Store>();
      await store.updateSecret('openRouterKey', ork.text);
      await store.updateSecret('geminiKey', gk.text);
      await store.updateSecret('hfKey', hk.text);
      await store.updateSecret('googleTtsKey', gtts.text);
      await store.updateSecret('elevenLabsKey', elk.text);
      if (mounted) toast(context, 'تم حفظ المفاتيح في التخزين الآمن.');
    } catch (e) {
      if (mounted) toast(context, 'تعذر حفظ المفاتيح: $e');
    } finally {
      if (mounted) setState(() => savingKeys = false);
    }
  }

  @override
  void dispose() {
    gk.dispose();
    hk.dispose();
    ork.dispose();
    gtts.dispose();
    elk.dispose();
    mdl.dispose();
    nameC.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    Widget h(String t) => Padding(
        padding: const EdgeInsets.only(top: 20, bottom: 8),
        child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d))));
    Widget seg(List<(String, String)> items, String cur, void Function(String) on) => Wrap(spacing: 10, children: [
          for (final i in items)
            GestureDetector(
              onTap: () => on(i.$1),
              child: NeuBox(
                inset: cur == i.$1,
                radius: 14,
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                child: Text(i.$2,
                    style: TextStyle(fontWeight: FontWeight.w700, color: cur == i.$1 ? kAccent : neuText(d))),
              ),
            ),
        ]);
    return NeuPage(
      title: s.t('settings'),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        h(s.t('language')),
        seg([('ar', 'العربية'), ('en', 'English')], s.lang, (v) {
          s.lang = v;
          s.changed();
        }),
        h(s.t('theme')),
        Wrap(spacing: 12, children: [
          for (var i = 0; i < kThemeCount; i++)
            GestureDetector(
              onTap: () {
                s.themeIdx = i;
                gTheme = i;
                s.changed();
              },
              child: Container(
                width: 44,
                height: 44,
                decoration: BoxDecoration(
                  color: themeSwatch(i),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: neuLo(d), width: s.themeIdx == i ? 5 : 2.5),
                ),
              ),
            ),
        ]),
        h(s.t('fontSize')),
        seg([('0.9', 'S'), ('1.0', 'M'), ('1.15', 'L'), ('1.3', 'XL')], s.fontScale.toString(), (v) {
          s.fontScale = double.parse(v);
          s.changed();
        }),
        h(s.t('reminder')),
        Row(children: [
          NeuButton(
            filled: s.remindOn,
            onTap: () async {
              if (s.remindOn) {
                s.remindOn = false;
                await disableReminder();
              } else {
                final ok = await enableReminder(s.remindH, s.remindM, s.t('remTitle'), s.t('remBody'));
                s.remindOn = ok;
                if (!ok && context.mounted) toast(context, s.t('permDenied'));
              }
              s.changed();
            },
            child: Text(s.remindOn ? s.t('on') : s.t('off')),
          ),
          const SizedBox(width: 12),
          NeuButton(
            onTap: () async {
              final t = await showTimePicker(
                  context: context, initialTime: TimeOfDay(hour: s.remindH, minute: s.remindM));
              if (t == null) return;
              s.remindH = t.hour;
              s.remindM = t.minute;
              if (s.remindOn) await enableReminder(t.hour, t.minute, s.t('remTitle'), s.t('remBody'));
              s.changed();
            },
            child: Text('${s.remindH.toString().padLeft(2, '0')}:${s.remindM.toString().padLeft(2, '0')}'),
          ),
        ]),
        h(s.t('darkMode')),
        seg([('0', '☀'), ('1', '🌙')], s.dark ? '1' : '0', (v) {
          s.dark = v == '1';
          s.changed();
        }),
        h(s.t('dailyGoal')),
        Row(children: [
          NeuIcon(Icons.remove_rounded, onTap: () {
            if (s.dailyGoal > 5) {
              s.dailyGoal -= 5;
              s.changed();
            }
          }),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text('${s.dailyGoal}',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: neuText(d)))),
          NeuIcon(Icons.add_rounded, onTap: () {
            s.dailyGoal += 5;
            s.changed();
          }),
        ]),
        h(s.tr('خوارزمية المراجعة', 'Review algorithm')),
        seg([('fsrs', 'FSRS'), ('sm2', 'SM-2')], s.scheduler, (v) {
          s.scheduler = v;
          s.changed();
        }),
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(
              s.tr('FSRS يتنبأ بلحظة نسيانك لكل بطاقة بدقة أعلى من SM-2، فتراجع عددًا أقل من البطاقات لنفس مستوى التذكّر. البطاقات الحالية تُحوَّل تلقائيًا ولا تضيع بياناتك.',
                  'FSRS predicts when you will forget each card more accurately than SM-2, so you review fewer cards for the same retention. Existing cards are converted automatically; nothing is lost.'),
              style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
        ),
        if (s.scheduler == 'fsrs') ...[
          h(s.tr('نسبة التذكّر المستهدفة', 'Target retention')),
          seg([('0.8', '80%'), ('0.85', '85%'), ('0.9', '90%'), ('0.95', '95%')], s.retention.toString(), (v) {
            s.retention = double.parse(v);
            s.changed();
          }),
          Padding(
            padding: const EdgeInsets.only(top: 6),
            child: Text(
                s.tr('أعلى = تذكّر أفضل لكن مراجعات أكثر. 90% هو التوازن الموصى به.',
                    'Higher = better recall but more reviews. 90% is the recommended balance.'),
                style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
          ),
        ],
        h(s.tr('بطاقات جديدة يوميًا', 'New cards per day')),
        Row(children: [
          NeuIcon(Icons.remove_rounded, onTap: () {
            if (s.newPerDay > 5) {
              s.newPerDay -= 5;
              s.changed();
            }
          }),
          Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Text('${s.newPerDay}',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: neuText(d)))),
          NeuIcon(Icons.add_rounded, onTap: () {
            if (s.newPerDay < 200) {
              s.newPerDay += 5;
              s.changed();
            }
          }),
        ]),
        Padding(
          padding: const EdgeInsets.only(top: 6),
          child: Text(
              s.tr('يمنع تراكم مئات البطاقات الجديدة دفعة واحدة.',
                  'Stops hundreds of new cards from piling up at once.'),
              style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
        ),
        h(s.t('aiProvider')),
        seg([('openrouter', 'OpenRouter'), ('gemini', 'Gemini'), ('hf', 'Hugging Face')], s.provider, (v) {
          if (s.provider != v) {
            s.provider = v;
            s.model = '';
            mdl.clear();
            s.changed();
          }
        }),
        h('OpenRouter API Key'),
        NeuField(controller: ork, obscure: true),
        Padding(
          padding: const EdgeInsets.only(top: 5),
          child: Text('النموذج الافتراضي: openai/gpt-4o-mini. يمكنك إدخال اسم نموذج متاح من OpenRouter أدناه.', style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
        ),
        h(s.t('geminiKey')),
        NeuField(controller: gk, obscure: true),
        h(s.t('hfKey')),
        NeuField(controller: hk, obscure: true),
        h('مفتاح Google Cloud Text-to-Speech (اختياري)'),
        NeuField(controller: gtts, obscure: true),
        h('مفتاح ElevenLabs (اختياري)'),
        NeuField(controller: elk, obscure: true),
        const SizedBox(height: 12),
        NeuButton(
          filled: true,
          onTap: savingKeys ? null : _saveKeys,
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            if (savingKeys) const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            else const Icon(Icons.lock_rounded, size: 18),
            const SizedBox(width: 8),
            Text(savingKeys ? 'جارٍ الحفظ…' : 'حفظ مفاتيح API بشكل آمن'),
          ]),
        ),
        h(s.tr('اسمك', 'Your name')),
        NeuField(controller: nameC, hint: s.tr('يظهر في الشاشة الرئيسية', 'Shown on the home screen'), onChanged: (v) {
          s.userName = v.trim();
          s.changed();
        }),
        h('محرك القراءة الصوتية'),
        seg([('auto', 'تلقائي'), ('online', 'أونلاين مجاني'), ('local', 'محلي'), ('google', 'Google'), ('elevenlabs', 'ElevenLabs')], s.voiceEngine, (v) => s.setVoiceEngine(v)),
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text('الوضع التلقائي يعمل بدون أي مفتاح: يستخدم الصوت المجاني عبر الإنترنت، وإذا لم يتوفر الإنترنت يستخدم صوت الجهاز. إن أدخلت مفتاح Google أو ElevenLabs فسيُفضَّلان تلقائيًا. كل جملة تُنزَّل مرة واحدة وتُحفظ على جهازك، فتُعاد فورًا بعد ذلك.', style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
        ),
        const SizedBox(height: 12),
        Text(s.tr('اختبار المحركات', 'Test engines'), style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d))),
        const SizedBox(height: 8),
        Wrap(spacing: 10, runSpacing: 10, children: [
          for (final e in const [('online', 'أونلاين مجاني'), ('local', 'الجهاز / Device'), ('google', 'Google'), ('elevenlabs', 'ElevenLabs')])
            NeuButton(
              onTap: testing.isEmpty ? () => _test(e.$1) : null,
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
              child: Row(mainAxisSize: MainAxisSize.min, children: [
                if (testing == e.$1)
                  const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                else
                  const Icon(Icons.play_arrow_rounded, size: 18),
                const SizedBox(width: 6),
                Text(e.$2, style: const TextStyle(fontSize: 12)),
              ]),
            ),
        ]),
        const SizedBox(height: 12),
        const _VoiceCacheTile(),
        const SizedBox(height: 12),
        Row(children: [
          Text(s.tr('السرعة', 'Speed'), style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d))),
          Expanded(
            child: Slider(
              value: s.voiceSpeed,
              min: 0.5,
              max: 2.0,
              divisions: 12,
              activeColor: kAccent,
              label: '${s.voiceSpeed.toStringAsFixed(2)}x',
              onChanged: (v) => s.setVoiceSpeed(v),
            ),
          ),
          Text('${s.voiceSpeed.toStringAsFixed(2)}x', style: TextStyle(color: neuText(d))),
        ]),
        SwitchListTile(
          contentPadding: EdgeInsets.zero,
          activeColor: kAccent,
          title: Text(s.tr('قراءة البطاقات تلقائيًا أثناء المراجعة', 'Auto-read cards during review'), style: TextStyle(color: neuText(d), fontWeight: FontWeight.w700)),
          value: s.autoSpeak,
          onChanged: (v) {
            s.autoSpeak = v;
            s.changed();
          },
        ),
        Text(s.tr('تُقرأ الصيغ المكتوبة بـ LaTeX كلمات (مثل: x تربيع زائد 2). Google وElevenLabs قد لا تعمل في بعض الدول؛ عندها يعود التطبيق لصوت الجهاز ويعرض سبب الفشل.', 'LaTeX formulas are read as words. Google and ElevenLabs may be unreachable in some countries; the app then falls back to the device voice and shows why.'),
            style: TextStyle(fontSize: 11, color: neuText(d).withValues(alpha: .58))),
        h(s.t('aiModel')),
        NeuField(controller: mdl, onChanged: (v) {
          s.model = v.trim();
          s.changed();
        }),
        h('Backup'),
        Wrap(spacing: 10, runSpacing: 10, children: [
          NeuButton(
              onTap: () async {
                try {
                  final bytes = Uint8List.fromList(utf8.encode(jsonEncode(s.toMap())));
                  final name = 'studyea-backup-${dayKey(DateTime.now())}.json';
                  final path = await FilePicker.platform.saveFile(
                    dialogTitle: s.tr('حفظ النسخة الاحتياطية', 'Save backup'),
                    fileName: name,
                    bytes: bytes,
                  );
                  if (path != null && context.mounted) toast(context, s.tr('تم حفظ الملف', 'Backup file saved'));
                } catch (e) {
                  if (context.mounted) toast(context, e.toString());
                }
              },
              child: Text(s.tr('حفظ نسخة كملف', 'Save backup file'))),
          NeuButton(
              onTap: () async {
                try {
                  final res = await FilePicker.platform
                      .pickFiles(type: FileType.custom, allowedExtensions: const ['json'], withData: true);
                  final data = res?.files.single.bytes;
                  if (data == null) return;
                  s.fromMap(Map<String, dynamic>.from(jsonDecode(utf8.decode(data))));
                  s.changed();
                  if (context.mounted) toast(context, s.t('restored'));
                } catch (e) {
                  if (context.mounted) toast(context, e.toString());
                }
              },
              child: Text(s.tr('استعادة من ملف', 'Restore from file'))),
          NeuButton(
              onTap: () async {
                await Clipboard.setData(ClipboardData(text: jsonEncode(s.toMap())));
                if (context.mounted) toast(context, s.t('copied'));
              },
              child: Text(s.t('backupCopy'))),
          NeuButton(
              onTap: () async {
                final d = await Clipboard.getData('text/plain');
                try {
                  s.fromMap(jsonDecode(d?.text ?? ''));
                  s.changed();
                  if (context.mounted) toast(context, s.t('restored'));
                } catch (e) {
                  if (context.mounted) toast(context, e.toString());
                }
              },
              child: Text(s.t('backupRestore'))),
        ]),
        const SizedBox(height: 20),
      ]),
    );
  }
}


/// Shows how much downloaded voice audio is stored on the device and lets the user clear it.
class _VoiceCacheTile extends StatefulWidget {
  const _VoiceCacheTile();

  @override
  State<_VoiceCacheTile> createState() => _VoiceCacheTileState();
}

class _VoiceCacheTileState extends State<_VoiceCacheTile> {
  int? _bytes;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final b = await speechCacheBytes();
    if (mounted) setState(() => _bytes = b);
  }

  String _fmt(int b) => b < 1024 * 1024 ? '${(b / 1024).toStringAsFixed(0)} KB' : '${(b / 1024 / 1024).toStringAsFixed(1)} MB';

  @override
  Widget build(BuildContext context) {
    final s = context.watch<Store>();
    final d = isDark(context);
    return Row(children: [
      Expanded(
        child: Text(
          s.tr('الأصوات المحمّلة على الجهاز: ${_bytes == null ? '…' : _fmt(_bytes!)}', 'Downloaded voice audio: ${_bytes == null ? '…' : _fmt(_bytes!)}'),
          style: TextStyle(fontWeight: FontWeight.w800, color: neuText(d)),
        ),
      ),
      NeuButton(
        onTap: (_bytes ?? 0) == 0
            ? null
            : () async {
                await clearSpeechCache();
                await _load();
              },
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
        child: Text(s.tr('مسح', 'Clear'), style: const TextStyle(fontSize: 12)),
      ),
    ]);
  }
}
