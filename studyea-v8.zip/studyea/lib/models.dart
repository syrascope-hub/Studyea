const int kDeckColorCount = 5;

class Deck {
  String id, name;
  String? parentId;
  int color; // index into kDeckColors, -1 = derive from id
  int? exam; // exam date (ms since epoch, end of that day) or null
  Deck(this.id, this.name, [this.parentId, this.color = -1, this.exam]);
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'parentId': parentId, 'color': color, 'exam': exam};
  factory Deck.fromJson(Map<String, dynamic> j) => Deck(j['id'], j['name'], j['parentId'], (j['color'] ?? -1) as int, j['exam'] as int?);
}

class CardM {
  String id, deckId, type, front, back;
  List<String> options, tags;
  String? image;
  double ease;
  int interval, reps, lapses, due, created;
  // FSRS memory state: stability (days), difficulty (1-10) and the time of the last review (ms).
  // stab == 0 means "no FSRS state yet" (new card, or a card last scheduled with SM-2).
  double stab, diff;
  int lastRev;
  CardM({
    required this.id,
    required this.deckId,
    this.type = 'basic',
    this.front = '',
    this.back = '',
    List<String>? options,
    List<String>? tags,
    this.image,
    this.ease = 2.5,
    this.interval = 0,
    this.reps = 0,
    this.lapses = 0,
    this.stab = 0,
    this.diff = 0,
    this.lastRev = 0,
    int? due,
    int? created,
  })  : options = options ?? [],
        tags = tags ?? [],
        due = due ?? 0,
        created = created ?? DateTime.now().millisecondsSinceEpoch;

  bool get isNew => reps == 0 && lapses == 0;

  Map<String, dynamic> toJson() => {
        'id': id,
        'deckId': deckId,
        'type': type,
        'front': front,
        'back': back,
        'options': options,
        'tags': tags,
        'image': image,
        'ease': ease,
        'interval': interval,
        'reps': reps,
        'lapses': lapses,
        'stab': stab,
        'diff': diff,
        'lastRev': lastRev,
        'due': due,
        'created': created,
      };
  factory CardM.fromJson(Map<String, dynamic> j) => CardM(
        id: j['id'],
        deckId: j['deckId'],
        type: j['type'] ?? 'basic',
        front: j['front'] ?? '',
        back: j['back'] ?? '',
        options: List<String>.from(j['options'] ?? []),
        tags: List<String>.from(j['tags'] ?? []),
        image: j['image'],
        ease: (j['ease'] ?? 2.5).toDouble(),
        interval: j['interval'] ?? 0,
        reps: j['reps'] ?? 0,
        lapses: j['lapses'] ?? 0,
        stab: (j['stab'] ?? 0).toDouble(),
        diff: (j['diff'] ?? 0).toDouble(),
        lastRev: j['lastRev'] ?? 0,
        due: j['due'] ?? 0,
        created: j['created'],
      );
}

class MNode {
  String id, text;
  List<MNode> children;
  MNode(this.id, this.text, [List<MNode>? c]) : children = c ?? [];
  Map<String, dynamic> toJson() => {'id': id, 'text': text, 'children': children.map((e) => e.toJson()).toList()};
  factory MNode.fromJson(Map<String, dynamic> j) =>
      MNode(j['id'], j['text'], (j['children'] as List? ?? []).map((e) => MNode.fromJson(e)).toList());
  int count() => 1 + children.fold(0, (a, b) => a + b.count());
}

class MindMap {
  String id, title;
  MNode root;
  MindMap(this.id, this.title, this.root);
  Map<String, dynamic> toJson() => {'id': id, 'title': title, 'root': root.toJson()};
  factory MindMap.fromJson(Map<String, dynamic> j) => MindMap(j['id'], j['title'], MNode.fromJson(j['root']));
}
