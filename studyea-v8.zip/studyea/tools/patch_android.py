import os, re
base = 'android/app/'
# --- gradle: core library desugaring (needed by flutter_local_notifications)
for fn in ['build.gradle.kts', 'build.gradle']:
    p = base + fn
    if not os.path.exists(p):
        continue
    s = open(p).read()
    if 'desugar_jdk_libs' in s:
        continue
    if fn.endswith('.kts'):
        s = s.replace('compileOptions {', 'compileOptions {\n        isCoreLibraryDesugaringEnabled = true', 1)
        s += '\ndependencies {\n    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")\n}\n'
    else:
        s = s.replace('compileOptions {', 'compileOptions {\n        coreLibraryDesugaringEnabled true', 1)
        s += "\ndependencies {\n    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:2.1.4'\n}\n"
    open(p, 'w').write(s)
    print('patched', p)

# --- minSdk: Android 8.0+ (API 26)
for fn in ['build.gradle.kts', 'build.gradle']:
    p = base + fn
    if not os.path.exists(p):
        continue
    s = open(p).read()
    s2 = s.replace('minSdk = flutter.minSdkVersion', 'minSdk = 26').replace('minSdkVersion flutter.minSdkVersion', 'minSdkVersion 26')
    if s2 != s:
        open(p, 'w').write(s2)
        print('minSdk set to 26', p)

# --- release signing: use android/key.properties when present, otherwise fall back to debug
for fn in ['build.gradle.kts', 'build.gradle']:
    p = base + fn
    if not os.path.exists(p):
        continue
    s = open(p).read()
    if 'key.properties' in s:
        continue
    if fn.endswith('.kts'):
        s = ('import java.util.Properties\nimport java.io.FileInputStream\n\n'
             'val keystoreProperties = Properties()\n'
             'val keystorePropertiesFile = rootProject.file("key.properties")\n'
             'if (keystorePropertiesFile.exists()) { keystoreProperties.load(FileInputStream(keystorePropertiesFile)) }\n\n') + s
        s = s.replace('android {', """android {
    signingConfigs {
        create("release") {
            if (keystorePropertiesFile.exists()) {
                keyAlias = keystoreProperties["keyAlias"] as String
                keyPassword = keystoreProperties["keyPassword"] as String
                storeFile = file(keystoreProperties["storeFile"] as String)
                storePassword = keystoreProperties["storePassword"] as String
            }
        }
    }""", 1)
        s = s.replace('signingConfig = signingConfigs.getByName("debug")',
                      'signingConfig = if (keystorePropertiesFile.exists()) signingConfigs.getByName("release") else signingConfigs.getByName("debug")')
    else:
        s = ('def keystoreProperties = new Properties()\n'
             'def keystorePropertiesFile = rootProject.file("key.properties")\n'
             'if (keystorePropertiesFile.exists()) { keystoreProperties.load(new FileInputStream(keystorePropertiesFile)) }\n\n') + s
        s = s.replace('android {', """android {
    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
            }
        }
    }""", 1)
        s = s.replace('signingConfig signingConfigs.debug',
                      'signingConfig keystorePropertiesFile.exists() ? signingConfigs.release : signingConfigs.debug')
    open(p, 'w').write(s)
    print('signing patched', p)

# --- manifest
m = base + 'src/main/AndroidManifest.xml'
s = open(m).read()
s = re.sub(r'android:label="[^"]*"', 'android:label="Studyea"', s, count=1)
# Secure storage relies on device-bound encryption keys; avoid restoring an encrypted data blob
# onto a different installation where its key may no longer exist.
if 'android:allowBackup=' not in s:
    s = s.replace('<application', '<application android:allowBackup="false"', 1)
perms = ''.join('    <uses-permission android:name="android.permission.%s"/>\n' % x for x in
                ['INTERNET', 'VIBRATE', 'POST_NOTIFICATIONS', 'RECEIVE_BOOT_COMPLETED'])
queries = '''    <queries>
        <intent>
            <action android:name="android.intent.action.TTS_SERVICE"/>
        </intent>
    </queries>
'''
if 'TTS_SERVICE' not in s:
    s = s.replace('<application', queries + '    <application', 1)
s = s.replace('<application', perms + '    <application', 1)
receivers = '''
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MOCKED_BOOT_COMPLETED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
    </application>'''
s = s.replace('</application>', receivers, 1)
open(m, 'w').write(s)
print('manifest ok')

# --- compileSdk 36 (required by current AndroidX dependencies)
import re as _re
for fn in ['build.gradle.kts', 'build.gradle']:
    p = base + fn
    if not os.path.exists(p):
        continue
    s = open(p).read()
    eq = ' = ' if fn.endswith('.kts') else ' '
    s2 = _re.sub(r'compileSdk(?:Version)?\s*=?\s*(?:flutter\.\w+|\d+)', 'compileSdk' + eq + '36', s)
    if s2 != s:
        open(p, 'w').write(s2)
        print('compileSdk set to 36', p)

# --- launcher icon: copy the bundled StudyEA icons over the default Flutter ones
import shutil
res = base + 'src/main/res/'
if os.path.isdir('android_icons'):
    for dn in sorted(os.listdir('android_icons')):
        src_dir = os.path.join('android_icons', dn)
        if not (dn.startswith('mipmap-') and os.path.isdir(src_dir)):
            continue
        os.makedirs(res + dn, exist_ok=True)
        for fn in os.listdir(src_dir):
            shutil.copyfile(os.path.join(src_dir, fn), res + dn + '/' + fn)
    print('launcher icons copied')

# --- native launch screen: cream background instead of a white flash before Flutter draws its splash
launch = '''<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item>
        <shape android:shape="rectangle">
            <solid android:color="#FFF5F0E7"/>
        </shape>
    </item>
</layer-list>
'''
for dn in ['drawable', 'drawable-v21']:
    if os.path.isdir(res + dn):
        open(res + dn + '/launch_background.xml', 'w').write(launch)
        print('launch background patched', dn)

# Android 12+ has its own system splash; give it the same background colour (light and dark).
def _splash_style(color):
    return '''<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="LaunchTheme" parent="@android:style/Theme.Light.NoTitleBar">
        <item name="android:windowBackground">@drawable/launch_background</item>
        <item name="android:windowSplashScreenBackground">%s</item>
    </style>
</resources>
''' % color
for dn, color in [('values-v31', '#FFF5F0E7'), ('values-night-v31', '#FF17151D')]:
    os.makedirs(res + dn, exist_ok=True)
    open(res + dn + '/styles.xml', 'w').write(_splash_style(color))
print('android 12 splash colours set')

# --- compileSdk 36 for every plugin sub-project too (some plugins pin an older compileSdk and fail
# with "requires libraries and applications that depend on it to compile against version 36")
for fn in ['build.gradle.kts', 'build.gradle']:
    p = 'android/' + fn
    if not os.path.exists(p):
        continue
    s = open(p).read()
    if 'compileSdkVersion(36)' in s or 'compileSdkVersion 36' in s:
        continue
    if fn.endswith('.kts'):
        block = '''subprojects {
    afterEvaluate {
        (extensions.findByName("android") as? com.android.build.gradle.BaseExtension)?.compileSdkVersion(36)
    }
}

'''
    else:
        block = '''subprojects {
    afterEvaluate { p ->
        if (p.hasProperty('android')) {
            p.android.compileSdkVersion 36
        }
    }
}

'''
    open(p, 'w').write(block + s)
    print('subprojects compileSdk 36 patched', p)


# --- home-screen widget (streak, due cards, daily goal); data is sent from Dart by the home_widget plugin
ns = None
for fn in ['build.gradle.kts', 'build.gradle']:
    q = base + fn
    if os.path.exists(q):
        mm = re.search(r'namespace\s*=?\s*["\']([^"\']+)["\']', open(q).read())
        if mm:
            ns = mm.group(1)
            break
ns = ns or 'app.studyea.studyea'
kt_dir = base + 'src/main/kotlin/' + ns.replace('.', '/') + '/'
os.makedirs(kt_dir, exist_ok=True)
open(kt_dir + 'StudyeaWidgetProvider.kt', 'w').write("""package %s

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.SharedPreferences
import android.widget.RemoteViews
import es.antonborri.home_widget.HomeWidgetProvider

class StudyeaWidgetProvider : HomeWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray,
        widgetData: SharedPreferences
    ) {
        for (id in appWidgetIds) {
            val views = RemoteViews(context.packageName, R.layout.studyea_widget)
            views.setTextViewText(R.id.widget_title, widgetData.getString("w_title", "StudyEA"))
            views.setTextViewText(R.id.widget_streak, widgetData.getString("w_streak", "StudyEA"))
            views.setTextViewText(R.id.widget_due, widgetData.getString("w_due", ""))
            views.setTextViewText(R.id.widget_goal, widgetData.getString("w_goal", ""))
            val pct = widgetData.getString("w_pct", "0")?.toIntOrNull() ?: 0
            views.setProgressBar(R.id.widget_progress, 100, pct, false)
            val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
            if (launch != null) {
                val pending = PendingIntent.getActivity(
                    context, 0, launch, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                views.setOnClickPendingIntent(R.id.widget_root, pending)
            }
            appWidgetManager.updateAppWidget(id, views)
        }
    }
}
""" % ns)
os.makedirs(res + 'layout', exist_ok=True)
os.makedirs(res + 'xml', exist_ok=True)
os.makedirs(res + 'drawable', exist_ok=True)
open(res + 'drawable/studyea_widget_bg.xml', 'w').write("""<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">
    <solid android:color="#FFF5F0E7"/>
    <stroke android:width="2dp" android:color="#FF17151D"/>
    <corners android:radius="16dp"/>
</shape>
""")
open(res + 'layout/studyea_widget.xml', 'w').write("""<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/widget_root"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:padding="14dp"
    android:background="@drawable/studyea_widget_bg">
    <TextView
        android:id="@+id/widget_title"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="StudyEA"
        android:textColor="#FF6C3BFF"
        android:textSize="12sp"
        android:textStyle="bold"/>
    <TextView
        android:id="@+id/widget_streak"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="2dp"
        android:textColor="#FF17151D"
        android:textSize="20sp"
        android:textStyle="bold"/>
    <TextView
        android:id="@+id/widget_due"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="2dp"
        android:textColor="#FF17151D"
        android:textSize="14sp"/>
    <ProgressBar
        android:id="@+id/widget_progress"
        style="?android:attr/progressBarStyleHorizontal"
        android:layout_width="match_parent"
        android:layout_height="8dp"
        android:layout_marginTop="10dp"
        android:max="100"
        android:progress="0"
        android:progressTint="#FF6C3BFF"/>
    <TextView
        android:id="@+id/widget_goal"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:layout_marginTop="4dp"
        android:textColor="#FF17151D"
        android:textSize="12sp"/>
</LinearLayout>
""")
open(res + 'xml/studyea_widget_info.xml', 'w').write("""<?xml version="1.0" encoding="utf-8"?>
<appwidget-provider xmlns:android="http://schemas.android.com/apk/res/android"
    android:minWidth="180dp"
    android:minHeight="110dp"
    android:updatePeriodMillis="1800000"
    android:initialLayout="@layout/studyea_widget"
    android:resizeMode="horizontal|vertical"
    android:widgetCategory="home_screen"/>
""")
mf = base + 'src/main/AndroidManifest.xml'
ms = open(mf).read()
if 'StudyeaWidgetProvider' not in ms:
    rcv = """
        <receiver android:name="%s.StudyeaWidgetProvider" android:exported="true">
            <intent-filter>
                <action android:name="android.appwidget.action.APPWIDGET_UPDATE"/>
            </intent-filter>
            <meta-data android:name="android.appwidget.provider" android:resource="@xml/studyea_widget_info"/>
        </receiver>
    </application>""" % ns
    ms = ms.replace('</application>', rcv, 1)
    open(mf, 'w').write(ms)
print('home-screen widget files written for package', ns)
